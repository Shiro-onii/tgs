

<?php $__env->startSection('title', 'Kembalikan Alat'); ?>
<?php $__env->startSection('page-title', 'Pengembalian Alat'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Pengembalian Alat</h5>
            </div>
            <div class="card-body">
                <!-- Info Peminjaman -->
                <div class="alert alert-info">
                    <h6 class="alert-heading">Informasi Peminjaman</h6>
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <th width="30%">Kode</th>
                            <td>: <?php echo e($peminjaman->kode_peminjaman); ?></td>
                        </tr>
                        <tr>
                            <th>Alat</th>
                            <td>: <?php echo e($peminjaman->alat->nama_alat); ?></td>
                        </tr>
                        <tr>
                            <th>Jumlah Pinjam</th>
                            <td>: <?php echo e($peminjaman->jumlah_pinjam); ?> unit</td>
                        </tr>
                        <tr>
                            <th>Tgl Kembali (Rencana)</th>
                            <td>: <?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana))); ?></td>
                        </tr>
                    </table>
                </div>

                <form action="<?php echo e(route('peminjam.pengembalian.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <input type="hidden" name="peminjaman_id" value="<?php echo e($peminjaman->id); ?>">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="jumlah_dikembalikan" class="form-label">Jumlah Dikembalikan <span class="text-danger">*</span></label>
                                <input type="number" class="form-control <?php $__errorArgs = ['jumlah_dikembalikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="jumlah_dikembalikan" name="jumlah_dikembalikan" 
                                       value="<?php echo e(old('jumlah_dikembalikan', $peminjaman->jumlah_pinjam)); ?>" 
                                       min="1" max="<?php echo e($peminjaman->jumlah_pinjam); ?>" required onchange="hitungDenda()">
                                <?php $__errorArgs = ['jumlah_dikembalikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pengembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_pengembalian" name="tanggal_pengembalian" 
                                       value="<?php echo e(old('tanggal_pengembalian', date('Y-m-d'))); ?>" 
                                       max="<?php echo e(date('Y-m-d')); ?>" required onchange="hitungDenda()">
                                <?php $__errorArgs = ['tanggal_pengembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="kondisi_alat" class="form-label">Kondisi Alat <span class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['kondisi_alat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="kondisi_alat" name="kondisi_alat" required onchange="hitungDenda()">
                            <option value="baik" <?php echo e(old('kondisi_alat') == 'baik' ? 'selected' : ''); ?>>Baik (Tidak Ada Kerusakan)</option>
                            <option value="rusak_ringan" <?php echo e(old('kondisi_alat') == 'rusak_ringan' ? 'selected' : ''); ?>>Rusak Ringan (+ Rp 50.000)</option>
                            <option value="rusak_berat" <?php echo e(old('kondisi_alat') == 'rusak_berat' ? 'selected' : ''); ?>>Rusak Berat (+ Rp 200.000)</option>
                        </select>
                        <?php $__errorArgs = ['kondisi_alat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan (Opsional)</label>
                        <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="keterangan" name="keterangan" rows="3" placeholder="Tambahkan keterangan jika ada..."><?php echo e(old('keterangan')); ?></textarea>
                        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Perhitungan Denda -->
                    <div class="card bg-light mb-3">
                        <div class="card-body">
                            <h6 class="card-title">Perhitungan Denda</h6>
                            <div id="dendaInfo">
                                <p class="mb-1">Menghitung...</p>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-check me-2"></i> Kembalikan Alat
                        </button>
                        <a href="<?php echo e(route('peminjam.peminjaman.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Batal
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i> Informasi Denda</h6>
            </div>
            <div class="card-body">
                <h6>Denda Keterlambatan</h6>
                <p class="small text-muted mb-3">Rp 10.000 per hari</p>

                <h6>Denda Kerusakan</h6>
                <ul class="small text-muted mb-0">
                    <li>Rusak Ringan: Rp 50.000 per unit</li>
                    <li>Rusak Berat: Rp 200.000 per unit</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const tglRencana = new Date('<?php echo e($peminjaman->tanggal_kembali_rencana); ?>');
const DENDA_PER_HARI = 10000;
const DENDA_RUSAK_RINGAN = 50000;
const DENDA_RUSAK_BERAT = 200000;

function hitungDenda() {
    const tglKembali = new Date(document.getElementById('tanggal_pengembalian').value);
    const kondisi = document.getElementById('kondisi_alat').value;
    const jumlah = parseInt(document.getElementById('jumlah_dikembalikan').value) || 1;
    
    // Hitung keterlambatan
    const diffTime = tglKembali - tglRencana;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const hariTerlambat = diffDays > 0 ? diffDays : 0;
    
    // Hitung denda keterlambatan
    const dendaTerlambat = hariTerlambat * DENDA_PER_HARI * jumlah;
    
    // Hitung denda kerusakan
    let dendaKerusakan = 0;
    if (kondisi === 'rusak_ringan') {
        dendaKerusakan = DENDA_RUSAK_RINGAN * jumlah;
    } else if (kondisi === 'rusak_berat') {
        dendaKerusakan = DENDA_RUSAK_BERAT * jumlah;
    }
    
    // Total denda
    const totalDenda = dendaTerlambat + dendaKerusakan;
    
    // Tampilkan info
    let infoHTML = '';
    
    if (hariTerlambat > 0) {
        infoHTML += `<p class="mb-1"><strong>Keterlambatan:</strong> ${hariTerlambat} hari × Rp ${DENDA_PER_HARI.toLocaleString('id-ID')} = Rp ${dendaTerlambat.toLocaleString('id-ID')}</p>`;
    } else {
        infoHTML += `<p class="mb-1"><strong>Keterlambatan:</strong> <span class="text-success">Tidak ada (Tepat waktu ✓)</span></p>`;
    }
    
    if (dendaKerusakan > 0) {
        const jenisKerusakan = kondisi === 'rusak_ringan' ? 'Rusak Ringan' : 'Rusak Berat';
        const dendaPerUnit = kondisi === 'rusak_ringan' ? DENDA_RUSAK_RINGAN : DENDA_RUSAK_BERAT;
        infoHTML += `<p class="mb-1"><strong>Kerusakan (${jenisKerusakan}):</strong> ${jumlah} unit × Rp ${dendaPerUnit.toLocaleString('id-ID')} = Rp ${dendaKerusakan.toLocaleString('id-ID')}</p>`;
    }
    
    infoHTML += `<hr><h5 class="mb-0 ${totalDenda > 0 ? 'text-danger' : 'text-success'}">Total Denda: Rp ${totalDenda.toLocaleString('id-ID')}</h5>`;
    
    document.getElementById('dendaInfo').innerHTML = infoHTML;
}

// Hitung denda saat halaman load
window.addEventListener('load', hitungDenda);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjam/pengembalian/create.blade.php ENDPATH**/ ?>