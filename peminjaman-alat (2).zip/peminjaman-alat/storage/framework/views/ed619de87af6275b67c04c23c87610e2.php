

<?php $__env->startSection('title', 'Kelola Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Kelola Peminjaman'); ?>

<?php $__env->startSection('content'); ?>

<?php if(auth()->user()->role === 'peminjam'): ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('admin.peminjaman.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Ajukan Peminjaman
        </a>
    </div>
</div>
<?php endif; ?>

<!-- Tabs -->
<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button">
            Semua
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="menunggu-tab" data-bs-toggle="tab" data-bs-target="#menunggu" type="button">
            Menunggu <span class="badge bg-warning text-dark"><?php echo e($countMenunggu ?? 0); ?></span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="dipinjam-tab" data-bs-toggle="tab" data-bs-target="#dipinjam" type="button">
            Dipinjam <span class="badge bg-info"><?php echo e($countDipinjam ?? 0); ?></span>
        </button>
    </li>
</ul>

<!-- Tab Content -->
<div class="tab-content">
    <!-- Semua -->
    <div class="tab-pane fade show active" id="all" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->user->name ?? '-'); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                                    <td>
                                        <?php
                                            $badgeClass = match($p->status) {
                                                'menunggu' => 'bg-warning text-dark',
                                                'disetujui' => 'bg-success',
                                                'ditolak' => 'bg-danger',
                                                'dipinjam' => 'bg-info',
                                                'dikembalikan' => 'bg-secondary',
                                                default => 'bg-secondary'
                                            };
                                        ?>
                                        <span class="badge <?php echo e($badgeClass); ?>">
                                            <?php echo e(ucfirst($p->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <?php if(in_array(auth()->user()->role, ['admin', 'petugas']) && $p->status === 'menunggu'): ?>

                                                 <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-success" title="Setujui">
                                                    <i class="fas fa-check"></i>
                                                </button> 
                                            </form>
                                             
                                                 <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" title="Tolak">
                                                    <i class="fas fa-times"></i>
                                                </button> 
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Belum ada peminjaman</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <?php echo e($peminjamans->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <!-- Menunggu -->
    <div class="tab-pane fade" id="menunggu" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Keperluan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->user->name ?? '-'); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                    <td><?php echo e(Str::limit($p->keperluan, 50)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <?php if(in_array(auth()->user()->role, ['admin', 'petugas'])): ?>
                                             
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="fas fa-check"></i> Setujui
                                                </button>
                                            </form>
                                            
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-times"></i> Tolak
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">Tidak ada peminjaman yang menunggu</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Dipinjam -->
    <div class="tab-pane fade" id="dipinjam" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Sisa Hari</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $today = \Carbon\Carbon::now();
                                    $tglKembali = \Carbon\Carbon::parse($p->tanggal_kembali_rencana);
                                    $sisaHari = $today->diffInDays($tglKembali, false);
                                    $isOverdue = $sisaHari < 0;
                                ?>
                                <tr class="<?php echo e($isOverdue ? 'table-danger' : ''); ?>">
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->user->name ?? '-'); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($isOverdue ? 'danger' : 'success'); ?>">
                                            <?php echo e($isOverdue ? 'Terlambat ' . abs($sisaHari) : $sisaHari); ?> hari
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <?php if(in_array(auth()->user()->role, ['admin', 'petugas'])): ?>
                                            <a href="<?php echo e(route('admin.pengembalian.create', ['peminjaman_id' => $p->id])); ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-undo"></i> Kembalikan
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Tidak ada alat yang sedang dipinjam</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/peminjaman/index.blade.php ENDPATH**/ ?>