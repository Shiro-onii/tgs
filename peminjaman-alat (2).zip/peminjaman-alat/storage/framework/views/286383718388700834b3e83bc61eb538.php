<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 12px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #000;
            padding-bottom: 20px;
        }
        
        .header h1 {
            font-size: 20px;
            margin-bottom: 5px;
        }
        
        .header h2 {
            font-size: 16px;
            font-weight: normal;
            margin-bottom: 10px;
        }
        
        .info {
            margin-bottom: 20px;
        }
        
        .info p {
            margin: 5px 0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        table th,
        table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        
        table th {
            background-color: #f0f0f0;
            font-weight: bold;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-right {
            text-align: right;
        }
        
        .footer {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature {
            text-align: center;
            width: 200px;
        }
        
        .signature-line {
            margin-top: 60px;
            border-top: 1px solid #000;
            padding-top: 5px;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
        }
        
        .badge-warning {
            background-color: #ffc107;
            color: #000;
        }
        
        .badge-success {
            background-color: #28a745;
            color: #fff;
        }
        
        .badge-danger {
            background-color: #dc3545;
            color: #fff;
        }
        
        .badge-info {
            background-color: #17a2b8;
            color: #fff;
        }
        
        .badge-secondary {
            background-color: #6c757d;
            color: #fff;
        }
        
        @media print {
            .no-print {
                display: none;
            }
            
            body {
                padding: 0;
            }
        }
    </style>
</head>
<body>
    
    <!-- Header -->
    <div class="header">
        <h1>SISTEM PEMINJAMAN ALAT</h1>
        <h2><?php echo e($title); ?></h2>
        <p>Periode: <?php echo e(date('d/m/Y', strtotime($tanggal_mulai))); ?> s/d <?php echo e(date('d/m/Y', strtotime($tanggal_akhir))); ?></p>
    </div>
    
    <!-- Info -->
    <div class="info">
        <p><strong>Dicetak oleh:</strong> <?php echo e(auth()->user()->name); ?></p>
        <p><strong>Tanggal Cetak:</strong> <?php echo e(date('d/m/Y H:i:s')); ?></p>
        <p><strong>Total Data:</strong> <?php echo e($data->count()); ?> peminjaman</p>
    </div>
    
    <!-- Tabel Laporan -->
    <table>
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="12%">Kode</th>
                <th width="18%">Peminjam</th>
                <th width="20%">Alat</th>
                <th width="8%">Jumlah</th>
                <th width="12%">Tgl Pinjam</th>
                <th width="12%">Tgl Kembali</th>
                <th width="13%">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peminjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td><?php echo e($peminjaman->kode_peminjaman); ?></td>
                    <td><?php echo e($peminjaman->user->name ?? '-'); ?></td>
                    <td><?php echo e($peminjaman->alat->nama_alat ?? '-'); ?></td>
                    <td class="text-center"><?php echo e($peminjaman->jumlah_pinjam); ?></td>
                    <td class="text-center"><?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_pinjam))); ?></td>
                    <td class="text-center"><?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana))); ?></td>
                    <td class="text-center">
                        <?php
                            $badgeClass = match($peminjaman->status) {
                                'menunggu' => 'badge-warning',
                                'disetujui' => 'badge-success',
                                'ditolak' => 'badge-danger',
                                'dipinjam' => 'badge-info',
                                'dikembalikan' => 'badge-secondary',
                                default => 'badge-secondary'
                            };
                        ?>
                        <span class="badge <?php echo e($badgeClass); ?>">
                            <?php echo e(ucfirst($peminjaman->status)); ?>

                        </span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">Tidak ada data</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <!-- Summary -->
    <div style="margin-bottom: 30px;">
        <h3>Ringkasan</h3>
        <table style="width: 50%;">
            <tr>
                <td><strong>Status Menunggu:</strong></td>
                <td class="text-right"><?php echo e($data->where('status', 'menunggu')->count()); ?></td>
            </tr>
            <tr>
                <td><strong>Status Disetujui:</strong></td>
                <td class="text-right"><?php echo e($data->where('status', 'disetujui')->count()); ?></td>
            </tr>
            <tr>
                <td><strong>Status Dipinjam:</strong></td>
                <td class="text-right"><?php echo e($data->where('status', 'dipinjam')->count()); ?></td>
            </tr>
            <tr>
                <td><strong>Status Dikembalikan:</strong></td>
                <td class="text-right"><?php echo e($data->where('status', 'dikembalikan')->count()); ?></td>
            </tr>
            <tr>
                <td><strong>Status Ditolak:</strong></td>
                <td class="text-right"><?php echo e($data->where('status', 'ditolak')->count()); ?></td>
            </tr>
            <tr style="border-top: 2px solid #000;">
                <td><strong>Total:</strong></td>
                <td class="text-right"><strong><?php echo e($data->count()); ?></strong></td>
            </tr>
        </table>
    </div>
    
    <!-- Footer / Signature -->
    <div class="footer">
        <div class="signature">
            <p>Mengetahui,</p>
            <div class="signature-line">
                <p>Kepala Unit</p>
            </div>
        </div>
        
        <div class="signature">
            <p><?php echo e(date('d/m/Y')); ?></p>
            <p>Petugas,</p>
            <div class="signature-line">
                <p><?php echo e(auth()->user()->name); ?></p>
            </div>
        </div>
    </div>
    
    <!-- Print Button -->
    <div class="no-print" style="text-align: center; margin-top: 30px;">
        <button onclick="window.print()" style="padding: 10px 30px; font-size: 14px; cursor: pointer; background: #007bff; color: white; border: none; border-radius: 5px;">
            <i class="fas fa-print"></i> Cetak Laporan
        </button>
        <button onclick="window.close()" style="padding: 10px 30px; font-size: 14px; cursor: pointer; background: #6c757d; color: white; border: none; border-radius: 5px; margin-left: 10px;">
            Tutup
        </button>
    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/laporan/peminjaman.blade.php ENDPATH**/ ?>