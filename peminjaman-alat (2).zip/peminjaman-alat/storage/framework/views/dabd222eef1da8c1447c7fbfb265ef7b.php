

<?php $__env->startSection('title', 'Ajukan Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Ajukan Peminjaman Alat'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Pengajuan Peminjaman</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('peminjam.peminjaman.store')); ?>" method="POST" id="formPeminjaman">
                    <?php echo csrf_field(); ?>
                    
                    <div class="mb-3">
                        <label for="alat_id" class="form-label">Pilih Alat <span class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['alat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="alat_id" name="alat_id" required onchange="updateStokInfo()">
                            <option value="">-- Pilih Alat --</option>
                            <?php $__currentLoopData = $alats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($alat->id); ?>" 
                                        data-stok="<?php echo e($alat->jumlah_tersedia); ?>"
                                        <?php echo e(old('alat_id', request('alat_id')) == $alat->id ? 'selected' : ''); ?>>
                                    <?php echo e($alat->nama_alat); ?> - <?php echo e($alat->kode_alat); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small id="stokInfo" class="text-muted"></small>
                        <?php $__errorArgs = ['alat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="jumlah_pinjam" class="form-label">Jumlah <span class="text-danger">*</span></label>
                                <input type="number" class="form-control <?php $__errorArgs = ['jumlah_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="jumlah_pinjam" name="jumlah_pinjam" value="<?php echo e(old('jumlah_pinjam', 1)); ?>" min="1" required>
                                <?php $__errorArgs = ['jumlah_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pinjam" class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_pinjam" name="tanggal_pinjam" value="<?php echo e(old('tanggal_pinjam', date('Y-m-d'))); ?>" 
                                       min="<?php echo e(date('Y-m-d')); ?>" required>
                                <?php $__errorArgs = ['tanggal_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_kembali_rencana" class="form-label">Tanggal Kembali <span class="text-danger">*</span></label>
                        <input type="date" class="form-control <?php $__errorArgs = ['tanggal_kembali_rencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="tanggal_kembali_rencana" name="tanggal_kembali_rencana" value="<?php echo e(old('tanggal_kembali_rencana')); ?>" 
                               min="<?php echo e(date('Y-m-d', strtotime('+1 day'))); ?>" required>
                        <?php $__errorArgs = ['tanggal_kembali_rencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="keperluan" class="form-label">Keperluan <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['keperluan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="keperluan" name="keperluan" rows="4" required placeholder="Jelaskan untuk keperluan apa alat ini dipinjam..."><?php echo e(old('keperluan')); ?></textarea>
                        <?php $__errorArgs = ['keperluan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Catatan Penting:</strong>
                        <ul class="mb-0 mt-2">
                            <li>Pastikan tanggal pengembalian sesuai kebutuhan</li>
                            <li>Keterlambatan dikenakan denda <strong>Rp 10.000/hari</strong></li>
                            <li>Kerusakan dikenakan denda tambahan</li>
                            <li>Peminjaman akan diproses setelah disetujui petugas</li>
                        </ul>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i> Ajukan Peminjaman
                        </button>
                        <a href="<?php echo e(route('peminjam.alat.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-question-circle me-2"></i> Panduan</h6>
            </div>
            <div class="card-body">
                <h6>Langkah Peminjaman:</h6>
                <ol class="mb-3">
                    <li>Pilih alat yang ingin dipinjam</li>
                    <li>Tentukan jumlah dan tanggal</li>
                    <li>Isi keperluan dengan jelas</li>
                    <li>Tunggu persetujuan dari petugas</li>
                    <li>Ambil alat setelah disetujui</li>
                </ol>

                <h6>Denda:</h6>
                <ul class="mb-0 small">
                    <li>Terlambat: Rp 10.000/hari</li>
                    <li>Rusak Ringan: Rp 50.000</li>
                    <li>Rusak Berat: Rp 200.000</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateStokInfo() {
    const select = document.getElementById('alat_id');
    const selected = select.options[select.selectedIndex];
    const stok = selected.getAttribute('data-stok');
    const jumlahInput = document.getElementById('jumlah_pinjam');
    
    if (stok) {
        document.getElementById('stokInfo').textContent = `Stok tersedia: ${stok}`;
        jumlahInput.max = stok;
    } else {
        document.getElementById('stokInfo').textContent = '';
        jumlahInput.max = '';
    }
}

// Set minimum date for tanggal kembali
document.getElementById('tanggal_pinjam').addEventListener('change', function() {
    const tglPinjam = new Date(this.value);
    tglPinjam.setDate(tglPinjam.getDate() + 1);
    const minDate = tglPinjam.toISOString().split('T')[0];
    document.getElementById('tanggal_kembali_rencana').min = minDate;
});

// Init on load
window.addEventListener('load', updateStokInfo);
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjam/peminjaman/create.blade.php ENDPATH**/ ?>