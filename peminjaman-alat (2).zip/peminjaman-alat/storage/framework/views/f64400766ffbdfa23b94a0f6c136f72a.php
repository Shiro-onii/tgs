

<?php $__env->startSection('title', 'Cetak Laporan'); ?>
<?php $__env->startSection('page-title', 'Cetak Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Cetak Laporan</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('petugas.laporan.cetak')); ?>" method="POST" target="_blank">
                    <?php echo csrf_field(); ?>
                    
                    <div class="mb-3">
                        <label for="jenis" class="form-label">Jenis Laporan <span class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="jenis" name="jenis" required>
                            <option value="">-- Pilih Jenis Laporan --</option>
                            <option value="peminjaman">Laporan Peminjaman</option>
                            <option value="pengembalian">Laporan Pengembalian</option>
                        </select>
                        <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_mulai" class="form-label">Tanggal Mulai <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_mulai" name="tanggal_mulai" required>
                                <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_akhir" class="form-label">Tanggal Akhir <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_akhir" name="tanggal_akhir" required>
                                <?php $__errorArgs = ['tanggal_akhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-print me-2"></i> Cetak Laporan
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i> Informasi</h6>
            </div>
            <div class="card-body">
                <h6>Laporan Peminjaman</h6>
                <p class="small text-muted">Menampilkan data peminjaman alat berdasarkan tanggal peminjaman</p>

                <h6>Laporan Pengembalian</h6>
                <p class="small text-muted mb-0">Menampilkan data pengembalian alat beserta denda berdasarkan tanggal pengembalian</p>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i> Quick Stats</h6>
            </div>
            <div class="card-body">
                <p class="mb-2"><small><strong>Total Peminjaman Bulan Ini:</strong></small></p>
                <h4 class="text-primary"><?php echo e(\App\Models\Peminjaman::whereMonth('tanggal_pinjam', date('m'))->count()); ?></h4>
                
                <hr>
                
                <p class="mb-2 mt-3"><small><strong>Total Pengembalian Bulan Ini:</strong></small></p>
                <h4 class="text-success"><?php echo e(\App\Models\Pengembalian::whereMonth('tanggal_pengembalian', date('m'))->count()); ?></h4>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/laporan/index.blade.php ENDPATH**/ ?>