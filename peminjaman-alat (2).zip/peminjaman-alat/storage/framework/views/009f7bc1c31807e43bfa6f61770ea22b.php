

<?php $__env->startSection('title', 'Tambah Pengembalian'); ?>
<?php $__env->startSection('page-title', 'Tambah Data Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Tambah Pengembalian</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.pengembalian.store')); ?>" method="POST" id="formPengembalian">
                    <?php echo csrf_field(); ?>
                    
                    <div class="mb-3">
                        <label for="peminjaman_id" class="form-label">Pilih Peminjaman <span class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['peminjaman_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="peminjaman_id" name="peminjaman_id" required onchange="loadPeminjamanInfo()">
                            <option value="">-- Pilih Peminjaman --</option>
                            <?php $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pem->id); ?>" 
                                        data-kode="<?php echo e($pem->kode_peminjaman); ?>"
                                        data-user="<?php echo e($pem->user->name); ?>"
                                        data-alat="<?php echo e($pem->alat->nama_alat); ?>"
                                        data-jumlah="<?php echo e($pem->jumlah_pinjam); ?>"
                                        data-tgl-rencana="<?php echo e($pem->tanggal_kembali_rencana); ?>"
                                        <?php echo e(old('peminjaman_id') == $pem->id ? 'selected' : ''); ?>>
                                    <?php echo e($pem->kode_peminjaman); ?> - <?php echo e($pem->user->name); ?> (<?php echo e($pem->alat->nama_alat); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['peminjaman_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div id="peminjamanInfo" class="alert alert-info d-none mb-3">
                        <h6 class="alert-heading">Info Peminjaman</h6>
                        <p class="mb-0" id="infoText"></p>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="jumlah_dikembalikan" class="form-label">Jumlah Dikembalikan <span class="text-danger">*</span></label>
                                <input type="number" class="form-control <?php $__errorArgs = ['jumlah_dikembalikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="jumlah_dikembalikan" name="jumlah_dikembalikan" value="<?php echo e(old('jumlah_dikembalikan', 1)); ?>" min="1" required>
                                <?php $__errorArgs = ['jumlah_dikembalikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pengembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_pengembalian" name="tanggal_pengembalian" value="<?php echo e(old('tanggal_pengembalian', date('Y-m-d'))); ?>" required>
                                <?php $__errorArgs = ['tanggal_pengembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="kondisi_alat" class="form-label">Kondisi Alat <span class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['kondisi_alat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        id="kondisi_alat" name="kondisi_alat" required>
                                    <option value="baik" <?php echo e(old('kondisi_alat') == 'baik' ? 'selected' : ''); ?>>Baik</option>
                                    <option value="rusak_ringan" <?php echo e(old('kondisi_alat') == 'rusak_ringan' ? 'selected' : ''); ?>>Rusak Ringan</option>
                                    <option value="rusak_berat" <?php echo e(old('kondisi_alat') == 'rusak_berat' ? 'selected' : ''); ?>>Rusak Berat</option>
                                </select>
                                <?php $__errorArgs = ['kondisi_alat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="keterangan" name="keterangan" rows="3"><?php echo e(old('keterangan')); ?></textarea>
                        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Simpan
                        </button>
                        <a href="<?php echo e(route('admin.pengembalian.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function loadPeminjamanInfo() {
    const select = document.getElementById('peminjaman_id');
    const selected = select.options[select.selectedIndex];
    
    if (selected.value) {
        const info = `
            <strong>Kode:</strong> ${selected.dataset.kode} | 
            <strong>Peminjam:</strong> ${selected.dataset.user} | 
            <strong>Alat:</strong> ${selected.dataset.alat} | 
            <strong>Jumlah:</strong> ${selected.dataset.jumlah} | 
            <strong>Tgl Kembali Rencana:</strong> ${selected.dataset.tglRencana}
        `;
        document.getElementById('infoText').innerHTML = info;
        document.getElementById('peminjamanInfo').classList.remove('d-none');
        document.getElementById('jumlah_dikembalikan').max = selected.dataset.jumlah;
    } else {
        document.getElementById('peminjamanInfo').classList.add('d-none');
    }
}

window.addEventListener('load', loadPeminjamanInfo);
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/pengembalian/create.blade.php ENDPATH**/ ?>