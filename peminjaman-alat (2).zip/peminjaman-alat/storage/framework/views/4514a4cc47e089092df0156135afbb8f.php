

<?php $__env->startSection('title', 'Kelola User'); ?>
<?php $__env->startSection('page-title', 'Kelola User'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah User
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="20%">Nama</th>
                        <th width="20%">Email</th>
                        <th width="10%">Role</th>
                        <th width="15%">Phone</th>
                        <th width="20%">Alamat</th>
                        <th width="10%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($users->firstItem() + $index); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php
                                    $badgeClass = match($user->role) {
                                        'admin' => 'bg-danger',
                                        'petugas' => 'bg-warning text-dark',
                                        'peminjam' => 'bg-primary',
                                        default => 'bg-secondary'
                                    };
                                ?>
                                <span class="badge <?php echo e($badgeClass); ?>">
                                    <?php echo e(ucfirst($user->role)); ?>

                                </span>
                            </td>
                            <td><?php echo e($user->phone ?? '-'); ?></td>
                            <td><?php echo e(Str::limit($user->address ?? '-', 30)); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.user.edit', $user->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if($user->id !== auth()->id() && $user->role !== 'admin'): ?>
                                    <form action="<?php echo e(route('admin.user.destroy', $user->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus user ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                <?php elseif($user->role === 'admin'): ?>
                                    <button class="btn btn-sm btn-secondary" disabled title="Admin tidak bisa dihapus">
                                        <i class="fas fa-lock"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                <i class="fas fa-users fa-3x mb-3 d-block"></i>
                                Belum ada user
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($users->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/user/index.blade.php ENDPATH**/ ?>