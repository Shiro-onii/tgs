

<?php $__env->startSection('title', 'Log Aktivitas'); ?>
<?php $__env->startSection('page-title', 'Log Aktivitas Sistem'); ?>

<?php $__env->startSection('content'); ?>

<!-- Filter -->
<div class="card mb-3">
    <div class="card-body">
        <form action="<?php echo e(route('admin.logs.index')); ?>" method="GET">
            <div class="row">
                <div class="col-md-3 mb-2">
                    <input type="text" name="activity" class="form-control" placeholder="Cari aktivitas..." value="<?php echo e(request('activity')); ?>">
                </div>
                <div class="col-md-3 mb-2">
                    <input type="date" name="start_date" class="form-control" placeholder="Tanggal Mulai" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-3 mb-2">
                    <input type="date" name="end_date" class="form-control" placeholder="Tanggal Akhir" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="col-md-3 mb-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="15%">Waktu</th>
                        <th width="15%">User</th>
                        <th width="20%">Aktivitas</th>
                        <th width="35%">Deskripsi</th>
                        <th width="15%">IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <small><?php echo e($log->created_at->format('d/m/Y H:i')); ?></small>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="user-avatar me-2" style="width: 30px; height: 30px; font-size: 12px;">
                                        <?php echo e($log->user ? strtoupper(substr($log->user->name, 0, 1)) : 'S'); ?>

                                    </div>
                                    <div>
                                        <small class="fw-bold"><?php echo e($log->user ? $log->user->name : 'System'); ?></small><br>
                                        <small class="text-muted"><?php echo e($log->user ? ucfirst($log->user->role) : '-'); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php
                                    $badgeClass = match(true) {
                                        str_contains($log->activity, 'LOGIN') => 'bg-success',
                                        str_contains($log->activity, 'LOGOUT') => 'bg-secondary',
                                        str_contains($log->activity, 'CREATE') => 'bg-primary',
                                        str_contains($log->activity, 'UPDATE') => 'bg-warning text-dark',
                                        str_contains($log->activity, 'DELETE') => 'bg-danger',
                                        str_contains($log->activity, 'APPROVE') => 'bg-info',
                                        str_contains($log->activity, 'REJECT') => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                ?>
                                <span class="badge <?php echo e($badgeClass); ?>">
                                    <?php echo e(str_replace('_', ' ', $log->activity)); ?>

                                </span>
                            </td>
                            <td><small><?php echo e($log->description); ?></small></td>
                            <td><small class="text-muted"><?php echo e($log->ip_address ?? '-'); ?></small></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-5">
                                <i class="fas fa-history fa-3x mb-3 d-block"></i>
                                Belum ada log aktivitas
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($logs->links()); ?>

        </div>
    </div>
</div>

<div class="row mt-3">
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-0"><?php echo e($stats['total'] ?? 0); ?></h3>
                <small class="text-muted">Total Log</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-0"><?php echo e($stats['today'] ?? 0); ?></h3>
                <small class="text-muted">Hari Ini</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-0"><?php echo e($stats['week'] ?? 0); ?></h3>
                <small class="text-muted">7 Hari Terakhir</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card">
            <div class="card-body text-center">
                <h3 class="mb-0"><?php echo e($stats['month'] ?? 0); ?></h3>
                <small class="text-muted">30 Hari Terakhir</small>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/logs/index.blade.php ENDPATH**/ ?>