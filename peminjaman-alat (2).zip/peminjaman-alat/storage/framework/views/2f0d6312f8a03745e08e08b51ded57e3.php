

<?php $__env->startSection('title', 'Edit Pengembalian'); ?>
<?php $__env->startSection('page-title', 'Edit Data Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Edit Pengembalian</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.pengembalian.update', $pengembalian->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Kode Peminjaman</label>
                        <input type="text" class="form-control" value="<?php echo e($pengembalian->peminjaman->kode_peminjaman); ?>" readonly>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Peminjam</label>
                            <input type="text" class="form-control" value="<?php echo e($pengembalian->peminjaman->user->name); ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Alat</label>
                            <input type="text" class="form-control" value="<?php echo e($pengembalian->peminjaman->alat->nama_alat); ?>" readonly>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian <span class="text-danger">*</span></label>
                        <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pengembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="tanggal_pengembalian" name="tanggal_pengembalian" 
                               value="<?php echo e(old('tanggal_pengembalian', $pengembalian->tanggal_pengembalian)); ?>" required>
                        <?php $__errorArgs = ['tanggal_pengembalian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="kondisi_alat" class="form-label">Kondisi Alat <span class="text-danger">*</span></label>
                        <select class="form-select <?php $__errorArgs = ['kondisi_alat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="kondisi_alat" name="kondisi_alat" required>
                            <option value="baik" <?php echo e(old('kondisi_alat', $pengembalian->kondisi_alat) == 'baik' ? 'selected' : ''); ?>>Baik</option>
                            <option value="rusak_ringan" <?php echo e(old('kondisi_alat', $pengembalian->kondisi_alat) == 'rusak_ringan' ? 'selected' : ''); ?>>Rusak Ringan</option>
                            <option value="rusak_berat" <?php echo e(old('kondisi_alat', $pengembalian->kondisi_alat) == 'rusak_berat' ? 'selected' : ''); ?>>Rusak Berat</option>
                        </select>
                        <?php $__errorArgs = ['kondisi_alat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="denda" class="form-label">Denda (Rp) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control <?php $__errorArgs = ['denda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="denda" name="denda" value="<?php echo e(old('denda', $pengembalian->denda)); ?>" min="0" required>
                        <?php $__errorArgs = ['denda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="keterangan" name="keterangan" rows="3"><?php echo e(old('keterangan', $pengembalian->keterangan)); ?></textarea>
                        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update
                        </button>
                        <a href="<?php echo e(route('admin.pengembalian.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/pengembalian/edit.blade.php ENDPATH**/ ?>