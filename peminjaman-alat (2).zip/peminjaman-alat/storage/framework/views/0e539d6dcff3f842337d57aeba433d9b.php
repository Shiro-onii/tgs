

<?php $__env->startSection('title', 'Peminjaman Saya'); ?>
<?php $__env->startSection('page-title', 'Riwayat Peminjaman Saya'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('peminjam.peminjaman.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Ajukan Peminjaman
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Alat</th>
                        <th>Jumlah</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($p->kode_peminjaman); ?></td>
                            <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                            <td><?php echo e($p->jumlah_pinjam); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                            <td>
                                <?php
                                    $badgeClass = match($p->status) {
                                        'menunggu' => 'bg-warning text-dark',
                                        'disetujui' => 'bg-success',
                                        'ditolak' => 'bg-danger',
                                        'dipinjam' => 'bg-info',
                                        'dikembalikan' => 'bg-secondary',
                                        default => 'bg-secondary'
                                    };
                                ?>
                                <span class="badge <?php echo e($badgeClass); ?>">
                                    <?php echo e(ucfirst($p->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('peminjam.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if(in_array($p->status, ['disetujui', 'dipinjam'])): ?>
                                    <a href="<?php echo e(route('peminjam.pengembalian.create', ['peminjaman_id' => $p->id])); ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-undo"></i> Kembalikan
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada riwayat peminjaman
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($peminjamans->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjam/peminjaman/index.blade.php ENDPATH**/ ?>