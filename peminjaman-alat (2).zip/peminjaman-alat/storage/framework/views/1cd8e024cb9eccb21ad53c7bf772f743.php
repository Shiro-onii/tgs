

<?php $__env->startSection('title', 'Kelola Kategori'); ?>
<?php $__env->startSection('page-title', 'Kelola Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Kategori
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="25%">Nama Kategori</th>
                        <th width="45%">Deskripsi</th>
                        <th width="10%">Jumlah Alat</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($kategoris->firstItem() + $index); ?></td>
                            <td><?php echo e($kategori->nama_kategori); ?></td>
                            <td><?php echo e($kategori->deskripsi ?? '-'); ?></td>
                            <td>
                                <span class="badge bg-primary">
                                    <?php echo e($kategori->alat_count ?? 0); ?> alat
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('kategori.edit', $kategori->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('kategori.destroy', $kategori->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus kategori ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada kategori
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($kategoris->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/kategori/index.blade.php ENDPATH**/ ?>