

<?php $__env->startSection('title', 'Kelola Alat'); ?>
<?php $__env->startSection('page-title', 'Kelola Alat'); ?>

<?php $__env->startSection('content'); ?>

<!-- Filter & Search -->
<div class="card mb-3">
    <div class="card-body">
        <form action="<?php echo e(route('admin.alat.index')); ?>" method="GET">
            <div class="row">
                <div class="col-md-4 mb-2">
                    <input type="text" name="search" class="form-control" placeholder="Cari alat..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-3 mb-2">
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kat->id); ?>" <?php echo e(request('kategori') == $kat->id ? 'selected' : ''); ?>>
                                <?php echo e($kat->nama_kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <select name="kondisi" class="form-select">
                        <option value="">Semua Kondisi</option>
                        <option value="baik" <?php echo e(request('kondisi') == 'baik' ? 'selected' : ''); ?>>Baik</option>
                        <option value="rusak_ringan" <?php echo e(request('kondisi') == 'rusak_ringan' ? 'selected' : ''); ?>>Rusak Ringan</option>
                        <option value="rusak_berat" <?php echo e(request('kondisi') == 'rusak_berat' ? 'selected' : ''); ?>>Rusak Berat</option>
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if(in_array(auth()->user()->role, ['admin', 'petugas'])): ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('admin.alat.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Alat
        </a>
    </div>
</div>
<?php endif; ?>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $alats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <?php if($alat->foto): ?>
                    <img src="<?php echo e(asset('storage/' . $alat->foto)); ?>" class="card-img-top" alt="<?php echo e($alat->nama_alat); ?>" style="height: 200px; object-fit: cover;">
                <?php else: ?>
                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-tools fa-4x text-muted"></i>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($alat->nama_alat); ?></h5>
                    <p><?php echo e($alat->kategori->nama_kategori ?? '-'); ?> - <?php echo e(ucfirst(str_replace('_', ' ', $alat->kondisi))); ?></p>
                    <p>Merk: <?php echo e($alat->merk ?? '-'); ?></p>
                    <p>Jumlah tersedia: <?php echo e($alat->jumlah_tersedia); ?>/<?php echo e($alat->jumlah_total); ?></p>

                    <a href="<?php echo e(route('admin.alat.edit', $alat->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <?php if(auth()->user()->role === 'admin'): ?>
                        <form action="<?php echo e(route('admin.alat.destroy', $alat->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus alat ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Belum ada alat</p>
    <?php endif; ?>
</div>

<div class="mt-3">
    <?php echo e($alats->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/alat/index.blade.php ENDPATH**/ ?>