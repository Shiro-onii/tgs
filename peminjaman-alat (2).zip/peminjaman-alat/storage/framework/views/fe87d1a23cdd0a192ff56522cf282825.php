

<?php $__env->startSection('title', 'Detail Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Detail Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Detail Peminjaman #<?php echo e($peminjaman->kode_peminjaman); ?></h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="text-muted">Kode Peminjaman</h6>
                        <p class="mb-0 fw-bold"><?php echo e($peminjaman->kode_peminjaman); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Status</h6>
                        <?php
                            $badgeClass = match($peminjaman->status) {
                                'menunggu' => 'bg-warning text-dark',
                                'disetujui' => 'bg-success',
                                'ditolak' => 'bg-danger',
                                'dipinjam' => 'bg-info',
                                'dikembalikan' => 'bg-secondary',
                                default => 'bg-secondary'
                            };
                        ?>
                        <span class="badge <?php echo e($badgeClass); ?> fs-6"><?php echo e(ucfirst($peminjaman->status)); ?></span>
                    </div>
                </div>

                <hr>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="text-muted">Peminjam</h6>
                        <p class="mb-0"><?php echo e($peminjaman->user->name ?? '-'); ?></p>
                        <small class="text-muted"><?php echo e($peminjaman->user->email ?? '-'); ?></small>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Alat</h6>
                        <p class="mb-0"><?php echo e($peminjaman->alat->nama_alat ?? '-'); ?></p>
                        <small class="text-muted"><?php echo e($peminjaman->alat->kode_alat ?? '-'); ?></small>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <h6 class="text-muted">Jumlah Pinjam</h6>
                        <p class="mb-0"><?php echo e($peminjaman->jumlah_pinjam); ?> unit</p>
                    </div>
                    <div class="col-md-4">
                        <h6 class="text-muted">Tanggal Pinjam</h6>
                        <p class="mb-0"><?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_pinjam))); ?></p>
                    </div>
                    <div class="col-md-4">
                        <h6 class="text-muted">Tanggal Kembali (Rencana)</h6>
                        <p class="mb-0"><?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana))); ?></p>
                    </div>
                </div>

                <?php if($peminjaman->tanggal_kembali_aktual): ?>
                    <div class="mb-3">
                        <h6 class="text-muted">Tanggal Kembali (Aktual)</h6>
                        <p class="mb-0"><?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_kembali_aktual))); ?></p>
                    </div>
                <?php endif; ?>

                <div class="mb-3">
                    <h6 class="text-muted">Keperluan</h6>
                    <p class="mb-0"><?php echo e($peminjaman->keperluan); ?></p>
                </div>

                <?php if($peminjaman->catatan_petugas): ?>
                    <div class="mb-3">
                        <h6 class="text-muted">Catatan Petugas</h6>
                        <p class="mb-0"><?php echo e($peminjaman->catatan_petugas); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($peminjaman->disetujui_oleh): ?>
                    <div class="mb-3">
                        <h6 class="text-muted">Disetujui Oleh</h6>
                        <p class="mb-0"><?php echo e($peminjaman->petugas->name ?? '-'); ?></p>
                    </div>
                <?php endif; ?>

                <hr>

                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('admin.peminjaman.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                    <a href="<?php echo e(route('admin.peminjaman.edit', $peminjaman->id)); ?>" class="btn btn-warning">
                        <i class="fas fa-edit me-2"></i> Edit
                    </a>
                    <?php if(!in_array($peminjaman->status, ['disetujui', 'dipinjam'])): ?>
                        <form action="<?php echo e(route('admin.peminjaman.destroy', $peminjaman->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash me-2"></i> Hapus
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <?php if($peminjaman->alat): ?>
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Informasi Alat</h6>
                </div>
                <div class="card-body">
                    <?php if($peminjaman->alat->foto): ?>
                        <img src="<?php echo e(asset('storage/' . $peminjaman->alat->foto)); ?>" class="img-fluid rounded mb-3" alt="<?php echo e($peminjaman->alat->nama_alat); ?>">
                    <?php endif; ?>
                    <h6><?php echo e($peminjaman->alat->nama_alat); ?></h6>
                    <p class="text-muted small mb-2"><?php echo e($peminjaman->alat->kode_alat); ?></p>
                    <?php if($peminjaman->alat->spesifikasi): ?>
                        <p class="small mb-0"><?php echo e($peminjaman->alat->spesifikasi); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjam/peminjaman/show.blade.php ENDPATH**/ ?>