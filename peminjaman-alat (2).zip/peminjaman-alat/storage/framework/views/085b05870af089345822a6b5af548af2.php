

<?php $__env->startSection('title', 'Kelola Pengembalian'); ?>
<?php $__env->startSection('page-title', 'Kelola Pengembalian'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode Peminjaman</th>
                        <th>Peminjam</th>
                        <th>Alat</th>
                        <th>Tgl Pengembalian</th>
                        <th>Kondisi</th>
                        <th>Denda</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pengembalians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengembalian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($pengembalian->peminjaman->kode_peminjaman ?? '-'); ?></td>
                            <td><?php echo e($pengembalian->peminjaman->user->name ?? '-'); ?></td>
                            <td><?php echo e($pengembalian->peminjaman->alat->nama_alat ?? '-'); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($pengembalian->tanggal_pengembalian))); ?></td>
                            <td>
                                <?php
                                    $kondisiBadge = match($pengembalian->kondisi_alat) {
                                        'baik' => 'bg-success',
                                        'rusak_ringan' => 'bg-warning text-dark',
                                        'rusak_berat' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                ?>
                                <span class="badge <?php echo e($kondisiBadge); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $pengembalian->kondisi_alat))); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($pengembalian->denda > 0 ? 'danger' : 'success'); ?>">
                                    Rp <?php echo e(number_format($pengembalian->denda, 0, ',', '.')); ?>

                                </span>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($pengembalian->id); ?>">
                                    <i class="fas fa-eye"></i> Detail
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <div class="modal fade" id="detailModal<?php echo e($pengembalian->id); ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Detail Pengembalian</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-borderless">
                                            <tr>
                                                <th width="40%">Kode Peminjaman</th>
                                                <td><?php echo e($pengembalian->peminjaman->kode_peminjaman ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Peminjam</th>
                                                <td><?php echo e($pengembalian->peminjaman->user->name ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Alat</th>
                                                <td><?php echo e($pengembalian->peminjaman->alat->nama_alat ?? '-'); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Jumlah Dikembalikan</th>
                                                <td><?php echo e($pengembalian->jumlah_dikembalikan); ?> unit</td>
                                            </tr>
                                            <tr>
                                                <th>Tanggal Pengembalian</th>
                                                <td><?php echo e(date('d/m/Y', strtotime($pengembalian->tanggal_pengembalian))); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Kondisi Alat</th>
                                                <td>
                                                    <span class="badge <?php echo e($kondisiBadge); ?>">
                                                        <?php echo e(ucfirst(str_replace('_', ' ', $pengembalian->kondisi_alat))); ?>

                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Denda</th>
                                                <td class="fw-bold text-<?php echo e($pengembalian->denda > 0 ? 'danger' : 'success'); ?>">
                                                    Rp <?php echo e(number_format($pengembalian->denda, 0, ',', '.')); ?>

                                                </td>
                                            </tr>
                                            <?php if($pengembalian->keterangan): ?>
                                                <tr>
                                                    <th>Keterangan</th>
                                                    <td><?php echo e($pengembalian->keterangan); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <th>Diterima Oleh</th>
                                                <td><?php echo e($pengembalian->petugas->name ?? '-'); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada pengembalian
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($pengembalians->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/pengembalian/index.blade.php ENDPATH**/ ?>