

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Stats Cards -->
    <?php if(in_array(auth()->user()->role, ['admin', 'petugas'])): ?>
        <!-- Admin & Petugas Stats -->
        <div class="col-md-3 mb-4">
            <div class="card stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Alat</h6>
                            <h2 class="mb-0"><?php echo e($totalAlat ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(37, 99, 235, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-tools fa-2x" style="color: #2563eb;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card stat-card" style="border-left-color: #10b981;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total User</h6>
                            <h2 class="mb-0"><?php echo e($totalUser ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(16, 185, 129, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-users fa-2x" style="color: #10b981;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card stat-card" style="border-left-color: #f59e0b;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Sedang Dipinjam</h6>
                            <h2 class="mb-0"><?php echo e($peminjamanAktif ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(245, 158, 11, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-exchange-alt fa-2x" style="color: #f59e0b;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card stat-card" style="border-left-color: #ef4444;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Menunggu Approve</h6>
                            <h2 class="mb-0"><?php echo e($menungguApprove ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(239, 68, 68, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-clock fa-2x" style="color: #ef4444;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- Peminjam Stats -->
        <div class="col-md-3 mb-4">
            <div class="card stat-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Alat Tersedia</h6>
                            <h2 class="mb-0"><?php echo e($alatTersedia ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(37, 99, 235, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-tools fa-2x" style="color: #2563eb;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card stat-card" style="border-left-color: #f59e0b;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Sedang Dipinjam</h6>
                            <h2 class="mb-0"><?php echo e($myPeminjamanAktif ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(245, 158, 11, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-exchange-alt fa-2x" style="color: #f59e0b;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card stat-card" style="border-left-color: #ef4444;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Menunggu Approve</h6>
                            <h2 class="mb-0"><?php echo e($myMenungguApprove ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(239, 68, 68, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-clock fa-2x" style="color: #ef4444;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card stat-card" style="border-left-color: #10b981;">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-muted mb-2">Total Peminjaman</h6>
                            <h2 class="mb-0"><?php echo e($myTotalPeminjaman ?? 0); ?></h2>
                        </div>
                        <div style="width: 60px; height: 60px; background: rgba(16, 185, 129, 0.1); border-radius: 15px; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-check-circle fa-2x" style="color: #10b981;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="row">
    <!-- Recent Peminjaman -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-clock me-2"></i> Peminjaman Terbaru</h5>
            </div>
            <div class="card-body">
                <?php if(isset($recentPeminjaman) && $recentPeminjaman->count() > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $recentPeminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($p->alat->nama_alat ?? '-'); ?></h6>
                                        <small class="text-muted">
                                            <?php echo e($p->user->name ?? '-'); ?> • <?php echo e($p->tanggal_pinjam); ?>

                                        </small>
                                    </div>
                                    <span class="badge bg-<?php echo e($p->status === 'menunggu' ? 'warning' : ($p->status === 'disetujui' ? 'success' : 'info')); ?>">
                                        <?php echo e(ucfirst($p->status)); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="<?php echo e(route('admin.peminjaman.index')); ?>" class="btn btn-sm btn-outline-primary">
                            Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center mb-0">Belum ada peminjaman</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Popular Alat / Quick Actions -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <?php if(auth()->user()->role === 'peminjam'): ?>
                        <i class="fas fa-fire me-2"></i> Alat Populer
                    <?php else: ?>
                        <i class="fas fa-tools me-2"></i> Alat Sering Dipinjam
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body">
                <?php if(isset($popularAlat) && $popularAlat->count() > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $popularAlat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item px-0">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($alat->nama_alat); ?></h6>
                                        <small class="text-muted"><?php echo e($alat->kode_alat); ?></small>
                                    </div>
                                    <div class="text-end">
                                        <span class="badge bg-primary">
                                            <?php echo e($alat->jumlah_total - $alat->jumlah_tersedia); ?> dipinjam
                                        </span>
                                        <br>
                                        <small class="text-muted">Tersedia: <?php echo e($alat->jumlah_tersedia); ?></small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="<?php echo e(route('admin.alat.index')); ?>" class="btn btn-sm btn-outline-primary">
                            Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center mb-0">Belum ada data</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if(auth()->user()->role === 'peminjam'): ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-hand-holding fa-3x text-primary mb-3"></i>
                <h4>Siap Meminjam Alat?</h4>
                <p class="text-muted">Lihat alat yang tersedia dan ajukan peminjaman dengan mudah!</p>
                <a href="<?php echo e(route('peminjam.alat.index')); ?>" class="btn btn-primary btn-lg">
                    <i class="fas fa-tools me-2"></i> Lihat Daftar Alat
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/dashboard.blade.php ENDPATH**/ ?>