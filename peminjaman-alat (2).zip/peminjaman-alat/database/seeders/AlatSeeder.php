<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Alat;

class AlatSeeder extends Seeder
{
    public function run(): void
    {
        $alats = [
            // Elektronik
            [
                'kode_alat' => 'PS001',
                'nama_alat' => 'Xbox Series X',
                'kategori_id' => 1,
                'merek' => '',
                'kondisi' => 'baik',
                'jumlah_total' => 50,
                'jumlah_tersedia' => 50,
                'spesifikasi' => 'Intel Core i7, RAM 16GB, SSD 512GB, RTX 3060',
            ]
            

        ];


        foreach ($alats as $alat) {
            Alat::create($alat);
        }
    }
}