<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Kategori;

class KategoriSeeder extends Seeder
{
    public function run(): void
    {
        $kategoris = [
            [
                'nama_kategori' => 'Elektronik',
                'deskripsi' => 'Peralatan elektronik seperti laptop, komputer, printer',
            ],
            [
                'nama_kategori' => 'Multimedia',
                'deskripsi' => 'Peralatan multimedia seperti kamera, proyektor, speaker',
            ],
            [
                'nama_kategori' => 'Olahraga',
                'deskripsi' => 'Peralatan olahraga seperti bola, net, raket',
            ],
            [
                'nama_kategori' => 'Laboratorium',
                'deskripsi' => 'Peralatan laboratorium seperti mikroskop, tabung reaksi',
            ],
            [
                'nama_kategori' => 'Perkakas',
                'deskripsi' => 'Perkakas seperti tang, obeng, bor',
            ],
        ];

        foreach ($kategoris as $kategori) {
            Kategori::create($kategori);
        }
    }
}