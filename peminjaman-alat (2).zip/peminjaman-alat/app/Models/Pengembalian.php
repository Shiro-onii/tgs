<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pengembalian extends Model
{
    use HasFactory;

    protected $table = 'pengembalian';

    protected $fillable = [
        'peminjaman_id',
        'tanggal_pengembalian',
        'kondisi_alat',
        'jumlah_dikembalikan',
        'denda',
        'keterangan',
        'diterima_oleh',
    ];

    protected $casts = [
        'tanggal_pengembalian' => 'date',
        'jumlah_dikembalikan' => 'integer',
        'denda' => 'decimal:2',
    ];

    /**
     * Relasi: Pengembalian milik satu Peminjaman
     */
    public function peminjaman()
    {
        return $this->belongsTo(Peminjaman::class, 'peminjaman_id', 'id');
    }

    /**
     * Relasi: Pengembalian diterima oleh satu User (petugas)
     */
    public function petugas()
    {
        return $this->belongsTo(User::class, 'diterima_oleh', 'id');
    }

    /**
     * Check apakah ada denda
     */
    public function hasDenda()
    {
        return $this->denda > 0;
    }
}