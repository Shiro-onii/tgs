<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Peminjaman extends Model
{
    use HasFactory;

    protected $table = 'peminjaman';

    protected $fillable = [
        'kode_peminjaman',
        'user_id',
        'alat_id',
        'jumlah_pinjam',
        'tanggal_pinjam',
        'tanggal_kembali_rencana',
        'tanggal_kembali_aktual',
        'keperluan',
        'status',
        'catatan_petugas',
        'disetujui_oleh',
    ];

    protected $casts = [
        'tanggal_pinjam' => 'date',
        'tanggal_kembali_rencana' => 'date',
        'tanggal_kembali_aktual' => 'date',
        'jumlah_pinjam' => 'integer',
    ];

    /**
     * Relasi: Peminjaman milik satu User (peminjam)
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    /**
     * Relasi: Peminjaman milik satu Alat
     */
    public function alat()
    {
        return $this->belongsTo(Alat::class, 'alat_id', 'id');
    }

    /**
     * Relasi: Peminjaman disetujui oleh satu User (petugas)
     */
    public function petugas()
    {
        return $this->belongsTo(User::class, 'disetujui_oleh', 'id');
    }

    /**
     * Relasi: Peminjaman punya satu Pengembalian
     */
    public function pengembalian()
    {
        return $this->hasOne(Pengembalian::class, 'peminjaman_id', 'id');
    }

    /**
     * Scope: Filter berdasarkan status
     */
    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope: Peminjaman yang menunggu persetujuan
     */
    public function scopeMenunggu($query)
    {
        return $query->where('status', 'menunggu');
    }

    /**
     * Scope: Peminjaman yang sedang dipinjam
     */
    public function scopeDipinjam($query)
    {
        return $query->where('status', 'dipinjam');
    }

    /**
     * Check apakah terlambat
     */
    public function isTerlambat()
    {
        if ($this->status === 'dipinjam') {
            return now()->isAfter($this->tanggal_kembali_rencana);
        }
        return false;
    }

    /**
     * Hitung durasi peminjaman (hari)
     */
    public function getDurasiAttribute()
    {
        return $this->tanggal_pinjam->diffInDays($this->tanggal_kembali_rencana);
    }
}