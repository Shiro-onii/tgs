<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kategori extends Model
{
    use HasFactory;
    //
    protected $table='kategori';
    protected $primaryKey = 'id';
    public $incrementing =true;
    protected $keyType = 'int';
    public $timestamps = true;
    protected $fillable = ['nama_kategori','deskripsi'];
    protected $hidden = [];
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' =>'datetime'
    ];

    public function alat(){
        return $this->hasMany(Alat::class, 'kategori_id','id');
    }
}
