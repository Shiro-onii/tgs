<?php

namespace App\Http\Controllers\Peminjam;

use App\Http\Controllers\Controller;
use App\Models\Peminjaman;
use App\Models\Alat;
use App\Models\ActivityLog;
use Illuminate\Http\Request;

class PeminjamanController extends Controller
{
    // Lihat peminjaman sendiri
    public function index()
    {
        $peminjamans = Peminjaman::with(['alat', 'petugas'])
            ->where('user_id', auth()->id())
            ->latest()
            ->paginate(10);

        return view('peminjam.peminjaman.index', compact('peminjamans'));
    }

    // Form ajukan peminjaman
    public function create()
    {
        $alats = Alat::where('jumlah_tersedia', '>', 0)->get();
        return view('peminjam.peminjaman.create', compact('alats'));
    }

    // Simpan peminjaman
    public function store(Request $request)
    {
        $validated = $request->validate([
            'alat_id' => 'required|exists:alat,id',
            'jumlah_pinjam' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date|after_or_equal:today',
            'tanggal_kembali_rencana' => 'required|date|after:tanggal_pinjam',
            'keperluan' => 'required|string',
        ], [
            'alat_id.required' => 'Alat wajib dipilih',
            'jumlah_pinjam.min' => 'Jumlah minimal 1',
            'tanggal_pinjam.after_or_equal' => 'Tanggal pinjam tidak boleh kurang dari hari ini',
            'tanggal_kembali_rencana.after' => 'Tanggal kembali harus setelah tanggal pinjam',
        ]);

        // Cek stok
        $alat = Alat::findOrFail($validated['alat_id']);
        if ($alat->jumlah_tersedia < $validated['jumlah_pinjam']) {
            return back()->withErrors([
                'jumlah_pinjam' => "Stok tidak mencukupi. Tersedia: {$alat->jumlah_tersedia}"
            ])->withInput();
        }

        // Generate kode
        $validated['kode_peminjaman'] = 'PJM' . date('Ymd') . rand(1000, 9999);
        $validated['user_id'] = auth()->id();
        $validated['status'] = 'menunggu';

        $peminjaman = Peminjaman::create($validated);

        ActivityLog::log('AJUKAN_PEMINJAMAN', "Mengajukan peminjaman {$validated['kode_peminjaman']}");

        return redirect()->route('peminjam.peminjaman.index')
            ->with('success', "Peminjaman berhasil diajukan. Kode: {$validated['kode_peminjaman']}");
    }

    // Detail peminjaman sendiri
    public function show(Peminjaman $peminjaman)
    {
        // Cek hanya bisa lihat milik sendiri
        if ($peminjaman->user_id !== auth()->id()) {
            abort(403, 'Anda tidak memiliki akses');
        }

        $peminjaman->load(['alat', 'petugas']);
        return view('peminjam.peminjaman.show', compact('peminjaman'));
    }
}