<?php

namespace App\Http\Controllers\Peminjam;

use App\Http\Controllers\Controller;
use App\Models\Pengembalian;
use App\Models\Peminjaman;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PengembalianController extends Controller
{
    // Form pengembalian untuk peminjaman sendiri
    public function create(Request $request)
    {
        $peminjaman = Peminjaman::with(['alat'])
            ->where('user_id', auth()->id())
            ->where('id', $request->peminjaman_id)
            ->whereIn('status', ['disetujui', 'dipinjam'])
            ->firstOrFail();

        return view('peminjam.pengembalian.create', compact('peminjaman'));
    }

    // Simpan pengembalian
    public function store(Request $request)
    {
        $validated = $request->validate([
            'peminjaman_id' => 'required|exists:peminjaman,id',
            'tanggal_pengembalian' => 'required|date',
            'kondisi_alat' => 'required|in:baik,rusak_ringan,rusak_berat',
            'jumlah_dikembalikan' => 'required|integer|min:1',
            'keterangan' => 'nullable|string',
        ]);

        $peminjaman = Peminjaman::findOrFail($validated['peminjaman_id']);

        // Cek hanya bisa mengembalikan milik sendiri
        if ($peminjaman->user_id !== auth()->id()) {
            abort(403, 'Anda tidak memiliki akses');
        }

        // Validate jumlah
        if ($validated['jumlah_dikembalikan'] > $peminjaman->jumlah_pinjam) {
            return back()->withErrors([
                'jumlah_dikembalikan' => 'Jumlah melebihi jumlah pinjam'
            ])->withInput();
        }

        // Hitung denda
        $tglKembali = Carbon::parse($validated['tanggal_pengembalian']);
        $tglRencana = Carbon::parse($peminjaman->tanggal_kembali_rencana);
        $hariTerlambat = $tglKembali->gt($tglRencana) ? $tglKembali->diffInDays($tglRencana) : 0;

        $dendaTerlambat = $hariTerlambat * 10000 * $validated['jumlah_dikembalikan'];
        
        $dendaKerusakan = 0;
        if ($validated['kondisi_alat'] === 'rusak_ringan') {
            $dendaKerusakan = 50000 * $validated['jumlah_dikembalikan'];
        } elseif ($validated['kondisi_alat'] === 'rusak_berat') {
            $dendaKerusakan = 200000 * $validated['jumlah_dikembalikan'];
        }

        $totalDenda = $dendaTerlambat + $dendaKerusakan;

        DB::beginTransaction();
        try {
            Pengembalian::create([
                'peminjaman_id' => $validated['peminjaman_id'],
                'tanggal_pengembalian' => $validated['tanggal_pengembalian'],
                'kondisi_alat' => $validated['kondisi_alat'],
                'jumlah_dikembalikan' => $validated['jumlah_dikembalikan'],
                'denda' => $totalDenda,
                'keterangan' => $validated['keterangan'],
                'diterima_oleh' => auth()->id(), // Self return
            ]);

            // Update stok alat
            $peminjaman->alat->increment('jumlah_tersedia', $validated['jumlah_dikembalikan']);

            // Update status peminjaman
            $peminjaman->update([
                'status' => 'dikembalikan',
                'tanggal_kembali_aktual' => $validated['tanggal_pengembalian'],
            ]);

            ActivityLog::log(
                'MENGEMBALIKAN_ALAT',
                "Mengembalikan alat {$peminjaman->kode_peminjaman}. Denda: Rp " . number_format($totalDenda)
            );

            DB::commit();

            return redirect()->route('peminjam.peminjaman.index')
                ->with('success', "Pengembalian berhasil. Total denda: Rp " . number_format($totalDenda));
        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }
}