<?php

namespace App\Http\Controllers\Peminjam;

use App\Http\Controllers\Controller;
use App\Models\Alat;
use App\Models\Kategori;
use Illuminate\Http\Request;

class AlatController extends Controller
{
    // Melihat daftar alat (READ ONLY)
    public function index(Request $request)
    {
        $query = Alat::with('kategori')->where('jumlah_tersedia', '>', 0);

        // Search
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('nama_alat', 'like', '%' . $request->search . '%')
                  ->orWhere('kode_alat', 'like', '%' . $request->search . '%');
            });
        }

        // Filter by kategori
        if ($request->filled('kategori')) {
            $query->where('kategori_id', $request->kategori);
        }

        $alats = $query->paginate(9)->appends($request->all());
        $kategoris = Kategori::all();

        return view('peminjam.alat.index', compact('alats', 'kategoris'));
    }
}