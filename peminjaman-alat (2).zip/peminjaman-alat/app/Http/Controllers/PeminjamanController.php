<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Peminjaman;
use App\Models\Alat;
use App\Models\User;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PeminjamanController extends Controller
{
    public function index()
    {
        $peminjamans = Peminjaman::with(['user', 'alat', 'petugas'])
            ->latest()
            ->paginate(15);
        
        return view('admin.peminjaman.index', compact('peminjamans'));
    }

    public function create()
    {
        $users = User::where('role', 'peminjam')->get();
        $alats = Alat::where('jumlah_tersedia', '>', 0)->get();
        
        return view('admin.peminjaman.create', compact('users', 'alats'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'alat_id' => 'required|exists:alat,id',
            'jumlah_pinjam' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date',
            'tanggal_kembali_rencana' => 'required|date|after:tanggal_pinjam',
            'keperluan' => 'required|string',
            'status' => 'required|in:menunggu,disetujui,ditolak',
        ]);

        // Cek stok
        $alat = Alat::find($validated['alat_id']);
        if ($alat->jumlah_tersedia < $validated['jumlah_pinjam']) {
            return back()->withErrors(['jumlah_pinjam' => 'Stok tidak mencukupi'])->withInput();
        }

        // Generate kode
        $validated['kode_peminjaman'] = 'PJM' . date('Ymd') . rand(1000, 9999);
        $validated['disetujui_oleh'] = auth()->id();

        DB::beginTransaction();
        try {
            $peminjaman = Peminjaman::create($validated);

            // Jika langsung disetujui, kurangi stok
            if ($validated['status'] === 'disetujui') {
                $alat->decrement('jumlah_tersedia', $validated['jumlah_pinjam']);
            }

            ActivityLog::log('CREATE_PEMINJAMAN', "Admin membuat peminjaman {$validated['kode_peminjaman']}");
            
            DB::commit();
            return redirect()->route('admin.peminjaman.index')->with('success', 'Peminjaman berhasil ditambahkan');
        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Terjadi kesalahan')->withInput();
        }
    }

    public function show(Peminjaman $peminjaman)
    {
        $peminjaman->load(['user', 'alat', 'petugas']);
        return view('admin.peminjaman.show', compact('peminjaman'));
    }

    public function edit(Peminjaman $peminjaman)
    {
        return view('admin.peminjaman.edit', compact('peminjaman'));
    }

    public function update(Request $request, Peminjaman $peminjaman)
    {
        $validated = $request->validate([
            'jumlah_pinjam' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date',
            'tanggal_kembali_rencana' => 'required|date|after:tanggal_pinjam',
            'keperluan' => 'required|string',
            'status' => 'required|in:menunggu,disetujui,ditolak,dipinjam,dikembalikan',
            'catatan_petugas' => 'nullable|string',
        ]);

        $peminjaman->update($validated);

        ActivityLog::log('UPDATE_PEMINJAMAN', "Admin mengupdate peminjaman {$peminjaman->kode_peminjaman}");

        return redirect()->route('admin.peminjaman.index')->with('success', 'Peminjaman berhasil diupdate');
    }

    public function destroy(Peminjaman $peminjaman)
    {
        // Hanya bisa hapus jika status menunggu atau ditolak
        if (in_array($peminjaman->status, ['disetujui', 'dipinjam'])) {
            return back()->with('error', 'Tidak bisa menghapus peminjaman yang sudah disetujui/dipinjam');
        }

        $kode = $peminjaman->kode_peminjaman;
        $peminjaman->delete();

        ActivityLog::log('DELETE_PEMINJAMAN', "Admin menghapus peminjaman {$kode}");

        return redirect()->route('admin.peminjaman.index')->with('success', 'Peminjaman berhasil dihapus');
    }
}