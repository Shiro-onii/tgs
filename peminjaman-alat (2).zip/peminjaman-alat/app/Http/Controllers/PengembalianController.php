<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pengembalian;
use App\Models\Peminjaman;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PengembalianController extends Controller
{
    public function index()
    {
        $pengembalians = Pengembalian::with(['peminjaman.user', 'peminjaman.alat', 'petugas'])
            ->latest()
            ->paginate(15);

        return view('admin.pengembalian.index', compact('pengembalians'));
    }

    public function create()
    {
        $peminjamans = Peminjaman::whereIn('status', ['disetujui', 'dipinjam'])
            ->with(['user', 'alat'])
            ->get();

        return view('admin.pengembalian.create', compact('peminjamans'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'peminjaman_id' => 'required|exists:peminjaman,id',
            'tanggal_pengembalian' => 'required|date',
            'kondisi_alat' => 'required|in:baik,rusak_ringan,rusak_berat',
            'jumlah_dikembalikan' => 'required|integer|min:1',
            'keterangan' => 'nullable|string',
        ]);

        $peminjaman = Peminjaman::findOrFail($validated['peminjaman_id']);

        // Hitung denda
        $tglKembali = Carbon::parse($validated['tanggal_pengembalian']);
        $tglRencana = Carbon::parse($peminjaman->tanggal_kembali_rencana);
        $hariTerlambat = $tglKembali->gt($tglRencana) ? $tglKembali->diffInDays($tglRencana) : 0;

        $dendaTerlambat = $hariTerlambat * 10000;
        $dendaKerusakan = 0;

        if ($validated['kondisi_alat'] === 'rusak_ringan') {
            $dendaKerusakan = 50000 * $validated['jumlah_dikembalikan'];
        } elseif ($validated['kondisi_alat'] === 'rusak_berat') {
            $dendaKerusakan = 200000 * $validated['jumlah_dikembalikan'];
        }

        $totalDenda = $dendaTerlambat + $dendaKerusakan;

        DB::beginTransaction();
        try {
            Pengembalian::create([
                'peminjaman_id' => $validated['peminjaman_id'],
                'tanggal_pengembalian' => $validated['tanggal_pengembalian'],
                'kondisi_alat' => $validated['kondisi_alat'],
                'jumlah_dikembalikan' => $validated['jumlah_dikembalikan'],
                'denda' => $totalDenda,
                'keterangan' => $validated['keterangan'],
                'diterima_oleh' => auth()->id(),
            ]);

            // Update stok & status
            $peminjaman->alat->increment('jumlah_tersedia', $validated['jumlah_dikembalikan']);
            $peminjaman->update([
                'status' => 'dikembalikan',
                'tanggal_kembali_aktual' => $validated['tanggal_pengembalian'],
            ]);

            ActivityLog::log('CREATE_PENGEMBALIAN', "Admin memproses pengembalian {$peminjaman->kode_peminjaman}");

            DB::commit();
            return redirect()->route('admin.pengembalian.index')->with('success', 'Pengembalian berhasil diproses');
        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Terjadi kesalahan')->withInput();
        }
    }

    public function show(Pengembalian $pengembalian)
    {
        $pengembalian->load(['peminjaman.user', 'peminjaman.alat', 'petugas']);
        return view('admin.pengembalian.show', compact('pengembalian'));
    }

    public function edit(Pengembalian $pengembalian)
    {
        return view('admin.pengembalian.edit', compact('pengembalian'));
    }

    public function update(Request $request, Pengembalian $pengembalian)
    {
        $validated = $request->validate([
            'tanggal_pengembalian' => 'required|date',
            'kondisi_alat' => 'required|in:baik,rusak_ringan,rusak_berat',
            'denda' => 'required|numeric|min:0',
            'keterangan' => 'nullable|string',
        ]);

        $pengembalian->update($validated);

        ActivityLog::log('UPDATE_PENGEMBALIAN', "Admin mengupdate pengembalian");

        return redirect()->route('admin.pengembalian.index')->with('success', 'Pengembalian berhasil diupdate');
    }

    public function destroy(Pengembalian $pengembalian)
    {
        DB::beginTransaction();
        try {
            // Kembalikan stok
            $pengembalian->peminjaman->alat->decrement('jumlah_tersedia', $pengembalian->jumlah_dikembalikan);
            
            // Update status peminjaman
            $pengembalian->peminjaman->update(['status' => 'dipinjam']);

            $pengembalian->delete();

            ActivityLog::log('DELETE_PENGEMBALIAN', "Admin menghapus pengembalian");

            DB::commit();
            return redirect()->route('admin.pengembalian.index')->with('success', 'Pengembalian berhasil dihapus');
        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Terjadi kesalahan');
        }
    }
}