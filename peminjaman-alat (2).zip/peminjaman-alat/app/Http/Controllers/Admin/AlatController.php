<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Alat;
use App\Models\Kategori;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class AlatController extends Controller
{
    public function index(Request $request)
    {
        $query = Alat::with('kategori');

        // Search
        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('nama_alat', 'like', '%' . $request->search . '%')
                  ->orWhere('kode_alat', 'like', '%' . $request->search . '%');
            });
        }

        // Filter by kategori
        if ($request->filled('kategori')) {
            $query->where('kategori_id', $request->kategori);
        }

        // Filter by kondisi
        if ($request->filled('kondisi')) {
            $query->where('kondisi', $request->kondisi);
        }

        $alats = $query->paginate(9)->appends($request->all());
        $kategoris = Kategori::all();

        return view('admin.alat.index', compact('alats', 'kategoris'));
    }

    public function create()
    {
        $kategoris = Kategori::all();
        return view('admin.alat.create', compact('kategoris'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'kode_alat' => 'required|string|max:50|unique:alat,kode_alat',
            'nama_alat' => 'required|string|max:200',
            'kategori_id' => 'required|exists:kategori,id',
            'merk' => 'nullable|string|max:100',
            'kondisi' => 'required|in:baik,rusak_ringan,rusak_berat',
            'jumlah_total' => 'required|integer|min:0',
            'jumlah_tersedia' => 'required|integer|min:0|lte:jumlah_total',
            'spesifikasi' => 'nullable|string',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ], [
            'kode_alat.required' => 'Kode alat wajib diisi',
            'kode_alat.unique' => 'Kode alat sudah digunakan',
            'nama_alat.required' => 'Nama alat wajib diisi',
            'kategori_id.required' => 'Kategori wajib dipilih',
            'jumlah_tersedia.lte' => 'Jumlah tersedia tidak boleh lebih dari jumlah total',
        ]);

        // Handle file upload
        if ($request->hasFile('foto')) {
            $validated['foto'] = $request->file('foto')->store('alat', 'public');
        }

        $alat = Alat::create($validated);

        ActivityLog::log('CREATE_ALAT', "Menambah alat: {$alat->nama_alat}");

        return redirect()->route('admin.alat.index')
            ->with('success', 'Alat berhasil ditambahkan');
    }

    public function edit(Alat $alat)
    {
        $kategoris = Kategori::all();
        return view('admin.alat.edit', compact('alat', 'kategoris'));
    }

    public function update(Request $request, Alat $alat)
    {
        $validated = $request->validate([
            'kode_alat' => 'required|string|max:50|unique:alat,kode_alat,' . $alat->id,
            'nama_alat' => 'required|string|max:200',
            'kategori_id' => 'required|exists:kategori,id',
            'kondisi' => 'required|in:baik,rusak_ringan,rusak_berat',
            'jumlah_total' => 'required|integer|min:0',
            'jumlah_tersedia' => 'required|integer|min:0|lte:jumlah_total',
            'spesifikasi' => 'nullable|string',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        // Handle file upload
        if ($request->hasFile('foto')) {
            // Delete old file
            if ($alat->foto) {
                Storage::disk('public')->delete($alat->foto);
            }
            $validated['foto'] = $request->file('foto')->store('alat', 'public');
        }

        $alat->update($validated);

        ActivityLog::log('UPDATE_ALAT', "Mengupdate alat: {$alat->nama_alat}");

        return redirect()->route('admin.alat.index')
            ->with('success', 'Alat berhasil diupdate');
    }

    public function destroy(Alat $alat)
    {
        // Check if alat has peminjaman
        if ($alat->peminjaman()->whereIn('status', ['menunggu', 'disetujui', 'dipinjam'])->count() > 0) {
            return back()->with('error', 'Alat tidak bisa dihapus karena sedang/akan dipinjam');
        }

        // Delete file
        if ($alat->foto) {
            Storage::disk('public')->delete($alat->foto);
        }

        $namaAlat = $alat->nama_alat;
        $alat->delete();

        ActivityLog::log('DELETE_ALAT', "Menghapus alat: {$namaAlat}");

        return redirect()->route('admin.alat.index')
            ->with('success', 'Alat berhasil dihapus');
    }
}