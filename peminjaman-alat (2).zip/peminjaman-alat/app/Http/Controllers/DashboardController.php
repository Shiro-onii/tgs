<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Alat;
use App\Models\Peminjaman;


class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        
        if (in_array($user->role, ['admin', 'petugas'])) {
            // Data for Admin & Petugas
            $data = [
                'totalAlat' => Alat::count(),
                'totalUser' => User::count(),
                'peminjamanAktif' => Peminjaman::whereIn('status', ['disetujui', 'dipinjam'])->count(),
                'menungguApprove' => Peminjaman::where('status', 'menunggu')->count(),
                'recentPeminjaman' => Peminjaman::with(['user', 'alat'])
                    ->latest()
                    ->limit(5)
                    ->get(),
                'popularAlat' => Alat::withCount(['peminjaman' => function($query) {
                        $query->whereIn('status', ['disetujui', 'dipinjam', 'dikembalikan']);
                    }])
                    ->orderBy('peminjaman_count', 'desc')
                    ->limit(5)
                    ->get(),
            ];
        } else {
            // Data for Peminjam
            $data = [
                'alatTersedia' => Alat::where('jumlah_tersedia', '>', 0)->count(),
                'myPeminjamanAktif' => Peminjaman::where('user_id', $user->id)
                    ->whereIn('status', ['disetujui', 'dipinjam'])
                    ->count(),
                'myMenungguApprove' => Peminjaman::where('user_id', $user->id)
                    ->where('status', 'menunggu')
                    ->count(),
                'myTotalPeminjaman' => Peminjaman::where('user_id', $user->id)->count(),
                'recentPeminjaman' => Peminjaman::with(['user', 'alat'])
                    ->where('user_id', $user->id)
                    ->latest()
                    ->limit(5)
                    ->get(),
                'popularAlat' => Alat::where('jumlah_tersedia', '>', 0)
                    ->withCount(['peminjaman' => function($query) {
                        $query->whereIn('status', ['disetujui', 'dipinjam', 'dikembalikan']);
                    }])
                    ->orderBy('peminjaman_count', 'desc')
                    ->limit(5)
                    ->get(),
            ];
        }
        
        return view('dashboard', $data);
    }
}