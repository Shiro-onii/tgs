<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Controller;
use App\Models\Peminjaman;
use App\Models\Pengembalian;
use Illuminate\Http\Request;
use PDF; // Install: composer require barryvdh/laravel-dompdf

class LaporanController extends Controller
{
    public function index()
    {
        return view('petugas.laporan.index');
    }

    public function cetak(Request $request)
    {
        $jenis = $request->jenis; // peminjaman atau pengembalian
        $tanggal_mulai = $request->tanggal_mulai;
        $tanggal_akhir = $request->tanggal_akhir;

        if ($jenis === 'peminjaman') {
            $data = Peminjaman::with(['user', 'alat'])
                ->whereBetween('tanggal_pinjam', [$tanggal_mulai, $tanggal_akhir])
                ->get();
            
            $title = 'Laporan Peminjaman';
            $view = 'petugas.laporan.peminjaman';
        } else {
            $data = Pengembalian::with(['peminjaman.user', 'peminjaman.alat'])
                ->whereBetween('tanggal_pengembalian', [$tanggal_mulai, $tanggal_akhir])
                ->get();
            
            $title = 'Laporan Pengembalian';
            $view = 'petugas.laporan.pengembalian';
        }

        // Return as PDF (optional - bisa juga HTML biasa)
        // $pdf = PDF::loadView($view, compact('data', 'title', 'tanggal_mulai', 'tanggal_akhir'));
        // return $pdf->download('laporan-' . $jenis . '.pdf');

        // Atau tampilkan di browser
        return view($view, compact('data', 'title', 'tanggal_mulai', 'tanggal_akhir'));
    }
}