<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Controller;
use App\Models\Pengembalian;

class PengembalianController extends Controller
{
    // Memantau pengembalian (READ ONLY)
    public function index()
    {
        $pengembalians = Pengembalian::with(['peminjaman.user', 'peminjaman.alat', 'petugas'])
            ->latest()
            ->paginate(15);

        return view('petugas.pengembalian.index', compact('pengembalians'));
    }

    public function show(Pengembalian $pengembalian)
    {
        $pengembalian->load(['peminjaman.user', 'peminjaman.alat', 'petugas']);
        return view('petugas.pengembalian.show', compact('pengembalian'));
    }
}