<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Controller;
use App\Models\Peminjaman;
use App\Models\ActivityLog;
use Illuminate\Support\Facades\DB;

class PeminjamanController extends Controller
{

    public function index()
    {
        $peminjamans = Peminjaman::with(['user', 'alat'])
            ->whereIn('status', ['menunggu', 'disetujui', 'dipinjam'])
            ->latest()
            ->paginate(15);

        return view('petugas.peminjaman.index', compact('peminjamans'));
    }

    public function show(Peminjaman $peminjaman)
    {
        $peminjaman->load(['user', 'alat', 'petugas']);
        return view('petugas.peminjaman.show', compact('peminjaman'));
    }


    public function approve(Peminjaman $peminjaman)
    {
        if ($peminjaman->status !== 'menunggu') {
            return back()->with('error', 'Peminjaman sudah diproses');
        }

        $alat = $peminjaman->alat;
        if ($alat->jumlah_tersedia < $peminjaman->jumlah_pinjam) {
            return back()->with('error', 'Stok tidak mencukupi');
        }

        DB::beginTransaction();
        try {
            $peminjaman->update([
                'status' => 'disetujui',
                'disetujui_oleh' => auth()->id(),
            ]);

            // Kurangi stok
            $alat->decrement('jumlah_tersedia', $peminjaman->jumlah_pinjam);

            ActivityLog::log('APPROVE_PEMINJAMAN', "Menyetujui peminjaman {$peminjaman->kode_peminjaman}");

            DB::commit();
            return back()->with('success', 'Peminjaman berhasil disetujui');
        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    // Reject peminjaman
    public function reject(Peminjaman $peminjaman)
    {
        if ($peminjaman->status !== 'menunggu') {
            return back()->with('error', 'Peminjaman sudah diproses');
        }

        $peminjaman->update([
            'status' => 'ditolak',
            'disetujui_oleh' => auth()->id(),
        ]);

        ActivityLog::log('REJECT_PEMINJAMAN', "Menolak peminjaman {$peminjaman->kode_peminjaman}");

        return back()->with('success', 'Peminjaman ditolak');
    }
}