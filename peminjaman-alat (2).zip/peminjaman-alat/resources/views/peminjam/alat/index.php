use Illuminate\Support\Str;
@extends('layouts.app')

@section('title', 'Daftar Alat')
@section('page-title', 'Daftar Alat Tersedia')

@section('content')

<!-- Filter & Search -->
<div class="card mb-3">
    <div class="card-body">
        <form action="{{ route('peminjam.alat.index') }}" method="GET">
            <div class="row">
                <div class="col-md-5 mb-2">
                    <input type="text" name="search" class="form-control" placeholder="Cari alat..." value="{{ request('search') }}">
                </div>
                <div class="col-md-4 mb-2">
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        @foreach($kategoris as $kat)
                            <option value="{{ $kat->id }}" {{ request('kategori') == $kat->id ? 'selected' : '' }}>
                                {{ $kat->nama_kategori }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Cari
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Alat Cards -->
<div class="row">
    @forelse($alats as $alat)
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                @if($alat->foto)
                    <img src="{{ asset('storage/' . $alat->foto) }}" class="card-img-top" alt="{{ $alat->nama_alat }}" style="height: 200px; object-fit: cover;">
                @else
                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-tools fa-4x text-muted"></i>
                    </div>
                @endif
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0">{{ $alat->nama_alat }}</h5>
                        <span class="badge bg-success">Tersedia</span>
                    </div>
                    <p class="text-muted small mb-2">
                        <i class="fas fa-barcode me-1"></i> {{ $alat->kode_alat }} 
                        <span class="ms-2"><i class="fas fa-tag me-1"></i> {{ $alat->kategori->nama_kategori ?? '-' }}</span>
                    </p>
                    @if($alat->merk)
                        <p class="mb-2"><small><strong>Merk:</strong> {{ $alat->merk }}</small></p>
                    @endif
                    @if($alat->spesifikasi)
                        <p class="mb-2 small">{{ Str::limit($alat->spesifikasi, 80) }}</p>
                    @endif
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="badge bg-primary fs-6">
                            Tersedia: {{ $alat->jumlah_tersedia }}
                        </span>
                        <a href="{{ route('peminjam.peminjaman.create', ['alat_id' => $alat->id]) }}" class="btn btn-sm btn-success">
                            <i class="fas fa-hand-holding me-1"></i> Pinjam
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @empty
        <div class="col-12">
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                    <h5>Tidak ada alat tersedia</h5>
                    <p class="text-muted">Silakan coba lagi nanti</p>
                </div>
            </div>
        </div>
    @endforelse
</div>

<div class="mt-3">
    {{ $alats->links() }}
</div>

@endsection