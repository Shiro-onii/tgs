@extends('layouts.app')

@section('title', 'Peminjaman Saya')
@section('page-title', 'Riwayat Peminjaman Saya')

@section('content')

<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('peminjam.peminjaman.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Ajukan Peminjaman
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Alat</th>
                        <th>Jumlah</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($peminjamans as $p)
                        <tr>
                            <td>{{ $p->kode_peminjaman }}</td>
                            <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                            <td>{{ $p->jumlah_pinjam }}</td>
                            <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                            <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                            <td>
                                @php
                                    $badgeClass = match($p->status) {
                                        'menunggu' => 'bg-warning text-dark',
                                        'disetujui' => 'bg-success',
                                        'ditolak' => 'bg-danger',
                                        'dipinjam' => 'bg-info',
                                        'dikembalikan' => 'bg-secondary',
                                        default => 'bg-secondary'
                                    };
                                @endphp
                                <span class="badge {{ $badgeClass }}">
                                    {{ ucfirst($p->status) }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('peminjam.peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                @if(in_array($p->status, ['disetujui', 'dipinjam']))
                                    <a href="{{ route('peminjam.pengembalian.create', ['peminjaman_id' => $p->id]) }}" class="btn btn-sm btn-primary">
                                        <i class="fas fa-undo"></i> Kembalikan
                                    </a>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada riwayat peminjaman
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $peminjamans->links() }}
        </div>
    </div>
</div>

@endsection