@extends('layouts.app')

@section('title', 'Kelola Alat')
@section('page-title', auth()->user()->role === 'peminjam' ? 'Daftar Alat' : 'Kelola Alat')

@section('content')

<!-- Filter & Search -->
<div class="card mb-3">
    <div class="card-body">
        <form action="{{ route('alat.index') }}" method="GET">
            <div class="row">
                <div class="col-md-4 mb-2">
                    <input type="text" name="search" class="form-control" placeholder="Cari alat..." value="{{ request('search') }}">
                </div>
                <div class="col-md-3 mb-2">
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        @foreach($kategoris as $kat)
                            <option value="{{ $kat->id }}" {{ request('kategori') == $kat->id ? 'selected' : '' }}>
                                {{ $kat->nama_kategori }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <select name="kondisi" class="form-select">
                        <option value="">Semua Kondisi</option>
                        <option value="baik" {{ request('kondisi') == 'baik' ? 'selected' : '' }}>Baik</option>
                        <option value="rusak_ringan" {{ request('kondisi') == 'rusak_ringan' ? 'selected' : '' }}>Rusak Ringan</option>
                        <option value="rusak_berat" {{ request('kondisi') == 'rusak_berat' ? 'selected' : '' }}>Rusak Berat</option>
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

@if(in_array(auth()->user()->role, ['admin', 'petugas']))
<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('alat.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Alat
        </a>
    </div>
</div>
@endif

<!-- Alat Cards -->
<div class="row">
    @forelse($alats as $alat)
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                @if($alat->foto)
                    <img src="{{ asset('storage/' . $alat->foto) }}" class="card-img-top" alt="{{ $alat->nama_alat }}" style="height: 200px; object-fit: cover;">
                @else
                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-tools fa-4x text-muted"></i>
                    </div>
                @endif
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0">{{ $alat->nama_alat }}</h5>
                        <span class="badge bg-{{ $alat->kondisi === 'baik' ? 'success' : ($alat->kondisi === 'rusak_ringan' ? 'warning' : 'danger') }}">
                            {{ ucfirst(str_replace('_', ' ', $alat->kondisi)) }}
                        </span>
                    </div>
                    <p class="text-muted small mb-2">
                        <i class="fas fa-barcode me-1"></i> {{ $alat->kode_alat }} 
                        <span class="ms-2"><i class="fas fa-tag me-1"></i> {{ $alat->kategori->nama_kategori ?? '-' }}</span>
                    </p>
                    @if($alat->merk)
                        <p class="mb-2"><small><strong>Merk:</strong> {{ $alat->merk }}</small></p>
                    @endif
                    @if($alat->spesifikasi)
                        <p class="mb-2"><small>{{ Str::limit($alat->spesifikasi, 80) }}</small></p>
                    @endif
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="badge bg-{{ $alat->jumlah_tersedia > 0 ? 'success' : 'danger' }} fs-6">
                            Tersedia: {{ $alat->jumlah_tersedia }}/{{ $alat->jumlah_total }}
                        </span>
                        <div>
                            @if(in_array(auth()->user()->role, ['admin', 'petugas']))
                                <a href="{{ route('alat.edit', $alat->id) }}" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                @if(auth()->user()->role === 'admin')
                                    <form action="{{ route('alat.destroy', $alat->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus alat ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @empty
        <div class="col-12">
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                    <h5>Belum ada alat</h5>
                    <p class="text-muted">Silakan tambah alat terlebih dahulu</p>
                </div>
            </div>
        </div>
    @endforelse
</div>

<div class="mt-3">
    {{ $alats->links() }}
</div>

@endsection