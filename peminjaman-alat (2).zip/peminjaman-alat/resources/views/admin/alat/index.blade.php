@extends('layouts.app')

@section('title', 'Kelola Alat')
@section('page-title', 'Kelola Alat')

@section('content')

<!-- Filter & Search -->
<div class="card mb-3">
    <div class="card-body">
        <form action="{{ route('admin.alat.index') }}" method="GET">
            <div class="row">
                <div class="col-md-4 mb-2">
                    <input type="text" name="search" class="form-control" placeholder="Cari alat..." value="{{ request('search') }}">
                </div>
                <div class="col-md-3 mb-2">
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        @foreach($kategoris as $kat)
                            <option value="{{ $kat->id }}" {{ request('kategori') == $kat->id ? 'selected' : '' }}>
                                {{ $kat->nama_kategori }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <select name="kondisi" class="form-select">
                        <option value="">Semua Kondisi</option>
                        <option value="baik" {{ request('kondisi') == 'baik' ? 'selected' : '' }}>Baik</option>
                        <option value="rusak_ringan" {{ request('kondisi') == 'rusak_ringan' ? 'selected' : '' }}>Rusak Ringan</option>
                        <option value="rusak_berat" {{ request('kondisi') == 'rusak_berat' ? 'selected' : '' }}>Rusak Berat</option>
                    </select>
                </div>
                <div class="col-md-2 mb-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

@if(in_array(auth()->user()->role, ['admin', 'petugas']))
<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('admin.alat.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Alat
        </a>
    </div>
</div>
@endif

<div class="row">
    @forelse($alats as $alat)
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                @if($alat->foto)
                    <img src="{{ asset('storage/' . $alat->foto) }}" class="card-img-top" alt="{{ $alat->nama_alat }}" style="height: 200px; object-fit: cover;">
                @else
                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-tools fa-4x text-muted"></i>
                    </div>
                @endif
                <div class="card-body">
                    <h5 class="card-title">{{ $alat->nama_alat }}</h5>
                    <p>{{ $alat->kategori->nama_kategori ?? '-' }} - {{ ucfirst(str_replace('_', ' ', $alat->kondisi)) }}</p>
                    <p>Merk: {{ $alat->merk ?? '-' }}</p>
                    <p>Jumlah tersedia: {{ $alat->jumlah_tersedia }}/{{ $alat->jumlah_total }}</p>

                    <a href="{{ route('admin.alat.edit', $alat->id) }}" class="btn btn-sm btn-warning">Edit</a>
                    @if(auth()->user()->role === 'admin')
                        <form action="{{ route('admin.alat.destroy', $alat->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus alat ini?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    @endif
                </div>
            </div>
        </div>
    @empty
        <p>Belum ada alat</p>
    @endforelse
</div>

<div class="mt-3">
    {{ $alats->links() }}
</div>

@endsection
