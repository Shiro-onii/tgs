@extends('layouts.app')

@section('title', 'Kelola Peminjaman')
@section('page-title', 'Kelola Peminjaman')

@section('content')

@if(auth()->user()->role === 'peminjam')
<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('peminjaman.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Ajukan Peminjaman
        </a>
    </div>
</div>
@endif

<!-- Tabs -->
<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button">
            Semua
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="menunggu-tab" data-bs-toggle="tab" data-bs-target="#menunggu" type="button">
            Menunggu <span class="badge bg-warning text-dark">{{ $countMenunggu ?? 0 }}</span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="dipinjam-tab" data-bs-toggle="tab" data-bs-target="#dipinjam" type="button">
            Dipinjam <span class="badge bg-info">{{ $countDipinjam ?? 0 }}</span>
        </button>
    </li>
</ul>

<!-- Tab Content -->
<div class="tab-content">
    <!-- Semua -->
    <div class="tab-pane fade show active" id="all" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjamanAll as $p)
                                <tr>
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->user->name ?? '-' }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                                    <td>
                                        @php
                                            $badgeClass = match($p->status) {
                                                'menunggu' => 'bg-warning text-dark',
                                                'disetujui' => 'bg-success',
                                                'ditolak' => 'bg-danger',
                                                'dipinjam' => 'bg-info',
                                                'dikembalikan' => 'bg-secondary',
                                                default => 'bg-secondary'
                                            };
                                        @endphp
                                        <span class="badge {{ $badgeClass }}">
                                            {{ ucfirst($p->status) }}
                                        </span>
                                    </td>
                                    <td>
                                        <a href="{{ route('peminjaman.show', $p->id) }}" class="btn btn-sm btn-info" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        @if(in_array(auth()->user()->role, ['admin', 'petugas']) && $p->status === 'menunggu')
                                            <form action="{{ route('peminjaman.approve', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Setujui peminjaman ini?')">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-success" title="Setujui">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                            <form action="{{ route('peminjaman.reject', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Tolak peminjaman ini?')">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-danger" title="Tolak">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Belum ada peminjaman</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    {{ $peminjamanAll->links() }}
                </div>
            </div>
        </div>
    </div>

    <!-- Menunggu -->
    <div class="tab-pane fade" id="menunggu" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Keperluan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjamanMenunggu as $p)
                                <tr>
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->user->name ?? '-' }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                    <td>{{ Str::limit($p->keperluan, 50) }}</td>
                                    <td>
                                        <a href="{{ route('peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        @if(in_array(auth()->user()->role, ['admin', 'petugas']))
                                            <form action="{{ route('peminjaman.approve', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Setujui peminjaman ini?')">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-success">
                                                    <i class="fas fa-check"></i> Setujui
                                                </button>
                                            </form>
                                            <form action="{{ route('peminjaman.reject', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Tolak peminjaman ini?')">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-times"></i> Tolak
                                                </button>
                                            </form>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted">Tidak ada peminjaman yang menunggu</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Dipinjam -->
    <div class="tab-pane fade" id="dipinjam" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Sisa Hari</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjamanDipinjam as $p)
                                @php
                                    $today = \Carbon\Carbon::now();
                                    $tglKembali = \Carbon\Carbon::parse($p->tanggal_kembali_rencana);
                                    $sisaHari = $today->diffInDays($tglKembali, false);
                                    $isOverdue = $sisaHari < 0;
                                @endphp
                                <tr class="{{ $isOverdue ? 'table-danger' : '' }}">
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->user->name ?? '-' }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                                    <td>
                                        <span class="badge bg-{{ $isOverdue ? 'danger' : 'success' }}">
                                            {{ $isOverdue ? 'Terlambat ' . abs($sisaHari) : $sisaHari }} hari
                                        </span>
                                    </td>
                                    <td>
                                        <a href="{{ route('peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        @if(in_array(auth()->user()->role, ['admin', 'petugas']))
                                            <a href="{{ route('pengembalian.create', ['peminjaman_id' => $p->id]) }}" class="btn btn-sm btn-primary">
                                                <i class="fas fa-undo"></i> Kembalikan
                                            </a>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="8" class="text-center text-muted">Tidak ada alat yang sedang dipinjam</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection