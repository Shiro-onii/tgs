@extends('layouts.app')

@section('title', 'Ajukan Peminjaman')
@section('page-title', 'Ajukan Peminjaman')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Pengajuan Peminjaman</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('peminjaman.store') }}" method="POST" id="formPeminjaman">
                    @csrf
                    
                    <div class="mb-3">
                        <label for="alat_id" class="form-label">Pilih Alat <span class="text-danger">*</span></label>
                        <select class="form-select @error('alat_id') is-invalid @enderror" 
                                id="alat_id" name="alat_id" required onchange="updateStokInfo()">
                            <option value="">-- Pilih Alat --</option>
                            @foreach($alats as $alat)
                                <option value="{{ $alat->id }}" 
                                        data-stok="{{ $alat->jumlah_tersedia }}"
                                        {{ old('alat_id') == $alat->id ? 'selected' : '' }}>
                                    {{ $alat->nama_alat }} - {{ $alat->kode_alat }}
                                </option>
                            @endforeach
                        </select>
                        <small id="stokInfo" class="text-muted"></small>
                        @error('alat_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="jumlah_pinjam" class="form-label">Jumlah Pinjam <span class="text-danger">*</span></label>
                                <input type="number" class="form-control @error('jumlah_pinjam') is-invalid @enderror" 
                                       id="jumlah_pinjam" name="jumlah_pinjam" value="{{ old('jumlah_pinjam', 1) }}" min="1" required>
                                @error('jumlah_pinjam')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pinjam" class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('tanggal_pinjam') is-invalid @enderror" 
                                       id="tanggal_pinjam" name="tanggal_pinjam" value="{{ old('tanggal_pinjam', date('Y-m-d')) }}" 
                                       min="{{ date('Y-m-d') }}" required>
                                @error('tanggal_pinjam')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_kembali_rencana" class="form-label">Tanggal Kembali (Rencana) <span class="text-danger">*</span></label>
                        <input type="date" class="form-control @error('tanggal_kembali_rencana') is-invalid @enderror" 
                               id="tanggal_kembali_rencana" name="tanggal_kembali_rencana" value="{{ old('tanggal_kembali_rencana') }}" 
                               min="{{ date('Y-m-d', strtotime('+1 day')) }}" required>
                        @error('tanggal_kembali_rencana')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="keperluan" class="form-label">Keperluan <span class="text-danger">*</span></label>
                        <textarea class="form-control @error('keperluan') is-invalid @enderror" 
                                  id="keperluan" name="keperluan" rows="4" required>{{ old('keperluan') }}</textarea>
                        @error('keperluan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Catatan:</strong>
                        <ul class="mb-0 mt-2">
                            <li>Pastikan tanggal pengembalian sesuai kebutuhan Anda</li>
                            <li>Keterlambatan pengembalian dikenakan denda Rp 10.000/hari</li>
                            <li>Peminjaman akan diproses setelah disetujui oleh petugas</li>
                        </ul>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i> Ajukan Peminjaman
                        </button>
                        <a href="{{ route('peminjaman.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-question-circle me-2"></i> Panduan Peminjaman</h6>
            </div>
            <div class="card-body">
                <ol class="mb-0">
                    <li>Pilih alat yang ingin dipinjam</li>
                    <li>Tentukan jumlah dan tanggal</li>
                    <li>Isi keperluan dengan jelas</li>
                    <li>Tunggu persetujuan dari petugas</li>
                    <li>Ambil alat setelah disetujui</li>
                </ol>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
function updateStokInfo() {
    const select = document.getElementById('alat_id');
    const selected = select.options[select.selectedIndex];
    const stok = selected.getAttribute('data-stok');
    const jumlahInput = document.getElementById('jumlah_pinjam');
    
    if (stok) {
        document.getElementById('stokInfo').textContent = `Stok tersedia: ${stok}`;
        jumlahInput.max = stok;
    } else {
        document.getElementById('stokInfo').textContent = '';
        jumlahInput.max = '';
    }
}

// Set minimum date for tanggal kembali based on tanggal pinjam
document.getElementById('tanggal_pinjam').addEventListener('change', function() {
    const tglPinjam = new Date(this.value);
    tglPinjam.setDate(tglPinjam.getDate() + 1);
    const minDate = tglPinjam.toISOString().split('T')[0];
    document.getElementById('tanggal_kembali_rencana').min = minDate;
});
</script>
@endpush