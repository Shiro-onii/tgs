@extends('layouts.app')

@section('title', 'Kelola Pengembalian')
@section('page-title', 'Kelola Data Pengembalian')

@section('content')
<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('admin.pengembalian.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Pengembalian
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode Peminjaman</th>
                        <th>Peminjam</th>
                        <th>Alat</th>
                        <th>Tgl Pengembalian</th>
                        <th>Jumlah</th>
                        <th>Kondisi</th>
                        <th>Denda</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($pengembalians as $p)
                        <tr>
                            <td>{{ $p->peminjaman->kode_peminjaman ?? '-' }}</td>
                            <td>{{ $p->peminjaman->user->name ?? '-' }}</td>
                            <td>{{ $p->peminjaman->alat->nama_alat ?? '-' }}</td>
                            <td>{{ date('d/m/Y', strtotime($p->tanggal_pengembalian)) }}</td>
                            <td>{{ $p->jumlah_dikembalikan }}</td>
                            <td>
                                @php
                                    $kondisiBadge = match($p->kondisi_alat) {
                                        'baik' => 'bg-success',
                                        'rusak_ringan' => 'bg-warning text-dark',
                                        'rusak_berat' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                @endphp
                                <span class="badge {{ $kondisiBadge }}">
                                    {{ ucfirst(str_replace('_', ' ', $p->kondisi_alat)) }}
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-{{ $p->denda > 0 ? 'danger' : 'success' }}">
                                    Rp {{ number_format($p->denda, 0, ',', '.') }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('admin.pengembalian.show', $p->id) }}" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="{{ route('admin.pengembalian.edit', $p->id) }}" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="{{ route('admin.pengembalian.destroy', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus pengembalian ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Belum ada data pengembalian
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $pengembalians->links() }}
        </div>
    </div>
</div>
@endsection