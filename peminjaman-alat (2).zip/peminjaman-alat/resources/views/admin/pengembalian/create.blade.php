@extends('layouts.app')

@section('title', 'Tambah Pengembalian')
@section('page-title', 'Tambah Data Pengembalian')

@section('content')
<div class="row">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Tambah Pengembalian</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.pengembalian.store') }}" method="POST" id="formPengembalian">
                    @csrf
                    
                    <div class="mb-3">
                        <label for="peminjaman_id" class="form-label">Pilih Peminjaman <span class="text-danger">*</span></label>
                        <select class="form-select @error('peminjaman_id') is-invalid @enderror" 
                                id="peminjaman_id" name="peminjaman_id" required onchange="loadPeminjamanInfo()">
                            <option value="">-- Pilih Peminjaman --</option>
                            @foreach($peminjamans as $pem)
                                <option value="{{ $pem->id }}" 
                                        data-kode="{{ $pem->kode_peminjaman }}"
                                        data-user="{{ $pem->user->name }}"
                                        data-alat="{{ $pem->alat->nama_alat }}"
                                        data-jumlah="{{ $pem->jumlah_pinjam }}"
                                        data-tgl-rencana="{{ $pem->tanggal_kembali_rencana }}"
                                        {{ old('peminjaman_id') == $pem->id ? 'selected' : '' }}>
                                    {{ $pem->kode_peminjaman }} - {{ $pem->user->name }} ({{ $pem->alat->nama_alat }})
                                </option>
                            @endforeach
                        </select>
                        @error('peminjaman_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div id="peminjamanInfo" class="alert alert-info d-none mb-3">
                        <h6 class="alert-heading">Info Peminjaman</h6>
                        <p class="mb-0" id="infoText"></p>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="jumlah_dikembalikan" class="form-label">Jumlah Dikembalikan <span class="text-danger">*</span></label>
                                <input type="number" class="form-control @error('jumlah_dikembalikan') is-invalid @enderror" 
                                       id="jumlah_dikembalikan" name="jumlah_dikembalikan" value="{{ old('jumlah_dikembalikan', 1) }}" min="1" required>
                                @error('jumlah_dikembalikan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('tanggal_pengembalian') is-invalid @enderror" 
                                       id="tanggal_pengembalian" name="tanggal_pengembalian" value="{{ old('tanggal_pengembalian', date('Y-m-d')) }}" required>
                                @error('tanggal_pengembalian')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="kondisi_alat" class="form-label">Kondisi Alat <span class="text-danger">*</span></label>
                                <select class="form-select @error('kondisi_alat') is-invalid @enderror" 
                                        id="kondisi_alat" name="kondisi_alat" required>
                                    <option value="baik" {{ old('kondisi_alat') == 'baik' ? 'selected' : '' }}>Baik</option>
                                    <option value="rusak_ringan" {{ old('kondisi_alat') == 'rusak_ringan' ? 'selected' : '' }}>Rusak Ringan</option>
                                    <option value="rusak_berat" {{ old('kondisi_alat') == 'rusak_berat' ? 'selected' : '' }}>Rusak Berat</option>
                                </select>
                                @error('kondisi_alat')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <textarea class="form-control @error('keterangan') is-invalid @enderror" 
                                  id="keterangan" name="keterangan" rows="3">{{ old('keterangan') }}</textarea>
                        @error('keterangan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Simpan
                        </button>
                        <a href="{{ route('admin.pengembalian.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function loadPeminjamanInfo() {
    const select = document.getElementById('peminjaman_id');
    const selected = select.options[select.selectedIndex];
    
    if (selected.value) {
        const info = `
            <strong>Kode:</strong> ${selected.dataset.kode} | 
            <strong>Peminjam:</strong> ${selected.dataset.user} | 
            <strong>Alat:</strong> ${selected.dataset.alat} | 
            <strong>Jumlah:</strong> ${selected.dataset.jumlah} | 
            <strong>Tgl Kembali Rencana:</strong> ${selected.dataset.tglRencana}
        `;
        document.getElementById('infoText').innerHTML = info;
        document.getElementById('peminjamanInfo').classList.remove('d-none');
        document.getElementById('jumlah_dikembalikan').max = selected.dataset.jumlah;
    } else {
        document.getElementById('peminjamanInfo').classList.add('d-none');
    }
}

window.addEventListener('load', loadPeminjamanInfo);
</script>
@endpush
@endsection