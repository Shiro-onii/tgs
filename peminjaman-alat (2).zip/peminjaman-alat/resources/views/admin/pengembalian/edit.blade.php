@extends('layouts.app')

@section('title', 'Edit Pengembalian')
@section('page-title', 'Edit Data Pengembalian')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Edit Pengembalian</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.pengembalian.update', $pengembalian->id) }}" method="POST">
                    @csrf
                    @method('PUT')
                    
                    <div class="mb-3">
                        <label class="form-label">Kode Peminjaman</label>
                        <input type="text" class="form-control" value="{{ $pengembalian->peminjaman->kode_peminjaman }}" readonly>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Peminjam</label>
                            <input type="text" class="form-control" value="{{ $pengembalian->peminjaman->user->name }}" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Alat</label>
                            <input type="text" class="form-control" value="{{ $pengembalian->peminjaman->alat->nama_alat }}" readonly>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian <span class="text-danger">*</span></label>
                        <input type="date" class="form-control @error('tanggal_pengembalian') is-invalid @enderror" 
                               id="tanggal_pengembalian" name="tanggal_pengembalian" 
                               value="{{ old('tanggal_pengembalian', $pengembalian->tanggal_pengembalian) }}" required>
                        @error('tanggal_pengembalian')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="kondisi_alat" class="form-label">Kondisi Alat <span class="text-danger">*</span></label>
                        <select class="form-select @error('kondisi_alat') is-invalid @enderror" 
                                id="kondisi_alat" name="kondisi_alat" required>
                            <option value="baik" {{ old('kondisi_alat', $pengembalian->kondisi_alat) == 'baik' ? 'selected' : '' }}>Baik</option>
                            <option value="rusak_ringan" {{ old('kondisi_alat', $pengembalian->kondisi_alat) == 'rusak_ringan' ? 'selected' : '' }}>Rusak Ringan</option>
                            <option value="rusak_berat" {{ old('kondisi_alat', $pengembalian->kondisi_alat) == 'rusak_berat' ? 'selected' : '' }}>Rusak Berat</option>
                        </select>
                        @error('kondisi_alat')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="denda" class="form-label">Denda (Rp) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('denda') is-invalid @enderror" 
                               id="denda" name="denda" value="{{ old('denda', $pengembalian->denda) }}" min="0" required>
                        @error('denda')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <textarea class="form-control @error('keterangan') is-invalid @enderror" 
                                  id="keterangan" name="keterangan" rows="3">{{ old('keterangan', $pengembalian->keterangan) }}</textarea>
                        @error('keterangan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update
                        </button>
                        <a href="{{ route('admin.pengembalian.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection