@extends('layouts.app')

@section('title', 'Detail Pengembalian')
@section('page-title', 'Detail Pengembalian')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Detail Pengembalian</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="text-muted">Kode Peminjaman</h6>
                        <p class="mb-0 fw-bold">{{ $pengembalian->peminjaman->kode_peminjaman ?? '-' }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Tanggal Pengembalian</h6>
                        <p class="mb-0">{{ date('d/m/Y', strtotime($pengembalian->tanggal_pengembalian)) }}</p>
                    </div>
                </div>

                <hr>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="text-muted">Peminjam</h6>
                        <p class="mb-0">{{ $pengembalian->peminjaman->user->name ?? '-' }}</p>
                        <small class="text-muted">{{ $pengembalian->peminjaman->user->email ?? '-' }}</small>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Alat</h6>
                        <p class="mb-0">{{ $pengembalian->peminjaman->alat->nama_alat ?? '-' }}</p>
                        <small class="text-muted">{{ $pengembalian->peminjaman->alat->kode_alat ?? '-' }}</small>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <h6 class="text-muted">Jumlah Dikembalikan</h6>
                        <p class="mb-0">{{ $pengembalian->jumlah_dikembalikan }} unit</p>
                    </div>
                    <div class="col-md-4">
                        <h6 class="text-muted">Kondisi Alat</h6>
                        @php
                            $kondisiBadge = match($pengembalian->kondisi_alat) {
                                'baik' => 'bg-success',
                                'rusak_ringan' => 'bg-warning text-dark',
                                'rusak_berat' => 'bg-danger',
                                default => 'bg-secondary'
                            };
                        @endphp
                        <p class="mb-0">
                            <span class="badge {{ $kondisiBadge }}">
                                {{ ucfirst(str_replace('_', ' ', $pengembalian->kondisi_alat)) }}
                            </span>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <h6 class="text-muted">Total Denda</h6>
                        <p class="mb-0 fw-bold text-{{ $pengembalian->denda > 0 ? 'danger' : 'success' }}">
                            Rp {{ number_format($pengembalian->denda, 0, ',', '.') }}
                        </p>
                    </div>
                </div>

                @if($pengembalian->keterangan)
                    <div class="mb-3">
                        <h6 class="text-muted">Keterangan</h6>
                        <p class="mb-0">{{ $pengembalian->keterangan }}</p>
                    </div>
                @endif

                <div class="mb-3">
                    <h6 class="text-muted">Diterima Oleh</h6>
                    <p class="mb-0">{{ $pengembalian->petugas->name ?? '-' }}</p>
                </div>

                <hr>

                <div class="d-flex gap-2">
                    <a href="{{ route('admin.pengembalian.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                    <a href="{{ route('admin.pengembalian.edit', $pengembalian->id) }}" class="btn btn-warning">
                        <i class="fas fa-edit me-2"></i> Edit
                    </a>
                    <form action="{{ route('admin.pengembalian.destroy', $pengembalian->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i> Hapus
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Info Peminjaman</h6>
            </div>
            <div class="card-body">
                <p class="mb-2"><small><strong>Tanggal Pinjam:</strong></small></p>
                <p>{{ date('d/m/Y', strtotime($pengembalian->peminjaman->tanggal_pinjam)) }}</p>
                
                <p class="mb-2"><small><strong>Tanggal Kembali (Rencana):</strong></small></p>
                <p>{{ date('d/m/Y', strtotime($pengembalian->peminjaman->tanggal_kembali_rencana)) }}</p>
                
                <p class="mb-2"><small><strong>Jumlah Pinjam:</strong></small></p>
                <p>{{ $pengembalian->peminjaman->jumlah_pinjam }} unit</p>
            </div>
        </div>
    </div>
</div>
@endsection