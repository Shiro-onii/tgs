@extends('layouts.app')

@section('title', 'Kelola Pengembalian')
@section('page-title', 'Kelola Pengembalian')

@section('content')

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode Peminjaman</th>
                        <th>Peminjam</th>
                        <th>Alat</th>
                        <th>Tgl Pengembalian</th>
                        <th>Kondisi</th>
                        <th>Denda</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($pengembalians as $pengembalian)
                        <tr>
                            <td>{{ $pengembalian->peminjaman->kode_peminjaman ?? '-' }}</td>
                            <td>{{ $pengembalian->peminjaman->user->name ?? '-' }}</td>
                            <td>{{ $pengembalian->peminjaman->alat->nama_alat ?? '-' }}</td>
                            <td>{{ date('d/m/Y', strtotime($pengembalian->tanggal_pengembalian)) }}</td>
                            <td>
                                @php
                                    $kondisiBadge = match($pengembalian->kondisi_alat) {
                                        'baik' => 'bg-success',
                                        'rusak_ringan' => 'bg-warning text-dark',
                                        'rusak_berat' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                @endphp
                                <span class="badge {{ $kondisiBadge }}">
                                    {{ ucfirst(str_replace('_', ' ', $pengembalian->kondisi_alat)) }}
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-{{ $pengembalian->denda > 0 ? 'danger' : 'success' }}">
                                    Rp {{ number_format($pengembalian->denda, 0, ',', '.') }}
                                </span>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detailModal{{ $pengembalian->id }}">
                                    <i class="fas fa-eye"></i> Detail
                                </button>
                            </td>
                        </tr>

                        <!-- Detail Modal -->
                        <div class="modal fade" id="detailModal{{ $pengembalian->id }}" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Detail Pengembalian</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <table class="table table-borderless">
                                            <tr>
                                                <th width="40%">Kode Peminjaman</th>
                                                <td>{{ $pengembalian->peminjaman->kode_peminjaman ?? '-' }}</td>
                                            </tr>
                                            <tr>
                                                <th>Peminjam</th>
                                                <td>{{ $pengembalian->peminjaman->user->name ?? '-' }}</td>
                                            </tr>
                                            <tr>
                                                <th>Alat</th>
                                                <td>{{ $pengembalian->peminjaman->alat->nama_alat ?? '-' }}</td>
                                            </tr>
                                            <tr>
                                                <th>Jumlah Dikembalikan</th>
                                                <td>{{ $pengembalian->jumlah_dikembalikan }} unit</td>
                                            </tr>
                                            <tr>
                                                <th>Tanggal Pengembalian</th>
                                                <td>{{ date('d/m/Y', strtotime($pengembalian->tanggal_pengembalian)) }}</td>
                                            </tr>
                                            <tr>
                                                <th>Kondisi Alat</th>
                                                <td>
                                                    <span class="badge {{ $kondisiBadge }}">
                                                        {{ ucfirst(str_replace('_', ' ', $pengembalian->kondisi_alat)) }}
                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Denda</th>
                                                <td class="fw-bold text-{{ $pengembalian->denda > 0 ? 'danger' : 'success' }}">
                                                    Rp {{ number_format($pengembalian->denda, 0, ',', '.') }}
                                                </td>
                                            </tr>
                                            @if($pengembalian->keterangan)
                                                <tr>
                                                    <th>Keterangan</th>
                                                    <td>{{ $pengembalian->keterangan }}</td>
                                                </tr>
                                            @endif
                                            <tr>
                                                <th>Diterima Oleh</th>
                                                <td>{{ $pengembalian->petugas->name ?? '-' }}</td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada pengembalian
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $pengembalians->links() }}
        </div>
    </div>
</div>

@endsection