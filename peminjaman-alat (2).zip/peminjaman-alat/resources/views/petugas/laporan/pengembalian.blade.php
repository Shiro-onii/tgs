<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 12px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #000;
            padding-bottom: 20px;
        }
        
        .header h1 {
            font-size: 20px;
            margin-bottom: 5px;
        }
        
        .header h2 {
            font-size: 16px;
            font-weight: normal;
            margin-bottom: 10px;
        }
        
        .info {
            margin-bottom: 20px;
        }
        
        .info p {
            margin: 5px 0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        table th,
        table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        
        table th {
            background-color: #f0f0f0;
            font-weight: bold;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-right {
            text-align: right;
        }
        
        .footer {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature {
            text-align: center;
            width: 200px;
        }
        
        .signature-line {
            margin-top: 60px;
            border-top: 1px solid #000;
            padding-top: 5px;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
        }
        
        .badge-success {
            background-color: #28a745;
            color: #fff;
        }
        
        .badge-warning {
            background-color: #ffc107;
            color: #000;
        }
        
        .badge-danger {
            background-color: #dc3545;
            color: #fff;
        }
        
        @media print {
            .no-print {
                display: none;
            }
            
            body {
                padding: 0;
            }
        }
    </style>
</head>
<body>
    
    <!-- Header -->
    <div class="header">
        <h1>SISTEM PEMINJAMAN ALAT</h1>
        <h2>{{ $title }}</h2>
        <p>Periode: {{ date('d/m/Y', strtotime($tanggal_mulai)) }} s/d {{ date('d/m/Y', strtotime($tanggal_akhir)) }}</p>
    </div>
    
    <!-- Info -->
    <div class="info">
        <p><strong>Dicetak oleh:</strong> {{ auth()->user()->name }}</p>
        <p><strong>Tanggal Cetak:</strong> {{ date('d/m/Y H:i:s') }}</p>
        <p><strong>Total Data:</strong> {{ $data->count() }} pengembalian</p>
    </div>
    
    <!-- Tabel Laporan -->
    <table>
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="15%">Kode Peminjaman</th>
                <th width="18%">Peminjam</th>
                <th width="18%">Alat</th>
                <th width="8%">Jumlah</th>
                <th width="12%">Tgl Kembali</th>
                <th width="12%">Kondisi</th>
                <th width="12%">Denda</th>
            </tr>
        </thead>
        <tbody>
            @php $totalDenda = 0; @endphp
            @forelse($data as $index => $pengembalian)
                @php $totalDenda += $pengembalian->denda; @endphp
                <tr>
                    <td class="text-center">{{ $index + 1 }}</td>
                    <td>{{ $pengembalian->peminjaman->kode_peminjaman ?? '-' }}</td>
                    <td>{{ $pengembalian->peminjaman->user->name ?? '-' }}</td>
                    <td>{{ $pengembalian->peminjaman->alat->nama_alat ?? '-' }}</td>
                    <td class="text-center">{{ $pengembalian->jumlah_dikembalikan }}</td>
                    <td class="text-center">{{ date('d/m/Y', strtotime($pengembalian->tanggal_pengembalian)) }}</td>
                    <td class="text-center">
                        @php
                            $kondisiBadge = match($pengembalian->kondisi_alat) {
                                'baik' => 'badge-success',
                                'rusak_ringan' => 'badge-warning',
                                'rusak_berat' => 'badge-danger',
                                default => 'badge-secondary'
                            };
                        @endphp
                        <span class="badge {{ $kondisiBadge }}">
                            {{ ucfirst(str_replace('_', ' ', $pengembalian->kondisi_alat)) }}
                        </span>
                    </td>
                    <td class="text-right">Rp {{ number_format($pengembalian->denda, 0, ',', '.') }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="text-center">Tidak ada data</td>
                </tr>
            @endforelse
            
            @if($data->count() > 0)
                <tr style="background-color: #f0f0f0; font-weight: bold;">
                    <td colspan="7" class="text-right">TOTAL DENDA:</td>
                    <td class="text-right">Rp {{ number_format($totalDenda, 0, ',', '.') }}</td>
                </tr>
            @endif
        </tbody>
    </table>
    
    <!-- Summary -->
    <div style="margin-bottom: 30px;">
        <h3>Ringkasan</h3>
        <table style="width: 50%;">
            <tr>
                <td><strong>Kondisi Baik:</strong></td>
                <td class="text-right">{{ $data->where('kondisi_alat', 'baik')->count() }}</td>
            </tr>
            <tr>
                <td><strong>Kondisi Rusak Ringan:</strong></td>
                <td class="text-right">{{ $data->where('kondisi_alat', 'rusak_ringan')->count() }}</td>
            </tr>
            <tr>
                <td><strong>Kondisi Rusak Berat:</strong></td>
                <td class="text-right">{{ $data->where('kondisi_alat', 'rusak_berat')->count() }}</td>
            </tr>
            <tr style="border-top: 2px solid #000;">
                <td><strong>Total Pengembalian:</strong></td>
                <td class="text-right"><strong>{{ $data->count() }}</strong></td>
            </tr>
            <tr>
                <td><strong>Total Denda:</strong></td>
                <td class="text-right"><strong>Rp {{ number_format($totalDenda, 0, ',', '.') }}</strong></td>
            </tr>
        </table>
    </div>
    
    <!-- Footer / Signature -->
    <div class="footer">
        <div class="signature">
            <p>Mengetahui,</p>
            <div class="signature-line">
                <p>Kepala Unit</p>
            </div>
        </div>
        
        <div class="signature">
            <p>{{ date('d/m/Y') }}</p>
            <p>Petugas,</p>
            <div class="signature-line">
                <p>{{ auth()->user()->name }}</p>
            </div>
        </div>
    </div>
    
    <!-- Print Button -->
    <div class="no-print" style="text-align: center; margin-top: 30px;">
        <button onclick="window.print()" style="padding: 10px 30px; font-size: 14px; cursor: pointer; background: #007bff; color: white; border: none; border-radius: 5px;">
            <i class="fas fa-print"></i> Cetak Laporan
        </button>
        <button onclick="window.close()" style="padding: 10px 30px; font-size: 14px; cursor: pointer; background: #6c757d; color: white; border: none; border-radius: 5px; margin-left: 10px;">
            Tutup
        </button>
    </div>
    
</body>
</html>