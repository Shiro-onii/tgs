<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Aplikasi Peminjaman Alat')</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --sidebar-width: 250px;
            --topbar-height: 60px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
            color: white;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu li a {
            display: block;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .sidebar-menu li a:hover,
        .sidebar-menu li a.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left: 3px solid #3498db;
        }
        
        .sidebar-menu li a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }
        
        .topbar {
            background: white;
            height: var(--topbar-height);
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .content-wrapper {
            padding: 30px;
        }
        
        .user-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: #3498db;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .alert {
            animation: slideDown 0.3s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.show {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
    
    @stack('styles')
</head>
<body>
    
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0">
                <i class="fas fa-tools"></i> Peminjaman Alat
            </h4>
            <small>{{ ucfirst(auth()->user()->role) }}</small>
        </div>
        
        <ul class="sidebar-menu">
            <!-- Dashboard - Semua Role -->
            <li>
                <a href="{{ route('dashboard') }}" class="{{ request()->is('dashboard') ? 'active' : '' }}">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>
            
            @if(auth()->user()->role === 'admin')
                <!-- Menu Admin -->
                <li>
                    <a href="{{ route('admin.user.index') }}" class="{{ request()->is('admin/user*') ? 'active' : '' }}">
                        <i class="fas fa-users"></i> Kelola User
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.kategori.index') }}" class="{{ request()->is('admin/kategori*') ? 'active' : '' }}">
                        <i class="fas fa-list"></i> Kelola Kategori
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.alat.index') }}" class="{{ request()->is('admin/alat*') ? 'active' : '' }}">
                        <i class="fas fa-toolbox"></i> Kelola Alat
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.peminjaman.index') }}" class="{{ request()->is('admin/peminjaman*') ? 'active' : '' }}">
                        <i class="fas fa-handshake"></i> Data Peminjaman
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.pengembalian.index') }}" class="{{ request()->is('admin/pengembalian*') ? 'active' : '' }}">
                        <i class="fas fa-undo"></i> Data Pengembalian
                    </a>
                </li>
                <li>
                    <a href="{{ route('admin.logs.index') }}" class="{{ request()->is('admin/logs*') ? 'active' : '' }}">
                        <i class="fas fa-history"></i> Log Aktivitas
                    </a>
                </li>
                
            @elseif(auth()->user()->role === 'petugas')
                <!-- Menu Petugas -->
                <li>
                    <a href="{{ route('petugas.peminjaman.index') }}" class="{{ request()->is('petugas/peminjaman*') ? 'active' : '' }}">
                        <i class="fas fa-check-circle"></i> Approval Peminjaman
                    </a>
                </li>
                <li>
                    <a href="{{ route('petugas.pengembalian.index') }}" class="{{ request()->is('petugas/pengembalian*') ? 'active' : '' }}">
                        <i class="fas fa-eye"></i> Monitor Pengembalian
                    </a>
                </li>
                <li>
                    <a href="{{ route('petugas.laporan.index') }}" class="{{ request()->is('petugas/laporan*') ? 'active' : '' }}">
                        <i class="fas fa-print"></i> Cetak Laporan
                    </a>
                </li>
                
            @elseif(auth()->user()->role === 'peminjam')
                <!-- Menu Peminjam -->
                <li>
                    <a href="{{ route('peminjam.alat.index') }}" class="{{ request()->is('peminjam/alat*') ? 'active' : '' }}">
                        <i class="fas fa-toolbox"></i> Daftar Alat
                    </a>
                </li>
                <li>
                    <a href="{{ route('peminjam.peminjaman.index') }}" class="{{ request()->is('peminjam/peminjaman*') ? 'active' : '' }}">
                        <i class="fas fa-list-alt"></i> Peminjaman Saya
                    </a>
                </li>
            @endif
            
            <!-- Profile - Semua Role -->
            <li>
                <a href="{{ route('profile.edit') }}" class="{{ request()->is('profile*') ? 'active' : '' }}">
                    <i class="fas fa-user-circle"></i> Profil
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Topbar -->
        <div class="topbar">
            <div class="d-flex align-items-center">
                <button class="btn btn-link d-md-none" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h5 class="mb-0">@yield('page-title', 'Dashboard')</h5>
            </div>
            
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                    <div class="user-avatar me-2">
                        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                    </div>
                    <span>{{ auth()->user()->name }}</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="{{ route('profile.edit') }}"><i class="fas fa-user me-2"></i> Profil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form action="{{ route('logout') }}" method="POST">
                            @csrf
                            <button type="submit" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Content -->
        <div class="content-wrapper">
            <!-- Flash Messages -->
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif
            
            @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif
            
            @yield('content')
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Auto hide alerts
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
        
        // Sidebar toggle for mobile
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
            });
        }
    </script>
    
    @stack('scripts')
</body>
</html>