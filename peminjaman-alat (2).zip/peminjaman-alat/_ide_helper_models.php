<?php

// @formatter:off
// phpcs:ignoreFile
/**
 * A helper file for your Eloquent Models
 * Copy the phpDocs from this file to the correct Model,
 * And remove them from this file, to prevent double declarations.
 *
 * @author Barry vd. Heuvel <barryvdh@gmail.com>
 */


namespace App\Models{
/**
 * @property-read \App\Models\User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder<static>|ActivityLog newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|ActivityLog newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|ActivityLog query()
 */
	class ActivityLog extends \Eloquent {}
}

namespace App\Models{
/**
 * @property int $id
 * @property string $kode_alat
 * @property string $nama_alat
 * @property int $kategori_id
 * @property string|null $merek
 * @property string $kondisi
 * @property int $jumlah_total
 * @property int $jumlah_tersedia
 * @property string|null $foto
 * @property string|null $spesifikasi
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read mixed $foto_url
 * @property-read \App\Models\Kategori $kategori
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Peminjaman> $peminjaman
 * @property-read int|null $peminjaman_count
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat kondisi($kondisi)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat query()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat tersedia()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereFoto($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereJumlahTersedia($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereJumlahTotal($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereKategoriId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereKodeAlat($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereKondisi($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereMerek($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereNamaAlat($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereSpesifikasi($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Alat whereUpdatedAt($value)
 */
	class Alat extends \Eloquent {}
}

namespace App\Models{
/**
 * @property int $id
 * @property string $nama_kategori
 * @property string|null $deskripsi
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Alat> $alat
 * @property-read int|null $alat_count
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori query()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori whereDeskripsi($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori whereNamaKategori($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Kategori whereUpdatedAt($value)
 */
	class Kategori extends \Eloquent {}
}

namespace App\Models{
/**
 * @property int $id
 * @property string $kode_peminjaman
 * @property int $user_id
 * @property int $alat_id
 * @property int $jumlah_pinjam
 * @property \Illuminate\Support\Carbon $tanggal_pinjam
 * @property \Illuminate\Support\Carbon $tanggal_kembali_rencana
 * @property \Illuminate\Support\Carbon|null $tanggal_kembali_aktual
 * @property string $keperluan
 * @property string $status
 * @property string|null $catatan_petugas
 * @property int|null $disetujui_oleh
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Alat $alat
 * @property-read mixed $durasi
 * @property-read \App\Models\Pengembalian|null $pengembalian
 * @property-read \App\Models\User|null $petugas
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman dipinjam()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman menunggu()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman query()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman status($status)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereAlatId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereCatatanPetugas($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereDisetujuiOleh($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereJumlahPinjam($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereKeperluan($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereKodePeminjaman($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereStatus($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereTanggalKembaliAktual($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereTanggalKembaliRencana($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereTanggalPinjam($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Peminjaman whereUserId($value)
 */
	class Peminjaman extends \Eloquent {}
}

namespace App\Models{
/**
 * @property int $id
 * @property int $peminjaman_id
 * @property \Illuminate\Support\Carbon $tanggal_pengembalian
 * @property string $kondisi_alat
 * @property int $jumlah_dikembalikan
 * @property numeric $denda
 * @property string|null $keterangan
 * @property int $diterima_oleh
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Peminjaman $peminjaman
 * @property-read \App\Models\User $petugas
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian query()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereDenda($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereDiterimaOleh($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereJumlahDikembalikan($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereKeterangan($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereKondisiAlat($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian wherePeminjamanId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereTanggalPengembalian($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|Pengembalian whereUpdatedAt($value)
 */
	class Pengembalian extends \Eloquent {}
}

namespace App\Models{
/**
 * @property int $id
 * @property string $name
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property string $password
 * @property string $role
 * @property string|null $nohp
 * @property string|null $alamat
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\ActivityLog> $activityLogs
 * @property-read int|null $activity_logs_count
 * @property-read \Illuminate\Notifications\DatabaseNotificationCollection<int, \Illuminate\Notifications\DatabaseNotification> $notifications
 * @property-read int|null $notifications_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Peminjaman> $peminjaman
 * @property-read int|null $peminjaman_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Peminjaman> $peminjaman_disetujui
 * @property-read int|null $peminjaman_disetujui_count
 * @method static \Database\Factories\UserFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User query()
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User role($role)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereAlamat($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereEmailVerifiedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereNohp($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereRole($value)
 * @method static \Illuminate\Database\Eloquent\Builder<static>|User whereUpdatedAt($value)
 */
	class User extends \Eloquent {}
}

