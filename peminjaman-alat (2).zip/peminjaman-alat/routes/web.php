<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;

// Admin Controllers
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\KategoriController;
use App\Http\Controllers\Admin\AlatController as AdminAlatController;
use App\Http\Controllers\Admin\PeminjamanController as AdminPeminjamanController;
use App\Http\Controllers\Admin\PengembalianController as AdminPengembalianController;
use App\Http\Controllers\Admin\ActivityLogController;

// Petugas Controllers
use App\Http\Controllers\Petugas\PeminjamanController as PetugasPeminjamanController;
use App\Http\Controllers\Petugas\PengembalianController as PetugasPengembalianController;
use App\Http\Controllers\Petugas\LaporanController;

// Peminjam Controllers
use App\Http\Controllers\Peminjam\AlatController as PeminjamAlatController;
use App\Http\Controllers\Peminjam\PeminjamanController as PeminjamPeminjamanController;
use App\Http\Controllers\Peminjam\PengembalianController as PeminjamPengembalianController;

/*
|--------------------------------------------------------------------------
| Public & Guest Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
});

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

/*
|--------------------------------------------------------------------------
| Shared Authenticated Routes
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
});

/*
|--------------------------------------------------------------------------
| ADMIN ROUTES
| Fitur: CRUD User, Kategori, Alat, Peminjaman, Pengembalian, Log
|--------------------------------------------------------------------------
*/

Route::prefix('admin')->middleware(['auth', 'role:admin'])->name('admin.')->group(function () {
    
    // User Management
    Route::resource('user', UserController::class);
    
    // Kategori Management
    Route::resource('kategori', KategoriController::class);
    
    // Alat Management
    Route::resource('alat', AdminAlatController::class);
    
    // Peminjaman Management (FULL CRUD)
    Route::resource('peminjaman', AdminPeminjamanController::class);
    
    // Pengembalian Management (FULL CRUD)
    Route::resource('pengembalian', AdminPengembalianController::class);
    
    // Activity Logs
    Route::get('logs', [ActivityLogController::class, 'index'])->name('logs.index');
});

/*
|--------------------------------------------------------------------------
| PETUGAS ROUTES
| Fitur: Menyetujui Peminjaman, Memantau Pengembalian, Cetak Laporan
|--------------------------------------------------------------------------
*/

Route::prefix('petugas')->middleware(['auth', 'role:petugas'])->name('petugas.')->group(function () {
    
    // Peminjaman - Approval (Menyetujui)
    Route::get('peminjaman', [PetugasPeminjamanController::class, 'index'])->name('peminjaman.index');
    Route::get('peminjaman/{peminjaman}', [PetugasPeminjamanController::class, 'show'])->name('peminjaman.show');
    Route::post('peminjaman/{peminjaman}/approve', [PetugasPeminjamanController::class, 'approve'])->name('peminjaman.approve');
    Route::post('peminjaman/{peminjaman}/reject', [PetugasPeminjamanController::class, 'reject'])->name('peminjaman.reject');
    
    // Pengembalian - Monitor Only (Memantau - READ ONLY)
    Route::get('pengembalian', [PetugasPengembalianController::class, 'index'])->name('pengembalian.index');
    Route::get('pengembalian/{pengembalian}', [PetugasPengembalianController::class, 'show'])->name('pengembalian.show');
    
    // Laporan - Cetak
    Route::get('laporan', [LaporanController::class, 'index'])->name('laporan.index');
    Route::post('laporan/cetak', [LaporanController::class, 'cetak'])->name('laporan.cetak');
});

/*
|--------------------------------------------------------------------------
| PEMINJAM ROUTES
| Fitur: Melihat Alat, Mengajukan Peminjaman, Mengembalikan Alat
|--------------------------------------------------------------------------
*/

Route::prefix('peminjam')->middleware(['auth', 'role:peminjam'])->name('peminjam.')->group(function () {
    
    // Melihat Daftar Alat (READ ONLY)
    Route::get('alat', [PeminjamAlatController::class, 'index'])->name('alat.index');
    
    // Mengajukan Peminjaman
    Route::get('peminjaman', [PeminjamPeminjamanController::class, 'index'])->name('peminjaman.index');
    Route::get('peminjaman/create', [PeminjamPeminjamanController::class, 'create'])->name('peminjaman.create');
    Route::post('peminjaman', [PeminjamPeminjamanController::class, 'store'])->name('peminjaman.store');
    Route::get('peminjaman/{peminjaman}', [PeminjamPeminjamanController::class, 'show'])->name('peminjaman.show');
    
    // Mengembalikan Alat (CREATE PENGEMBALIAN)
    Route::get('pengembalian/create', [PeminjamPengembalianController::class, 'create'])->name('pengembalian.create');
    Route::post('pengembalian', [PeminjamPengembalianController::class, 'store'])->name('pengembalian.store');
});

Route::fallback(function () {
    abort(404, 'Halaman tidak ditemukan');
});