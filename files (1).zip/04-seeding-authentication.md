# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 4: Seeding Data dan Authentication

### 📚 Apa itu Seeder?

Seeder adalah cara untuk mengisi database dengan data awal (dummy data). Berguna untuk:
- Testing aplikasi
- Membuat data sample
- Initialize data system (contoh: admin user, kategori default)

#### 🎯 Analogi Sederhana

Bayangkan Anda buka toko baru:
- **Tanpa Seeder**: Toko kosong, harus isi manual satu-satu
- **Dengan Seeder**: Langsung ada produk display untuk demo

---

### 🌱 Membuat Seeder

#### 1. Seeder untuk Kategori

```bash
php artisan make:seeder KategoriSeeder
```

Edit file `database/seeders/KategoriSeeder.php`:

```php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Kategori;

class KategoriSeeder extends Seeder
{
    public function run(): void
    {
        $kategoris = [
            [
                'nama_kategori' => 'Elektronik',
                'deskripsi' => 'Peralatan elektronik seperti laptop, komputer, printer',
            ],
            [
                'nama_kategori' => 'Multimedia',
                'deskripsi' => 'Peralatan multimedia seperti kamera, proyektor, speaker',
            ],
            [
                'nama_kategori' => 'Olahraga',
                'deskripsi' => 'Peralatan olahraga seperti bola, net, raket',
            ],
            [
                'nama_kategori' => 'Laboratorium',
                'deskripsi' => 'Peralatan laboratorium seperti mikroskop, tabung reaksi',
            ],
            [
                'nama_kategori' => 'Perkakas',
                'deskripsi' => 'Perkakas seperti tang, obeng, bor',
            ],
        ];

        foreach ($kategoris as $kategori) {
            Kategori::create($kategori);
        }
    }
}
```

#### 2. Seeder untuk User (Admin, Petugas, Peminjam)

```bash
php artisan make:seeder UserSeeder
```

Edit file `database/seeders/UserSeeder.php`:

```php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        User::create([
            'name' => 'Administrator',
            'email' => 'admin@gmail.com',
            'password' => Hash::make('password'), // JANGAN gunakan password ini di production!
            'role' => 'admin',
            'phone' => '081234567890',
            'address' => 'Jl. Admin No. 1',
        ]);

        // Petugas
        User::create([
            'name' => 'Petugas Satu',
            'email' => 'petugas@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'petugas',
            'phone' => '081234567891',
            'address' => 'Jl. Petugas No. 1',
        ]);

        User::create([
            'name' => 'Petugas Dua',
            'email' => 'petugas2@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'petugas',
            'phone' => '081234567892',
            'address' => 'Jl. Petugas No. 2',
        ]);

        // Peminjam
        User::create([
            'name' => 'John Doe',
            'email' => 'peminjam@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'peminjam',
            'phone' => '081234567893',
            'address' => 'Jl. Peminjam No. 1',
        ]);

        User::create([
            'name' => 'Jane Smith',
            'email' => 'peminjam2@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'peminjam',
            'phone' => '081234567894',
            'address' => 'Jl. Peminjam No. 2',
        ]);
    }
}
```

#### 3. Seeder untuk Alat

```bash
php artisan make:seeder AlatSeeder
```

Edit file `database/seeders/AlatSeeder.php`:

```php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Alat;

class AlatSeeder extends Seeder
{
    public function run(): void
    {
        $alats = [
            // Elektronik
            [
                'kode_alat' => 'ELK001',
                'nama_alat' => 'Laptop ASUS ROG',
                'kategori_id' => 1,
                'merk' => 'ASUS',
                'kondisi' => 'baik',
                'jumlah_total' => 5,
                'jumlah_tersedia' => 5,
                'spesifikasi' => 'Intel Core i7, RAM 16GB, SSD 512GB, RTX 3060',
            ],
            [
                'kode_alat' => 'ELK002',
                'nama_alat' => 'Printer Epson L3210',
                'kategori_id' => 1,
                'merk' => 'Epson',
                'kondisi' => 'baik',
                'jumlah_total' => 3,
                'jumlah_tersedia' => 3,
                'spesifikasi' => 'All-in-One: Print, Scan, Copy',
            ],
            [
                'kode_alat' => 'ELK003',
                'nama_alat' => 'Monitor LG 24 inch',
                'kategori_id' => 1,
                'merk' => 'LG',
                'kondisi' => 'baik',
                'jumlah_total' => 10,
                'jumlah_tersedia' => 10,
                'spesifikasi' => 'Full HD, IPS Panel, HDMI, VGA',
            ],

            // Multimedia
            [
                'kode_alat' => 'MLT001',
                'nama_alat' => 'Kamera Canon EOS 90D',
                'kategori_id' => 2,
                'merk' => 'Canon',
                'kondisi' => 'baik',
                'jumlah_total' => 2,
                'jumlah_tersedia' => 2,
                'spesifikasi' => '32.5 MP, 4K Video, Dual Pixel AF',
            ],
            [
                'kode_alat' => 'MLT002',
                'nama_alat' => 'Proyektor Epson EB-X06',
                'kategori_id' => 2,
                'merk' => 'Epson',
                'kondisi' => 'baik',
                'jumlah_total' => 4,
                'jumlah_tersedia' => 4,
                'spesifikasi' => '3600 Lumens, XGA Resolution',
            ],
            [
                'kode_alat' => 'MLT003',
                'nama_alat' => 'Speaker JBL Partybox 310',
                'kategori_id' => 2,
                'merk' => 'JBL',
                'kondisi' => 'baik',
                'jumlah_total' => 2,
                'jumlah_tersedia' => 2,
                'spesifikasi' => 'Portable, Bluetooth, 240W Output Power',
            ],

            // Olahraga
            [
                'kode_alat' => 'OLR001',
                'nama_alat' => 'Bola Basket Molten',
                'kategori_id' => 3,
                'merk' => 'Molten',
                'kondisi' => 'baik',
                'jumlah_total' => 15,
                'jumlah_tersedia' => 15,
                'spesifikasi' => 'Size 7, Rubber Material',
            ],
            [
                'kode_alat' => 'OLR002',
                'nama_alat' => 'Net Voli Mikasa',
                'kategori_id' => 3,
                'merk' => 'Mikasa',
                'kondisi' => 'baik',
                'jumlah_total' => 3,
                'jumlah_tersedia' => 3,
                'spesifikasi' => 'Standar Internasional, 9.5m x 1m',
            ],

            // Laboratorium
            [
                'kode_alat' => 'LAB001',
                'nama_alat' => 'Mikroskop Olympus',
                'kategori_id' => 4,
                'merk' => 'Olympus',
                'kondisi' => 'baik',
                'jumlah_total' => 8,
                'jumlah_tersedia' => 8,
                'spesifikasi' => 'Binocular, 40x-1000x Magnification',
            ],
            [
                'kode_alat' => 'LAB002',
                'nama_alat' => 'Tabung Reaksi Pyrex',
                'kategori_id' => 4,
                'merk' => 'Pyrex',
                'kondisi' => 'baik',
                'jumlah_total' => 50,
                'jumlah_tersedia' => 50,
                'spesifikasi' => 'Borosilicate Glass, 15ml',
            ],

            // Perkakas
            [
                'kode_alat' => 'PRK001',
                'nama_alat' => 'Bor Listrik Bosch',
                'kategori_id' => 5,
                'merk' => 'Bosch',
                'kondisi' => 'baik',
                'jumlah_total' => 4,
                'jumlah_tersedia' => 4,
                'spesifikasi' => '13mm Chuck, 550W Motor Power',
            ],
            [
                'kode_alat' => 'PRK002',
                'nama_alat' => 'Tool Set Stanley 150pcs',
                'kategori_id' => 5,
                'merk' => 'Stanley',
                'kondisi' => 'baik',
                'jumlah_total' => 2,
                'jumlah_tersedia' => 2,
                'spesifikasi' => '150 pieces, Complete hand tool set',
            ],
        ];

        foreach ($alats as $alat) {
            Alat::create($alat);
        }
    }
}
```

#### 4. Update DatabaseSeeder

Edit file `database/seeders/DatabaseSeeder.php`:

```php
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Panggil seeder sesuai urutan (karena ada foreign key)
        $this->call([
            UserSeeder::class,
            KategoriSeeder::class,
            AlatSeeder::class,
        ]);
    }
}
```

#### 5. Jalankan Seeder

```bash
# Jalankan semua seeder
php artisan db:seed

# Atau migrate fresh + seed (drop semua tabel, buat ulang, seed)
php artisan migrate:fresh --seed

# Jalankan seeder tertentu saja
php artisan db:seed --class=UserSeeder
```

**Cek di phpMyAdmin:**
- Tabel `users` ada 5 data
- Tabel `kategori` ada 5 data
- Tabel `alat` ada 12 data

---

### 🔐 Authentication (Login/Register) - Manual

Kita akan buat authentication dari nol tanpa menggunakan package tambahan seperti Breeze. Ini memberikan kontrol penuh dan pemahaman lebih baik tentang cara kerja authentication di Laravel.

#### 1. Buat Controller untuk Authentication

```bash
php artisan make:controller AuthController
```

Edit file `app/Http/Controllers/AuthController.php`:

```php
<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    /**
     * Tampilkan form login
     */
    public function showLogin()
    {
        return view('auth.login');
    }

    /**
     * Proses login
     */
    public function login(Request $request)
    {
        // Validasi input
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ], [
            'email.required' => 'Email wajib diisi',
            'email.email' => 'Format email tidak valid',
            'password.required' => 'Password wajib diisi',
            'password.min' => 'Password minimal 8 karakter',
        ]);

        // Coba login
        if (Auth::attempt($credentials, $request->filled('remember'))) {
            // Regenerate session untuk keamanan
            $request->session()->regenerate();

            // Log aktivitas
            ActivityLog::log('LOGIN', 'User berhasil login');

            // Redirect berdasarkan role
            $user = Auth::user();
            
            if ($user->role === 'admin') {
                return redirect()->intended('/admin/dashboard');
            } elseif ($user->role === 'petugas') {
                return redirect()->intended('/petugas/dashboard');
            } else {
                return redirect()->intended('/dashboard');
            }
        }

        // Login gagal
        return back()->withErrors([
            'email' => 'Email atau password salah.',
        ])->onlyInput('email');
    }

    /**
     * Tampilkan form register
     */
    public function showRegister()
    {
        return view('auth.register');
    }

    /**
     * Proses registrasi
     */
    public function register(Request $request)
    {
        // Validasi input
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
        ], [
            'name.required' => 'Nama wajib diisi',
            'email.required' => 'Email wajib diisi',
            'email.email' => 'Format email tidak valid',
            'email.unique' => 'Email sudah terdaftar',
            'password.required' => 'Password wajib diisi',
            'password.min' => 'Password minimal 8 karakter',
            'password.confirmed' => 'Konfirmasi password tidak cocok',
        ]);

        // Buat user baru
        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => 'peminjam', // Default role
            'phone' => $validated['phone'] ?? null,
            'address' => $validated['address'] ?? null,
        ]);

        // Auto login setelah register
        Auth::login($user);

        // Log aktivitas
        ActivityLog::log('REGISTER', 'User baru melakukan registrasi');

        return redirect('/dashboard')->with('success', 'Registrasi berhasil! Selamat datang.');
    }

    /**
     * Logout
     */
    public function logout(Request $request)
    {
        // Log aktivitas sebelum logout
        ActivityLog::log('LOGOUT', 'User logout dari sistem');

        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login')->with('success', 'Anda telah logout.');
    }
}
```

#### 2. Buat Routes untuk Authentication

Edit file `routes/web.php`:

```php
<?php

use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

// Public routes
Route::get('/', function () {
    return view('welcome');
});

// Authentication routes (guest only)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

// Logout route (authenticated only)
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// Protected routes
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
```

#### 3. Buat View untuk Login

Buat file `resources/views/auth/login.blade.php`:

```blade
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Peminjaman Alat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center" style="min-height: 100vh; align-items: center;">
            <div class="col-md-5">
                <div class="card shadow">
                    <div class="card-body p-5">
                        <h3 class="text-center mb-4">Login</h3>
                        
                        @if(session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif

                        @if($errors->any())
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form method="POST" action="{{ route('login') }}">
                            @csrf
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                       id="email" name="email" value="{{ old('email') }}" required autofocus>
                                @error('email')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                       id="password" name="password" required>
                                @error('password')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">Remember Me</label>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>

                        <div class="text-center mt-3">
                            <p>Belum punya akun? <a href="{{ route('register') }}">Daftar di sini</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
```

#### 4. Buat View untuk Register

Buat file `resources/views/auth/register.blade.php`:

```blade
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Sistem Peminjaman Alat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center" style="min-height: 100vh; align-items: center;">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body p-5">
                        <h3 class="text-center mb-4">Registrasi</h3>
                        
                        @if($errors->any())
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <form method="POST" action="{{ route('register') }}">
                            @csrf
                            
                            <div class="mb-3">
                                <label for="name" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                       id="name" name="name" value="{{ old('name') }}" required>
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control @error('email') is-invalid @enderror" 
                                       id="email" name="email" value="{{ old('email') }}" required>
                                @error('email')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control @error('password') is-invalid @enderror" 
                                           id="password" name="password" required>
                                    @error('password')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="password_confirmation" class="form-label">Konfirmasi Password</label>
                                    <input type="password" class="form-control" 
                                           id="password_confirmation" name="password_confirmation" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="phone" class="form-label">No. Telepon (Opsional)</label>
                                <input type="text" class="form-control" id="phone" name="phone" value="{{ old('phone') }}">
                            </div>

                            <div class="mb-3">
                                <label for="address" class="form-label">Alamat (Opsional)</label>
                                <textarea class="form-control" id="address" name="address" rows="2">{{ old('address') }}</textarea>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Daftar</button>
                        </form>

                        <div class="text-center mt-3">
                            <p>Sudah punya akun? <a href="{{ route('login') }}">Login di sini</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
```

#### 5. Testing Authentication

```bash
# Jalankan server
php artisan serve
```

Buka browser:

**Test Register:**
1. Buka http://localhost:8000/register
2. Isi form dengan data:
   - Nama: John Doe
   - Email: john@example.com
   - Password: password123
   - Konfirmasi Password: password123
3. Klik Daftar
4. Otomatis login dan redirect ke dashboard

**Test Login:**
1. Logout dulu
2. Buka http://localhost:8000/login
3. Login dengan:
   - Email: admin@gmail.com
   - Password: password
4. Redirect ke dashboard sesuai role

**SUKSES!** Authentication manual sudah berjalan

---

### 🛡️ Middleware

Middleware adalah "filter" yang berjalan sebelum request sampai ke controller.

#### Middleware Bawaan Laravel:

1. **auth**: Cek apakah user sudah login
2. **guest**: Cek apakah user belum login (untuk halaman login/register)
3. **verified**: Cek apakah email sudah diverifikasi
4. **throttle**: Rate limiting (batasi jumlah request)

#### Contoh Penggunaan Middleware:

```php
// Satu middleware
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware('auth');

// Multiple middleware
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified']);

// Group routes dengan middleware yang sama
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
    Route::get('/profile', [ProfileController::class, 'edit']);
});
```

#### Membuat Middleware untuk Role

Kita perlu middleware untuk cek role user (admin/petugas/peminjam).

```bash
php artisan make:middleware CheckRole
```

Edit file `app/Http/Middleware/CheckRole.php`:

```php
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        // Cek apakah user sudah login
        if (!auth()->check()) {
            return redirect('/login');
        }

        // Cek apakah role user sesuai
        if (!in_array(auth()->user()->role, $roles)) {
            abort(403, 'Unauthorized action.');
        }

        return $next($request);
    }
}
```

**Daftar Middleware:**

Edit file `bootstrap/app.php`:

```php
<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Register middleware alias
        $middleware->alias([
            'role' => \App\Http\Middleware\CheckRole::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
```

**Cara Pakai:**

```php
// Route hanya untuk admin
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'index']);
});

// Route untuk admin dan petugas
Route::middleware(['auth', 'role:admin,petugas'])->group(function () {
    Route::get('/peminjaman', [PeminjamanController::class, 'index']);
});

// Route untuk semua user yang login
Route::middleware(['auth'])->group(function () {
    Route::get('/profil', [ProfilController::class, 'index']);
});
```

---

### 🔑 Helper Authentication

Laravel menyediakan helper untuk check authentication:

```php
// Cek apakah user sudah login
if (auth()->check()) {
    // User sudah login
}

// Cek apakah user belum login
if (auth()->guest()) {
    // User belum login
}

// Ambil data user yang login
$user = auth()->user();
echo $user->name;
echo $user->email;
echo $user->role;

// Ambil ID user yang login
$userId = auth()->id();

// Login user secara manual
auth()->login($user);

// Logout user
auth()->logout();

// Di Blade (view)
@auth
    <p>Halo, {{ auth()->user()->name }}</p>
@endauth

@guest
    <p>Silakan login</p>
@endguest

// Check role
@if(auth()->user()->isAdmin())
    <a href="/admin">Dashboard Admin</a>
@endif
```

---

### 📝 Buat Dashboard Sederhana

Buat file `resources/views/dashboard.blade.php`:

```blade
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Peminjaman Alat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Sistem Peminjaman Alat</a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text text-white me-3">
                    {{ auth()->user()->name }} ({{ ucfirst(auth()->user()->role) }})
                </span>
                <form method="POST" action="{{ route('logout') }}" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-outline-light btn-sm">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <h2>Selamat Datang, {{ auth()->user()->name }}!</h2>
        <p>Role Anda: <strong>{{ ucfirst(auth()->user()->role) }}</strong></p>
        
        <div class="card mt-4">
            <div class="card-body">
                <h5>Dashboard akan dikembangkan di sini</h5>
                <p>Fitur CRUD akan ditambahkan di bagian selanjutnya.</p>
            </div>
        </div>
    </div>
</body>
</html>
```

---

### 📝 Latihan

1. **Register user baru:**
   - Buka http://localhost:8000/register
   - Daftar dengan data Anda
   - Login dengan akun baru

2. **Test Role Middleware:**
   - Buat route test di `routes/web.php`:

```php
Route::middleware(['auth', 'role:admin'])->get('/admin-only', function () {
    return 'Halaman ini hanya untuk Admin';
});

Route::middleware(['auth', 'role:petugas'])->get('/petugas-only', function () {
    return 'Halaman ini hanya untuk Petugas';
});
```

   - Login sebagai admin (admin@gmail.com / password)
   - Akses http://localhost:8000/admin-only (BERHASIL)
   - Akses http://localhost:8000/petugas-only (ERROR 403)

---

### 🎯 Rangkuman

Di bagian ini Anda sudah belajar:

✅ Membuat Seeder untuk data awal  
✅ Install Laravel Breeze  
✅ Login dan Register  
✅ Middleware untuk proteksi route  
✅ Custom Middleware untuk check role  
✅ Helper authentication  
✅ Customize redirect dan form  

**Langkah Selanjutnya:**

Di bagian 5, kita akan belajar:
- Membuat Controller
- CRUD untuk Kategori
- CRUD untuk Alat
- Upload file (foto alat)

---

*Anda sudah menguasai authentication! Selanjutnya kita mulai buat fitur CRUD! 🚀*
