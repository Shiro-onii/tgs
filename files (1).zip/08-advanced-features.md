# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 8: Advanced Features & Best Practices

---

## 📋 Daftar Isi

1. [ERD (Entity Relationship Diagram)](#1-erd-entity-relationship-diagram)
2. [Database: Stored Procedure, Function, Trigger](#2-database-stored-procedure-function-trigger)
3. [Struktur Folder Project](#3-struktur-folder-project)
4. [Coding Guidelines & Best Practices](#4-coding-guidelines--best-practices)
5. [Testing & Test Cases](#5-testing--test-cases)
6. [Laporan Singkat](#6-laporan-singkat)

---

## 1. ERD (Entity Relationship Diagram)

### Membuat ERD untuk Database

ERD (Entity Relationship Diagram) adalah diagram yang menggambarkan hubungan antar tabel dalam database.

**Tools untuk membuat ERD:**
- draw.io (https://draw.io) - Gratis
- dbdiagram.io (https://dbdiagram.io) - Gratis, khusus database
- MySQL Workbench - Gratis

### ERD Aplikasi Peminjaman Alat

```
┌─────────────────────┐
│       USERS         │
├─────────────────────┤
│ PK  id              │
│     name            │
│     email (unique)  │
│     password        │
│     role (enum)     │
│     phone           │
│     address         │
│     created_at      │
│     updated_at      │
└─────────────────────┘
         │ 1
         │
         │ N
         ▼
┌─────────────────────┐         ┌─────────────────────┐
│    PEMINJAMAN       │    N    │       ALAT          │
├─────────────────────┤◄────────┤─────────────────────┤
│ PK  id              │    1    │ PK  id              │
│ FK  user_id         │         │     kode_alat       │
│ FK  alat_id         │         │     nama_alat       │
│ FK  disetujui_oleh  │         │ FK  kategori_id     │
│     kode_peminjaman │         │     merk            │
│     jumlah_pinjam   │         │     kondisi (enum)  │
│     tanggal_pinjam  │         │     jumlah_total    │
│     tgl_kembali_..  │         │     jumlah_tersedia │
│     tgl_kembali_..  │         │     foto            │
│     keperluan       │         │     spesifikasi     │
│     status (enum)   │         │     created_at      │
│     catatan_petugas │         │     updated_at      │
│     created_at      │         └─────────────────────┘
│     updated_at      │                   │ N
└─────────────────────┘                   │
         │ 1                              │ 1
         │                                ▼
         │ 1                    ┌─────────────────────┐
         ▼                      │      KATEGORI       │
┌─────────────────────┐         ├─────────────────────┤
│   PENGEMBALIAN      │         │ PK  id              │
├─────────────────────┤         │     nama_kategori   │
│ PK  id              │         │     deskripsi       │
│ FK  peminjaman_id   │         │     created_at      │
│ FK  diterima_oleh   │         │     updated_at      │
│     tgl_pengembalian│         └─────────────────────┘
│     kondisi_alat    │
│     jumlah_dikemba..│
│     denda           │
│     keterangan      │
│     created_at      │
│     updated_at      │
└─────────────────────┘


         ┌─────────────────────┐
         │   ACTIVITY_LOGS     │
         ├─────────────────────┤
         │ PK  id              │
         │ FK  user_id         │
         │     activity        │
         │     description     │
         │     ip_address      │
         │     user_agent      │
         │     created_at      │
         │     updated_at      │
         └─────────────────────┘
```

**Relasi:**
- Users (1) → Peminjaman (N)
- Users (1) → Activity Logs (N)
- Kategori (1) → Alat (N)
- Alat (1) → Peminjaman (N)
- Peminjaman (1) → Pengembalian (1)
- Users (1) → Peminjaman.disetujui_oleh (N)
- Users (1) → Pengembalian.diterima_oleh (N)

---

## 2. Database: Stored Procedure, Function, Trigger

### Stored Procedure

Stored Procedure adalah sekumpulan SQL statements yang disimpan di database dan bisa dipanggil berulang kali.

#### Membuat Stored Procedure untuk Perhitungan Denda

```sql
-- File: database/migrations/xxxx_create_stored_procedures.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        DB::unprepared('
            DROP PROCEDURE IF EXISTS calculate_denda;
            
            CREATE PROCEDURE calculate_denda(
                IN peminjaman_id INT,
                IN tgl_kembali_aktual DATE,
                IN kondisi_alat VARCHAR(50),
                IN jumlah_dikembalikan INT,
                OUT total_denda DECIMAL(10,2)
            )
            BEGIN
                DECLARE tgl_rencana DATE;
                DECLARE hari_terlambat INT;
                DECLARE denda_terlambat DECIMAL(10,2);
                DECLARE denda_kerusakan DECIMAL(10,2);
                
                -- Ambil tanggal kembali rencana
                SELECT tanggal_kembali_rencana INTO tgl_rencana
                FROM peminjaman
                WHERE id = peminjaman_id;
                
                -- Hitung hari terlambat
                SET hari_terlambat = GREATEST(0, DATEDIFF(tgl_kembali_aktual, tgl_rencana));
                
                -- Hitung denda keterlambatan (Rp 10.000/hari)
                SET denda_terlambat = hari_terlambat * 10000;
                
                -- Hitung denda kerusakan
                SET denda_kerusakan = 0;
                IF kondisi_alat = "rusak_ringan" THEN
                    SET denda_kerusakan = 50000 * jumlah_dikembalikan;
                ELSEIF kondisi_alat = "rusak_berat" THEN
                    SET denda_kerusakan = 200000 * jumlah_dikembalikan;
                END IF;
                
                -- Total denda
                SET total_denda = denda_terlambat + denda_kerusakan;
            END
        ');
    }

    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS calculate_denda');
    }
};
```

**Cara Memanggil Stored Procedure di Laravel:**

```php
// Di Controller atau Service
public function hitungDenda($peminjamanId, $tglKembali, $kondisi, $jumlah)
{
    $result = DB::select('CALL calculate_denda(?, ?, ?, ?, @total)', [
        $peminjamanId,
        $tglKembali,
        $kondisi,
        $jumlah
    ]);
    
    $denda = DB::select('SELECT @total as total')[0]->total;
    
    return $denda;
}
```

### Function

Database function mirip stored procedure tapi mengembalikan nilai.

#### Membuat Function untuk Generate Kode Peminjaman

```sql
-- File: database/migrations/xxxx_create_functions.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        DB::unprepared('
            DROP FUNCTION IF EXISTS generate_kode_peminjaman;
            
            CREATE FUNCTION generate_kode_peminjaman()
            RETURNS VARCHAR(50)
            DETERMINISTIC
            BEGIN
                DECLARE new_kode VARCHAR(50);
                DECLARE counter INT;
                
                -- Ambil jumlah peminjaman hari ini
                SELECT COUNT(*) + 1 INTO counter
                FROM peminjaman
                WHERE DATE(created_at) = CURDATE();
                
                -- Generate kode: PJM + YYYYMMDD + counter (3 digit)
                SET new_kode = CONCAT(
                    "PJM",
                    DATE_FORMAT(NOW(), "%Y%m%d"),
                    LPAD(counter, 3, "0")
                );
                
                RETURN new_kode;
            END
        ');
    }

    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS generate_kode_peminjaman');
    }
};
```

**Cara Memanggil Function:**

```php
// Di Controller atau Model
$kodePeminjaman = DB::select('SELECT generate_kode_peminjaman() as kode')[0]->kode;
```

### Trigger

Trigger adalah aksi otomatis yang terjadi saat event tertentu (INSERT, UPDATE, DELETE).

#### Trigger untuk Update Stok Alat

```sql
-- File: database/migrations/xxxx_create_triggers.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        // Trigger saat peminjaman disetujui
        DB::unprepared('
            DROP TRIGGER IF EXISTS update_stok_after_approve;
            
            CREATE TRIGGER update_stok_after_approve
            AFTER UPDATE ON peminjaman
            FOR EACH ROW
            BEGIN
                -- Jika status berubah dari "menunggu" ke "disetujui"
                IF OLD.status = "menunggu" AND NEW.status = "disetujui" THEN
                    -- Kurangi stok
                    UPDATE alat
                    SET jumlah_tersedia = jumlah_tersedia - NEW.jumlah_pinjam
                    WHERE id = NEW.alat_id;
                END IF;
            END
        ');
        
        // Trigger saat pengembalian
        DB::unprepared('
            DROP TRIGGER IF EXISTS update_stok_after_return;
            
            CREATE TRIGGER update_stok_after_return
            AFTER INSERT ON pengembalian
            FOR EACH ROW
            BEGIN
                DECLARE alat_id_var INT;
                
                -- Ambil alat_id dari peminjaman
                SELECT alat_id INTO alat_id_var
                FROM peminjaman
                WHERE id = NEW.peminjaman_id;
                
                -- Tambah stok kembali
                UPDATE alat
                SET jumlah_tersedia = jumlah_tersedia + NEW.jumlah_dikembalikan
                WHERE id = alat_id_var;
                
                -- Update kondisi alat jika rusak
                IF NEW.kondisi_alat != "baik" THEN
                    UPDATE alat
                    SET kondisi = NEW.kondisi_alat
                    WHERE id = alat_id_var AND kondisi = "baik";
                END IF;
            END
        ');
    }

    public function down()
    {
        DB::unprepared('DROP TRIGGER IF EXISTS update_stok_after_approve');
        DB::unprepared('DROP TRIGGER IF EXISTS update_stok_after_return');
    }
};
```

### Commit dan Rollback

Transaction untuk memastikan data consistency.

```php
use Illuminate\Support\Facades\DB;

public function createPeminjaman($data)
{
    DB::beginTransaction();
    
    try {
        // 1. Create peminjaman
        $peminjaman = Peminjaman::create([
            'kode_peminjaman' => DB::select('SELECT generate_kode_peminjaman() as kode')[0]->kode,
            'user_id' => auth()->id(),
            'alat_id' => $data['alat_id'],
            'jumlah_pinjam' => $data['jumlah_pinjam'],
            'tanggal_pinjam' => $data['tanggal_pinjam'],
            'tanggal_kembali_rencana' => $data['tanggal_kembali_rencana'],
            'keperluan' => $data['keperluan'],
            'status' => 'menunggu',
        ]);
        
        // 2. Log activity
        ActivityLog::create([
            'user_id' => auth()->id(),
            'activity' => 'CREATE_PEMINJAMAN',
            'description' => "Membuat peminjaman {$peminjaman->kode_peminjaman}",
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
        
        // Commit jika semua berhasil
        DB::commit();
        
        return $peminjaman;
        
    } catch (\Exception $e) {
        // Rollback jika terjadi error
        DB::rollback();
        
        throw $e;
    }
}
```

---

## 3. Struktur Folder Project

### Struktur Lengkap Project Laravel

```
peminjaman-alat/
│
├── app/
│   ├── Console/               # Artisan commands
│   ├── Exceptions/            # Exception handlers
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php
│   │   │   ├── KategoriController.php
│   │   │   ├── AlatController.php
│   │   │   ├── PeminjamanController.php
│   │   │   ├── PengembalianController.php
│   │   │   └── DashboardController.php
│   │   ├── Middleware/
│   │   │   ├── CheckRole.php
│   │   │   └── LogActivity.php
│   │   └── Requests/
│   │       ├── StorePeminjamanRequest.php
│   │       └── UpdateAlatRequest.php
│   ├── Models/
│   │   ├── User.php
│   │   ├── Kategori.php
│   │   ├── Alat.php
│   │   ├── Peminjaman.php
│   │   ├── Pengembalian.php
│   │   └── ActivityLog.php
│   ├── Providers/
│   │   ├── AppServiceProvider.php
│   │   └── AuthServiceProvider.php
│   └── Services/              # Business logic layer
│       ├── PeminjamanService.php
│       ├── PengembalianService.php
│       └── DendaService.php
│
├── bootstrap/
│   └── app.php
│
├── config/                    # Configuration files
│   ├── app.php
│   ├── database.php
│   └── auth.php
│
├── database/
│   ├── factories/
│   │   └── UserFactory.php
│   ├── migrations/
│   │   ├── 0001_01_01_create_users_table.php
│   │   ├── xxxx_xx_create_kategori_table.php
│   │   ├── xxxx_xx_create_alat_table.php
│   │   ├── xxxx_xx_create_peminjaman_table.php
│   │   ├── xxxx_xx_create_pengembalian_table.php
│   │   ├── xxxx_xx_create_activity_logs_table.php
│   │   ├── xxxx_xx_create_stored_procedures.php
│   │   ├── xxxx_xx_create_functions.php
│   │   └── xxxx_xx_create_triggers.php
│   └── seeders/
│       ├── DatabaseSeeder.php
│       ├── UserSeeder.php
│       ├── KategoriSeeder.php
│       └── AlatSeeder.php
│
├── public/
│   ├── css/
│   ├── js/
│   ├── images/
│   ├── storage/              # Symlink ke storage/app/public
│   └── index.php
│
├── resources/
│   ├── css/
│   │   └── app.css
│   ├── js/
│   │   └── app.js
│   └── views/
│       ├── layouts/
│       │   ├── app.blade.php
│       │   ├── guest.blade.php
│       │   └── partials/
│       │       ├── header.blade.php
│       │       ├── sidebar.blade.php
│       │       └── footer.blade.php
│       ├── auth/
│       │   ├── login.blade.php
│       │   └── register.blade.php
│       ├── dashboard.blade.php
│       ├── kategori/
│       │   ├── index.blade.php
│       │   ├── create.blade.php
│       │   ├── edit.blade.php
│       │   └── show.blade.php
│       ├── alat/
│       │   ├── index.blade.php
│       │   ├── create.blade.php
│       │   └── edit.blade.php
│       ├── peminjaman/
│       │   ├── index.blade.php
│       │   ├── create.blade.php
│       │   └── show.blade.php
│       └── pengembalian/
│           ├── index.blade.php
│           └── create.blade.php
│
├── routes/
│   ├── web.php              # Web routes
│   ├── api.php              # API routes
│   └── console.php          # Console routes
│
├── storage/
│   ├── app/
│   │   ├── public/          # Files accessible via web
│   │   │   └── alat/        # Upload foto alat
│   │   └── private/
│   ├── framework/
│   └── logs/
│       └── laravel.log
│
├── tests/
│   ├── Feature/
│   │   ├── AuthTest.php
│   │   ├── PeminjamanTest.php
│   │   └── PengembalianTest.php
│   └── Unit/
│       ├── UserModelTest.php
│       └── DendaCalculationTest.php
│
├── .env                     # Environment variables
├── .env.example
├── .gitignore
├── artisan                  # CLI tool
├── composer.json            # PHP dependencies
├── package.json             # Node dependencies
├── phpunit.xml              # Testing configuration
└── README.md
```

### Penjelasan Folder Penting:

**app/Services/** - Business Logic Layer
- Pisahkan logic kompleks dari Controller
- Lebih mudah di-test
- Reusable

**database/migrations/** - Database Version Control
- Track perubahan database
- Mudah rollback

**resources/views/layouts/** - Template Reusable
- Header, sidebar, footer yang sama
- Konsistensi UI

**tests/** - Automated Testing
- Feature tests: Test dari user perspective
- Unit tests: Test function/method specific

---

## 4. Coding Guidelines & Best Practices

### A. Pastikan Halaman Memuat dengan Cepat

**1. Gunakan Eager Loading (Hindari N+1 Problem)**

```php
// ❌ BAD - N+1 Query Problem
$peminjamans = Peminjaman::all(); // 1 query
foreach ($peminjamans as $peminjaman) {
    echo $peminjaman->user->name;  // +N queries
    echo $peminjaman->alat->nama;  // +N queries
}
// Total: 1 + N + N queries

// ✅ GOOD - Eager Loading
$peminjamans = Peminjaman::with(['user', 'alat'])->all(); // 1 + 2 queries
foreach ($peminjamans as $peminjaman) {
    echo $peminjaman->user->name;  // No extra query
    echo $peminjaman->alat->nama;  // No extra query
}
// Total: 3 queries
```

**2. Use Query Optimization**

```php
// ❌ BAD - Mengambil semua kolom
$users = User::all();

// ✅ GOOD - Hanya ambil kolom yang diperlukan
$users = User::select('id', 'name', 'email')->get();

// ✅ GOOD - Use pagination
$users = User::paginate(20);
```

**3. Caching**

```php
use Illuminate\Support\Facades\Cache;

// Cache data yang jarang berubah
$kategoris = Cache::remember('kategoris', 3600, function () {
    return Kategori::all();
});

// Clear cache saat data berubah
Cache::forget('kategoris');
```

### B. Hindari Looping yang Tidak Perlu

```php
// ❌ BAD - Loop untuk update satu per satu
foreach ($alats as $alat) {
    DB::table('alat')
        ->where('id', $alat->id)
        ->update(['updated_at' => now()]);
}

// ✅ GOOD - Bulk update
DB::table('alat')
    ->whereIn('id', $alats->pluck('id'))
    ->update(['updated_at' => now()]);
```

### C. Gunakan Limit Ketika Menggunakan Data Besar

```php
// ❌ BAD - Load semua data
$logs = ActivityLog::all();

// ✅ GOOD - Limit dengan pagination
$logs = ActivityLog::latest()->paginate(50);

// ✅ GOOD - Chunk untuk proses batch
ActivityLog::chunk(100, function ($logs) {
    foreach ($logs as $log) {
        // Process each log
    }
});
```

### D. Best Practices Lainnya

**1. Validation**
```php
// Gunakan Form Request untuk validasi kompleks
php artisan make:request StorePeminjamanRequest

// app/Http/Requests/StorePeminjamanRequest.php
public function rules()
{
    return [
        'alat_id' => 'required|exists:alat,id',
        'jumlah_pinjam' => 'required|integer|min:1',
        // ... rules lainnya
    ];
}
```

**2. Use Service Layer**
```php
// ❌ BAD - Logic di Controller
public function store(Request $request)
{
    // 50 lines of business logic here
}

// ✅ GOOD - Logic di Service
public function store(StorePeminjamanRequest $request)
{
    $peminjaman = $this->peminjamanService->create($request->validated());
    
    return redirect()->route('peminjaman.index')
        ->with('success', 'Peminjaman berhasil dibuat');
}
```

**3. Use Eloquent Scopes**
```php
// Model Peminjaman
public function scopeMenunggu($query)
{
    return $query->where('status', 'menunggu');
}

// Usage
$pending = Peminjaman::menunggu()->get();
```

**4. Consistent Naming**
```php
// Controllers: PascalCase + Controller
KategoriController, AlatController

// Models: PascalCase, Singular
User, Kategori, Alat

// Methods: camelCase
public function createPeminjaman()

// Variables: camelCase
$totalDenda, $kodePeminjaman

// Database: snake_case
user_id, tanggal_pinjam
```

---

## 5. Testing & Test Cases

### Setup Testing

Laravel sudah include PHPUnit untuk testing.

```bash
# Install dependencies
composer require --dev phpunit/phpunit

# Run tests
php artisan test
```

### Test Case 1: Login dengan Username dan Password Salah

Buat file `tests/Feature/AuthTest.php`:

```php
<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AuthTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function test_login_dengan_password_salah_gagal()
    {
        // Arrange - Setup data
        $user = User::factory()->create([
            'email' => 'test@example.com',
            'password' => bcrypt('password123')
        ]);

        // Act - Lakukan aksi
        $response = $this->post('/login', [
            'email' => 'test@example.com',
            'password' => 'wrongpassword'
        ]);

        // Assert - Verifikasi hasil
        $response->assertStatus(302); // Redirect back
        $this->assertGuest(); // User tidak login
    }

    /** @test */
    public function test_login_dengan_email_salah_gagal()
    {
        $response = $this->post('/login', [
            'email' => 'notexist@example.com',
            'password' => 'password123'
        ]);

        $response->assertStatus(302);
        $this->assertGuest();
    }

    /** @test */
    public function test_login_dengan_kredensial_benar_berhasil()
    {
        $user = User::factory()->create([
            'email' => 'test@example.com',
            'password' => bcrypt('password123')
        ]);

        $response = $this->post('/login', [
            'email' => 'test@example.com',
            'password' => 'password123'
        ]);

        $response->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
    }
}
```

### Test Case 2: Tambah Alat

```php
<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Kategori;
use App\Models\Alat;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AlatTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function admin_dapat_menambah_alat()
    {
        // Login sebagai admin
        $admin = User::factory()->create(['role' => 'admin']);
        $this->actingAs($admin);

        // Buat kategori
        $kategori = Kategori::factory()->create();

        // Submit form tambah alat
        $response = $this->post('/alat', [
            'kode_alat' => 'TEST001',
            'nama_alat' => 'Alat Test',
            'kategori_id' => $kategori->id,
            'kondisi' => 'baik',
            'jumlah_total' => 10,
            'jumlah_tersedia' => 10,
        ]);

        // Assert
        $response->assertRedirect('/alat');
        $this->assertDatabaseHas('alat', [
            'kode_alat' => 'TEST001',
            'nama_alat' => 'Alat Test',
        ]);
    }

    /** @test */
    public function peminjam_tidak_dapat_menambah_alat()
    {
        $peminjam = User::factory()->create(['role' => 'peminjam']);
        $this->actingAs($peminjam);

        $response = $this->post('/alat', [
            'kode_alat' => 'TEST001',
            'nama_alat' => 'Alat Test',
        ]);

        $response->assertStatus(403); // Forbidden
    }
}
```

### Test Case 3: Pinjam Alat

```php
<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Alat;
use App\Models\Peminjaman;
use Illuminate\Foundation\Testing\RefreshDatabase;

class PeminjamanTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function peminjam_dapat_mengajukan_peminjaman()
    {
        $peminjam = User::factory()->create(['role' => 'peminjam']);
        $alat = Alat::factory()->create([
            'jumlah_tersedia' => 5
        ]);

        $this->actingAs($peminjam);

        $response = $this->post('/peminjaman', [
            'alat_id' => $alat->id,
            'jumlah_pinjam' => 2,
            'tanggal_pinjam' => now()->format('Y-m-d'),
            'tanggal_kembali_rencana' => now()->addDays(7)->format('Y-m-d'),
            'keperluan' => 'Untuk kegiatan',
        ]);

        $response->assertRedirect('/peminjaman');
        $this->assertDatabaseHas('peminjaman', [
            'user_id' => $peminjam->id,
            'alat_id' => $alat->id,
            'status' => 'menunggu',
        ]);
    }

    /** @test */
    public function peminjaman_gagal_jika_stok_tidak_cukup()
    {
        $peminjam = User::factory()->create(['role' => 'peminjam']);
        $alat = Alat::factory()->create([
            'jumlah_tersedia' => 2
        ]);

        $this->actingAs($peminjam);

        $response = $this->post('/peminjaman', [
            'alat_id' => $alat->id,
            'jumlah_pinjam' => 5, // Lebih dari stok
            'tanggal_pinjam' => now()->format('Y-m-d'),
            'tanggal_kembali_rencana' => now()->addDays(7)->format('Y-m-d'),
            'keperluan' => 'Untuk kegiatan',
        ]);

        $response->assertSessionHasErrors();
    }
}
```

### Test Case 4: Kembalikan Alat (dengan Denda)

```php
<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Alat;
use App\Models\Peminjaman;
use Illuminate\Foundation\Testing\RefreshDatabase;

class PengembalianTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function pengembalian_terlambat_dikenakan_denda()
    {
        $petugas = User::factory()->create(['role' => 'petugas']);
        $alat = Alat::factory()->create();
        
        $peminjaman = Peminjaman::factory()->create([
            'alat_id' => $alat->id,
            'jumlah_pinjam' => 1,
            'tanggal_kembali_rencana' => now()->subDays(5)->format('Y-m-d'), // 5 hari lalu
            'status' => 'dipinjam',
        ]);

        $this->actingAs($petugas);

        $response = $this->post('/pengembalian', [
            'peminjaman_id' => $peminjaman->id,
            'tanggal_pengembalian' => now()->format('Y-m-d'),
            'kondisi_alat' => 'baik',
            'jumlah_dikembalikan' => 1,
        ]);

        $this->assertDatabaseHas('pengembalian', [
            'peminjaman_id' => $peminjaman->id,
            'denda' => 50000, // 5 hari × Rp 10.000
        ]);
    }

    /** @test */
    public function pengembalian_rusak_dikenakan_denda_tambahan()
    {
        $petugas = User::factory()->create(['role' => 'petugas']);
        $alat = Alat::factory()->create();
        
        $peminjaman = Peminjaman::factory()->create([
            'alat_id' => $alat->id,
            'jumlah_pinjam' => 1,
            'tanggal_kembali_rencana' => now()->format('Y-m-d'), // Tidak terlambat
            'status' => 'dipinjam',
        ]);

        $this->actingAs($petugas);

        $response = $this->post('/pengembalian', [
            'peminjaman_id' => $peminjaman->id,
            'tanggal_pengembalian' => now()->format('Y-m-d'),
            'kondisi_alat' => 'rusak_ringan',
            'jumlah_dikembalikan' => 1,
        ]);

        $this->assertDatabaseHas('pengembalian', [
            'peminjaman_id' => $peminjaman->id,
            'denda' => 50000, // Rusak ringan
        ]);
    }
}
```

### Test Case 5: Cek Privilege User

```php
<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class PrivilegeTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function hanya_admin_yang_bisa_kelola_user()
    {
        // Admin bisa akses
        $admin = User::factory()->create(['role' => 'admin']);
        $this->actingAs($admin);
        $response = $this->get('/user');
        $response->assertStatus(200);

        // Petugas tidak bisa
        $petugas = User::factory()->create(['role' => 'petugas']);
        $this->actingAs($petugas);
        $response = $this->get('/user');
        $response->assertStatus(403);

        // Peminjam tidak bisa
        $peminjam = User::factory()->create(['role' => 'peminjam']);
        $this->actingAs($peminjam);
        $response = $this->get('/user');
        $response->assertStatus(403);
    }

    /** @test */
    public function admin_dan_petugas_bisa_approve_peminjaman()
    {
        $peminjaman = Peminjaman::factory()->create(['status' => 'menunggu']);

        // Admin bisa approve
        $admin = User::factory()->create(['role' => 'admin']);
        $this->actingAs($admin);
        $response = $this->post("/peminjaman/{$peminjaman->id}/approve");
        $response->assertStatus(302);

        // Reset status
        $peminjaman->update(['status' => 'menunggu']);

        // Petugas bisa approve
        $petugas = User::factory()->create(['role' => 'petugas']);
        $this->actingAs($petugas);
        $response = $this->post("/peminjaman/{$peminjaman->id}/approve");
        $response->assertStatus(302);

        // Peminjam tidak bisa approve
        $peminjam = User::factory()->create(['role' => 'peminjam']);
        $this->actingAs($peminjam);
        $response = $this->post("/peminjaman/{$peminjaman->id}/approve");
        $response->assertStatus(403);
    }
}
```

### Menjalankan Test

```bash
# Run all tests
php artisan test

# Run specific test file
php artisan test tests/Feature/AuthTest.php

# Run with coverage
php artisan test --coverage

# Run specific test method
php artisan test --filter=test_login_dengan_password_salah_gagal
```

---

## 6. Laporan Singkat

### Format Laporan Testing

Buat file `LAPORAN_TESTING.md`:

```markdown
# Laporan Testing Aplikasi Peminjaman Alat

## Informasi Project
- **Nama Aplikasi**: Sistem Peminjaman Alat
- **Versi**: 1.0.0
- **Framework**: Laravel 12
- **Tanggal Testing**: 13 Februari 2026
- **Tester**: [Nama Anda]

## Ringkasan Hasil Testing

| Kategori | Total Test | Passed | Failed | Success Rate |
|----------|-----------|--------|--------|--------------|
| Authentication | 3 | 3 | 0 | 100% |
| CRUD Alat | 2 | 2 | 0 | 100% |
| Peminjaman | 2 | 2 | 0 | 100% |
| Pengembalian | 2 | 2 | 0 | 100% |
| Privilege | 2 | 2 | 0 | 100% |
| **TOTAL** | **11** | **11** | **0** | **100%** |

## Detail Test Cases

### 1. Authentication Tests
✅ **Login dengan password salah** - PASSED
- Expected: Login gagal, redirect ke login page
- Actual: Sesuai expected
- Status: PASSED

✅ **Login dengan email salah** - PASSED
- Expected: Login gagal, muncul error message
- Actual: Sesuai expected
- Status: PASSED

✅ **Login dengan kredensial benar** - PASSED
- Expected: Login berhasil, redirect ke dashboard
- Actual: Sesuai expected
- Status: PASSED

### 2. CRUD Alat Tests
✅ **Admin dapat menambah alat** - PASSED
- Expected: Data alat tersimpan di database
- Actual: Sesuai expected
- Status: PASSED

✅ **Peminjam tidak dapat menambah alat** - PASSED
- Expected: HTTP 403 Forbidden
- Actual: Sesuai expected
- Status: PASSED

### 3. Peminjaman Tests
✅ **Peminjam dapat mengajukan peminjaman** - PASSED
- Expected: Peminjaman dengan status "menunggu" tersimpan
- Actual: Sesuai expected
- Status: PASSED

✅ **Peminjaman gagal jika stok tidak cukup** - PASSED
- Expected: Validation error muncul
- Actual: Sesuai expected
- Status: PASSED

### 4. Pengembalian Tests
✅ **Pengembalian terlambat dikenakan denda** - PASSED
- Expected: Denda Rp 10.000/hari keterlambatan
- Actual: Denda Rp 50.000 untuk 5 hari terlambat
- Status: PASSED

✅ **Pengembalian rusak dikenakan denda tambahan** - PASSED
- Expected: Denda kerusakan ditambahkan
- Actual: Denda Rp 50.000 untuk rusak ringan
- Status: PASSED

### 5. Privilege Tests
✅ **Hanya admin yang bisa kelola user** - PASSED
- Expected: Admin dapat akses, role lain tidak bisa
- Actual: Sesuai expected
- Status: PASSED

✅ **Admin dan petugas bisa approve peminjaman** - PASSED
- Expected: Admin dan petugas bisa, peminjam tidak
- Actual: Sesuai expected
- Status: PASSED

## Bug yang Ditemukan

Tidak ada bug yang ditemukan selama testing.

## Rencana Pengembangan Berikutnya

1. **Fitur Notifikasi**
   - Email notification saat peminjaman disetujui
   - Reminder sebelum tanggal kembali

2. **Dashboard dengan Statistik**
   - Grafik peminjaman per bulan
   - Alat paling sering dipinjam

3. **Export Laporan**
   - Export to PDF
   - Export to Excel

4. **API Development**
   - REST API untuk mobile app
   - API documentation dengan Swagger

5. **Peningkatan Security**
   - Two-factor authentication
   - Password reset via email
   - Session management

## Kesimpulan

Aplikasi Peminjaman Alat telah melalui testing dengan hasil **100% test passed**. Semua fitur utama berjalan dengan baik:
- ✅ Authentication berfungsi dengan baik
- ✅ CRUD operations berjalan lancar
- ✅ Role-based access control bekerja sesuai spesifikasi
- ✅ Business logic (perhitungan denda) akurat
- ✅ Data validation bekerja dengan baik

Aplikasi siap untuk di-deploy ke production setelah dilakukan final review dan persiapan deployment.

---
**Dibuat oleh**: [Nama Anda]  
**Tanggal**: 13 Februari 2026
```

---

## 📊 Ringkasan

Di bagian ini Anda sudah belajar:

✅ Membuat ERD untuk visualisasi database  
✅ Stored Procedure untuk logic di database  
✅ Function untuk operasi yang return value  
✅ Trigger untuk aksi otomatis  
✅ Transaction (Commit & Rollback)  
✅ Struktur folder project yang baik  
✅ Coding guidelines & best practices  
✅ Query optimization  
✅ Writing test cases  
✅ Running automated tests  
✅ Membuat laporan testing  

**Selamat! Anda sudah menguasai Laravel tingkat lanjut! 🎉**

---

*Lanjutkan ke deployment di Bagian 7 atau mulai praktek membuat fitur lengkap!*
