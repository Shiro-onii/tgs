

-- =====================================================
-- 3. STORED PROCEDURES
-- =====================================================

-- Procedure: Approve Peminjaman
DELIMITER //
CREATE PROCEDURE sp_approve_peminjaman(
    IN p_peminjaman_id BIGINT,
    IN p_petugas_id BIGINT,
    IN p_catatan TEXT
)
BEGIN
    DECLARE v_alat_id BIGINT;
    DECLARE v_jumlah INT;
    DECLARE v_stok_tersedia INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Gagal approve peminjaman';
    END;
    
    START TRANSACTION;
    
    -- Ambil data peminjaman
    SELECT alat_id, jumlah_pinjam INTO v_alat_id, v_jumlah
    FROM peminjaman
    WHERE id = p_peminjaman_id AND status = 'menunggu';
    
    -- Cek stok
    SELECT jumlah_tersedia INTO v_stok_tersedia
    FROM alat
    WHERE id = v_alat_id;
    
    IF v_stok_tersedia < v_jumlah THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Stok tidak mencukupi';
    END IF;
    
    -- Update peminjaman
    UPDATE peminjaman
    SET status = 'disetujui',
        disetujui_oleh = p_petugas_id,
        catatan_petugas = p_catatan
    WHERE id = p_peminjaman_id;
    
    -- Kurangi stok
    UPDATE alat
    SET jumlah_tersedia = jumlah_tersedia - v_jumlah
    WHERE id = v_alat_id;
    
    -- Log aktivitas
    INSERT INTO log_activity (user_id, activity, description)
    VALUES (p_petugas_id, 'APPROVE_PEMINJAMAN', CONCAT('Menyetujui peminjaman ID: ', p_peminjaman_id));
    
    COMMIT;
END //
DELIMITER ;

-- Procedure: Reject Peminjaman
DELIMITER //
CREATE PROCEDURE sp_reject_peminjaman(
    IN p_peminjaman_id BIGINT,
    IN p_petugas_id BIGINT,
    IN p_catatan TEXT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Gagal reject peminjaman';
    END;
    
    START TRANSACTION;
    
    UPDATE peminjaman
    SET status = 'ditolak',
        disetujui_oleh = p_petugas_id,
        catatan_petugas = p_catatan
    WHERE id = p_peminjaman_id AND status = 'menunggu';
    
    INSERT INTO log_activity (user_id, activity, description)
    VALUES (p_petugas_id, 'REJECT_PEMINJAMAN', CONCAT('Menolak peminjaman ID: ', p_peminjaman_id));
    
    COMMIT;
END //
DELIMITER ;

-- Procedure: Proses Pengembalian
DELIMITER //
CREATE PROCEDURE sp_proses_pengembalian(
    IN p_peminjaman_id BIGINT,
    IN p_tanggal_pengembalian DATE,
    IN p_kondisi ENUM('baik', 'rusak_ringan', 'rusak_berat'),
    IN p_jumlah INT,
    IN p_denda DECIMAL(15,2),
    IN p_keterangan TEXT,
    IN p_petugas_id BIGINT
)
BEGIN
    DECLARE v_alat_id BIGINT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Gagal proses pengembalian';
    END;
    
    START TRANSACTION;
    
    -- Ambil alat_id dari peminjaman
    SELECT alat_id INTO v_alat_id
    FROM peminjaman
    WHERE id = p_peminjaman_id;
    
    -- Insert pengembalian
    INSERT INTO pengembalian (
        peminjaman_id, tanggal_pengembalian, kondisi_alat,
        jumlah_dikembalikan, denda, keterangan, diterima_oleh
    ) VALUES (
        p_peminjaman_id, p_tanggal_pengembalian, p_kondisi,
        p_jumlah, p_denda, p_keterangan, p_petugas_id
    );
    
    -- Update status peminjaman
    UPDATE peminjaman
    SET status = 'dikembalikan',
        tanggal_kembali_aktual = p_tanggal_pengembalian
    WHERE id = p_peminjaman_id;
    
    -- Kembalikan stok
    UPDATE alat
    SET jumlah_tersedia = jumlah_tersedia + p_jumlah
    WHERE id = v_alat_id;
    
    -- Log
    INSERT INTO log_activity (user_id, activity, description)
    VALUES (p_petugas_id, 'PROSES_PENGEMBALIAN', CONCAT('Memproses pengembalian ID: ', p_peminjaman_id));
    
    COMMIT;
END //
DELIMITER ;

-- =====================================================
-- 4. FUNCTIONS
-- =====================================================

-- Function: Hitung Denda Keterlambatan
DELIMITER //
CREATE FUNCTION fn_hitung_denda_terlambat(
    p_harga DECIMAL(15,2),
    p_tanggal_kembali DATE,
    p_tanggal_rencana DATE,
    p_jumlah INT
) RETURNS DECIMAL(15,2)
DETERMINISTIC
BEGIN
    DECLARE v_hari_terlambat INT;
    DECLARE v_denda DECIMAL(15,2);
    
    SET v_hari_terlambat = DATEDIFF(p_tanggal_kembali, p_tanggal_rencana);
    
    IF v_hari_terlambat > 0 THEN
        -- Rumus: 1% × Harga × Hari × Jumlah
        SET v_denda = (p_harga * 0.01 * v_hari_terlambat * p_jumlah);
    ELSE
        SET v_denda = 0;
    END IF;
    
    RETURN v_denda;
END //
DELIMITER ;

-- Function: Hitung Denda Kerusakan
DELIMITER //
CREATE FUNCTION fn_hitung_denda_rusak(
    p_kondisi ENUM('baik', 'rusak_ringan', 'rusak_berat'),
    p_jumlah INT
) RETURNS DECIMAL(15,2)
DETERMINISTIC
BEGIN
    DECLARE v_denda DECIMAL(15,2);
    
    CASE p_kondisi
        WHEN 'rusak_ringan' THEN
            SET v_denda = 50000 * p_jumlah;
        WHEN 'rusak_berat' THEN
            SET v_denda = 200000 * p_jumlah;
        ELSE
            SET v_denda = 0;
    END CASE;
    
    RETURN v_denda;
END //
DELIMITER ;

-- Function: Generate Kode Peminjaman
DELIMITER //
CREATE FUNCTION fn_generate_kode_peminjaman() 
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE v_kode VARCHAR(50);
    DECLARE v_random INT;
    
    SET v_random = FLOOR(1000 + RAND() * 9000);
    SET v_kode = CONCAT('PJM', DATE_FORMAT(NOW(), '%Y%m%d'), v_random);
    
    RETURN v_kode;
END //
DELIMITER ;

-- Function: Cek Ketersediaan Stok
DELIMITER //
CREATE FUNCTION fn_cek_stok(
    p_alat_id BIGINT,
    p_jumlah_diminta INT
) RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    DECLARE v_stok INT;
    
    SELECT jumlah_tersedia INTO v_stok
    FROM alat
    WHERE id = p_alat_id;
    
    IF v_stok >= p_jumlah_diminta THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END //
DELIMITER ;

-- =====================================================
-- 5. TRIGGERS
-- =====================================================

-- Trigger: Before Insert Peminjaman - Generate Kode
DELIMITER //
CREATE TRIGGER trg_before_insert_peminjaman
BEFORE INSERT ON peminjaman
FOR EACH ROW
BEGIN
    IF NEW.kode_peminjaman IS NULL OR NEW.kode_peminjaman = '' THEN
        SET NEW.kode_peminjaman = fn_generate_kode_peminjaman();
    END IF;
END //
DELIMITER ;

-- Trigger: After Insert Peminjaman - Log Activity
DELIMITER //
CREATE TRIGGER trg_after_insert_peminjaman
AFTER INSERT ON peminjaman
FOR EACH ROW
BEGIN
    INSERT INTO log_activity (user_id, activity, description)
    VALUES (NEW.user_id, 'CREATE_PEMINJAMAN', CONCAT('Membuat peminjaman: ', NEW.kode_peminjaman));
END //
DELIMITER ;

-- Trigger: Before Delete Peminjaman - Cek Status
DELIMITER //
CREATE TRIGGER trg_before_delete_peminjaman
BEFORE DELETE ON peminjaman
FOR EACH ROW
BEGIN
    IF OLD.status IN ('disetujui', 'dipinjam') THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Error: Tidak bisa menghapus peminjaman yang sudah disetujui atau dipinjam';
    END IF;
END //
DELIMITER ;

-- Trigger: After Update Peminjaman Status - Restore Stok jika Ditolak
DELIMITER //
CREATE TRIGGER trg_after_update_peminjaman_status
AFTER UPDATE ON peminjaman
FOR EACH ROW
BEGIN
    -- Jika status berubah dari disetujui ke ditolak, kembalikan stok
    IF OLD.status = 'disetujui' AND NEW.status = 'ditolak' THEN
        UPDATE alat
        SET jumlah_tersedia = jumlah_tersedia + OLD.jumlah_pinjam
        WHERE id = OLD.alat_id;
    END IF;
END //
DELIMITER ;

-- Trigger: Before Insert Pengembalian - Validasi
DELIMITER //
CREATE TRIGGER trg_before_insert_pengembalian
BEFORE INSERT ON pengembalian
FOR EACH ROW
BEGIN
    DECLARE v_jumlah_pinjam INT;
    
    -- Ambil jumlah pinjam
    SELECT jumlah_pinjam INTO v_jumlah_pinjam
    FROM peminjaman
    WHERE id = NEW.peminjaman_id;
    
    -- Validasi jumlah
    IF NEW.jumlah_dikembalikan > v_jumlah_pinjam THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Error: Jumlah dikembalikan melebihi jumlah pinjam';
    END IF;
END //
DELIMITER ;

-- Trigger: After Insert Pengembalian - Log Activity
DELIMITER //
CREATE TRIGGER trg_after_insert_pengembalian
AFTER INSERT ON pengembalian
FOR EACH ROW
BEGIN
    INSERT INTO log_activity (user_id, activity, description)
    VALUES (NEW.diterima_oleh, 'CREATE_PENGEMBALIAN', CONCAT('Memproses pengembalian untuk peminjaman ID: ', NEW.peminjaman_id));
END //
DELIMITER ;

-- =====================================================
-- 6. VIEWS (Relasi)
-- =====================================================

-- View: Peminjaman Lengkap
CREATE OR REPLACE VIEW v_peminjaman_lengkap AS
SELECT 
    p.id,
    p.kode_peminjaman,
    u.name AS nama_peminjam,
    u.email AS email_peminjam,
    a.nama_alat,
    a.kode_alat,
    k.nama_kategori,
    p.jumlah_pinjam,
    p.tanggal_pinjam,
    p.tanggal_kembali_rencana,
    p.tanggal_kembali_aktual,
    p.status,
    petugas.name AS disetujui_oleh_nama,
    p.catatan_petugas,
    p.created_at
FROM peminjaman p
LEFT JOIN users u ON p.user_id = u.id
LEFT JOIN alat a ON p.alat_id = a.id
LEFT JOIN kategori k ON a.kategori_id = k.id
LEFT JOIN users petugas ON p.disetujui_oleh = petugas.id;

-- View: Pengembalian Lengkap dengan Denda
CREATE OR REPLACE VIEW v_pengembalian_lengkap AS
SELECT 
    pen.id,
    p.kode_peminjaman,
    u.name AS nama_peminjam,
    a.nama_alat,
    a.harga AS harga_alat,
    pen.tanggal_pengembalian,
    pen.kondisi_alat,
    pen.jumlah_dikembalikan,
    pen.denda,
    petugas.name AS diterima_oleh_nama,
    pen.keterangan,
    pen.created_at
FROM pengembalian pen
LEFT JOIN peminjaman p ON pen.peminjaman_id = p.id
LEFT JOIN users u ON p.user_id = u.id
LEFT JOIN alat a ON p.alat_id = a.id
LEFT JOIN users petugas ON pen.diterima_oleh = petugas.id;

-- View: Statistik Alat
CREATE OR REPLACE VIEW v_statistik_alat AS
SELECT 
    a.id,
    a.kode_alat,
    a.nama_alat,
    k.nama_kategori,
    a.jumlah_total,
    a.jumlah_tersedia,
    (a.jumlah_total - a.jumlah_tersedia) AS jumlah_dipinjam,
    COUNT(DISTINCT p.id) AS total_peminjaman,
    COALESCE(SUM(pen.denda), 0) AS total_denda_dihasilkan
FROM alat a
LEFT JOIN kategori k ON a.kategori_id = k.id
LEFT JOIN peminjaman p ON a.id = p.alat_id
LEFT JOIN pengembalian pen ON p.id = pen.peminjaman_id
GROUP BY a.id, a.kode_alat, a.nama_alat, k.nama_kategori, a.jumlah_total, a.jumlah_tersedia;

-- =====================================================
-- 7. DATA SEEDER
-- =====================================================

-- Insert Users
INSERT INTO users (name, email, password, role) VALUES
('Admin Utama', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Petugas 1', 'petugas@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'petugas'),
('Peminjam 1', 'peminjam@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'peminjam');

-- Insert Kategori
INSERT INTO kategori (nama_kategori, deskripsi) VALUES
('Konsol', 'Perangkat konsol game PlayStation'),
('Controller', 'Stik dan controller game'),
('VR', 'Perangkat Virtual Reality'),
('Aksesoris', 'Aksesoris tambahan');

-- Insert Alat
INSERT INTO alat (kategori_id, kode_alat, nama_alat, merk, harga, jumlah_total, jumlah_tersedia, kondisi) VALUES
(1, 'PS5-001', 'PlayStation 5 Standard', 'Sony', 7999000, 5, 5, 'baik'),
(1, 'PS4-001', 'PlayStation 4 Pro', 'Sony', 4999000, 3, 3, 'baik'),
(2, 'DS5-001', 'DualSense Controller', 'Sony', 899000, 10, 10, 'baik'),
(3, 'PSVR2-001', 'PlayStation VR2', 'Sony', 8999000, 2, 2, 'baik');

-- =====================================================
-- 8. CONTOH PENGGUNAAN
-- =====================================================

-- A. Menggunakan Stored Procedure dengan COMMIT/ROLLBACK

-- Contoh 1: Approve Peminjaman
START TRANSACTION;
CALL sp_approve_peminjaman(1, 2, 'Peminjaman disetujui');
COMMIT;

-- Contoh 2: Reject Peminjaman
START TRANSACTION;
CALL sp_reject_peminjaman(2, 2, 'Stok tidak tersedia');
COMMIT;

-- Contoh 3: Proses Pengembalian dengan Rollback jika error
START TRANSACTION;
CALL sp_proses_pengembalian(1, '2026-02-25', 'baik', 1, 0, 'Pengembalian tepat waktu', 2);
-- Jika ada error, otomatis ROLLBACK dari procedure
COMMIT;

-- B. Menggunakan Functions

-- Hitung denda keterlambatan
SELECT fn_hitung_denda_terlambat(7999000, '2026-03-01', '2026-02-25', 1) AS denda_terlambat;
-- Result: 479940 (1% × 7999000 × 4 hari × 1 unit)

-- Hitung denda kerusakan
SELECT fn_hitung_denda_rusak('rusak_ringan', 2) AS denda_kerusakan;
-- Result: 100000 (50000 × 2)

-- Generate kode peminjaman
SELECT fn_generate_kode_peminjaman() AS kode_baru;
-- Result: PJM202602234521 (contoh)

-- Cek stok
SELECT fn_cek_stok(1, 3) AS stok_cukup;
-- Result: 1 (TRUE) jika stok cukup, 0 (FALSE) jika tidak

-- C. Query menggunakan Views

-- Lihat semua peminjaman lengkap
SELECT * FROM v_peminjaman_lengkap WHERE status = 'menunggu';

-- Lihat pengembalian dengan denda
SELECT * FROM v_pengembalian_lengkap WHERE denda > 0 ORDER BY denda DESC;

-- Statistik alat paling sering dipinjam
SELECT * FROM v_statistik_alat ORDER BY total_peminjaman DESC LIMIT 5;

-- =====================================================
-- 9. CONTOH TRANSAKSI LENGKAP
-- =====================================================

-- Skenario: Peminjam mengajukan peminjaman, petugas approve, lalu peminjam mengembalikan

-- Step 1: Insert Peminjaman (Auto generate kode via trigger)
START TRANSACTION;
INSERT INTO peminjaman (user_id, alat_id, jumlah_pinjam, tanggal_pinjam, tanggal_kembali_rencana, keperluan)
VALUES (3, 1, 1, '2026-02-20', '2026-02-25', 'Untuk acara gaming');
-- Trigger akan auto generate kode_peminjaman dan log activity
COMMIT;

-- Step 2: Petugas Approve (via stored procedure)
START TRANSACTION;
CALL sp_approve_peminjaman(LAST_INSERT_ID(), 2, 'Disetujui, silakan ambil alat');
-- Procedure akan: update status, kurangi stok, log activity
COMMIT;

-- Step 3: Pengembalian (via stored procedure)
START TRANSACTION;
CALL sp_proses_pengembalian(
    LAST_INSERT_ID(), 
    '2026-02-27', 
    'baik', 
    1, 
    fn_hitung_denda_terlambat(7999000, '2026-02-27', '2026-02-25', 1),
    'Pengembalian terlambat 2 hari',
    2
);
-- Procedure akan: insert pengembalian, update status, kembalikan stok, log activity
COMMIT;

-- Step 4: Jika terjadi error, ROLLBACK
START TRANSACTION;
INSERT INTO peminjaman (user_id, alat_id, jumlah_pinjam, tanggal_pinjam, tanggal_kembali_rencana, keperluan)
VALUES (3, 999, 1, '2026-02-20', '2026-02-25', 'Test error');
-- Error: alat_id 999 tidak ada
ROLLBACK;
-- Data tidak tersimpan

-- =====================================================
-- 10. INDEX OPTIMIZATION QUERIES
-- =====================================================

-- Query optimized dengan index
EXPLAIN SELECT * FROM peminjaman WHERE status = 'menunggu';
-- Menggunakan idx_status

EXPLAIN SELECT * FROM alat WHERE jumlah_tersedia <= 2;
-- Menggunakan idx_stok

EXPLAIN SELECT * FROM log_activity WHERE user_id = 1 ORDER BY created_at DESC;
-- Menggunakan idx_user dan idx_created

-- =====================================================
-- END OF DATABASE SCRIPT
-- =====================================================