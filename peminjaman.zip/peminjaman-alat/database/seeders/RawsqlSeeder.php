<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class RawSqlSeeder extends Seeder
{
    public function run(): void
    {
        // // Baca file SQL
        // $path = database_path('scripts/full_database.sql');
        // $sql = File::get($path);

        // // Jalankan langsung ke database
        // DB::unprepared($sql);
    }
}