<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pengembalian', function (Blueprint $table) {
            $table->id();
            $table->foreignId('peminjaman_id')->constrained('peminjaman')->onDelete('cascade');
            $table->date('tanggal_pengembalian');
            $table->enum('kondisi_alat',[
                'baik',
                'rusak_ringan',
                'rusak_berat'
            ])->default('baik');
            $table->string('jumlah_dikembalikan');
            $table->decimal('denda',10,2)->default(0);
            $table->text('keterangan')->nullable();
            $table->foreignId('diterima_oleh')->constrained('users')->onDelete('cascade'); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pengembalian');
    }
};
