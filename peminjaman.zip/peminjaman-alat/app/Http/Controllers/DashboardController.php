<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Alat;
use App\Models\Peminjaman;
use App\Models\Pengembalian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        
        // Dashboard berdasarkan role
        if ($user->role === 'admin') {
            return $this->adminDashboard();
        } elseif ($user->role === 'petugas') {
            return $this->petugasDashboard();
        } else {
            return $this->peminjamDashboard();
        }
    }
    
    // Dashboard Admin
    private function adminDashboard()
    {
        $stats = [
            'total_users' => User::count(),
            'total_alat' => Alat::count(),
            'dipinjam' => Peminjaman::whereIn('status', ['disetujui', 'dipinjam'])->count(),
            'total_denda' => Pengembalian::sum('denda'),
        ];
        
        // Peminjaman menunggu approval
        $pending_peminjaman = Peminjaman::with(['user', 'alat'])
            ->where('status', 'menunggu')
            ->latest()
            ->limit(5)
            ->get();
        
        // Alat dengan stok menipis (tersedia <= 2)
        $low_stock = Alat::where('jumlah_tersedia', '<=', 2)
            ->where('jumlah_tersedia', '>', 0)
            ->orderBy('jumlah_tersedia', 'asc')
            ->limit(5)
            ->get();
        
        return view('dashboard', compact('stats', 'pending_peminjaman', 'low_stock'));
    }
    
    // Dashboard Petugas
    private function petugasDashboard()
    {
        $stats = [
            'menunggu' => Peminjaman::where('status', 'menunggu')->count(),
            'dipinjam' => Peminjaman::whereIn('status', ['disetujui', 'dipinjam'])->count(),
            'pengembalian' => Pengembalian::count(),
        ];
        
        // Peminjaman menunggu approval
        $pending_peminjaman = Peminjaman::with(['user', 'alat'])
            ->where('status', 'menunggu')
            ->latest()
            ->limit(10)
            ->get();
        
        return view('dashboard', compact('stats', 'pending_peminjaman'));
    }
    
    // Dashboard Peminjam
    private function peminjamDashboard()
    {
        $userId = auth()->id();
        
        $stats = [
            'total_peminjaman' => Peminjaman::where('user_id', $userId)->count(),
            'sedang_dipinjam' => Peminjaman::where('user_id', $userId)
                ->whereIn('status', ['disetujui', 'dipinjam'])
                ->count(),
            'total_denda' => Pengembalian::whereHas('peminjaman', function($q) use ($userId) {
                $q->where('user_id', $userId);
            })->sum('denda'),
        ];
        
        // Peminjaman aktif user
        $my_peminjaman = Peminjaman::with(['alat'])
            ->where('user_id', $userId)
            ->whereIn('status', ['menunggu', 'disetujui', 'dipinjam'])
            ->latest()
            ->limit(5)
            ->get();
        
        return view('dashboard', compact('stats', 'my_peminjaman'));
    }
}