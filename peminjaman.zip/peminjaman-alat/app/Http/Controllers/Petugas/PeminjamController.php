<?php

namespace App\Http\Controllers\Petugas;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class PeminjamController extends Controller
{
    // Lihat daftar peminjam
    public function index()
{
    $peminjams = User::where('role', 'peminjam')
        ->withCount('peminjamans') // tambahkan ini
        ->latest()
        ->paginate(15);

    return view('petugas.peminjam.index', compact('peminjams'));
}

    // Form registrasi peminjam baru
    public function create()
    {
        return view('petugas.peminjam.create');
    }

    // Simpan peminjam baru
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
        ], [
            'name.required' => 'Nama wajib diisi',
            'email.required' => 'Email wajib diisi',
            'email.unique' => 'Email sudah terdaftar',
            'password.required' => 'Password wajib diisi',
            'password.min' => 'Password minimal 8 karakter',
            'password.confirmed' => 'Konfirmasi password tidak cocok',
        ]);

        $validated['password'] = Hash::make($validated['password']);
        $validated['role'] = 'peminjam'; // Auto set role peminjam

        $user = User::create($validated);

        ActivityLog::log('REGISTER_PEMINJAM', "Petugas mendaftarkan peminjam baru: {$user->name}");

        return redirect()->route('petugas.peminjam.index')
            ->with('success', "Peminjam {$user->name} berhasil didaftarkan");
    }

    // Detail peminjam
    public function show(User $peminjam)
    {
        // Pastikan yang dilihat adalah peminjam
        if ($peminjam->role !== 'peminjam') {
            abort(404);
        }

        $peminjam->load(['peminjamans.alat']);

        return view('petugas.peminjam.show', compact('peminjam'));
    }
}