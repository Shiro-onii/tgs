

<?php $__env->startSection('title', 'Daftar Peminjam'); ?>
<?php $__env->startSection('page-title', 'Kelola Data Peminjam'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('petugas.peminjam.create')); ?>" class="btn btn-primary">
            <i class="fas fa-user-plus me-2"></i> Registrasi Peminjam Baru
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>No. Telepon</th>
                        <th>Terdaftar</th>
                        <th>Total Peminjaman</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $peminjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($peminjam->name); ?></td>
                            <td><?php echo e($peminjam->email); ?></td>
                            <td><?php echo e($peminjam->phone ?? '-'); ?></td>
                            <td><?php echo e($peminjam->created_at->format('d/m/Y')); ?></td>
                            <td>
                                <span class="badge bg-info">
                                    <?php echo e($peminjam->peminjamans_count); ?> peminjaman
                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('petugas.peminjam.show', $peminjam->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                Belum ada peminjam terdaftar
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($peminjams->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/peminjam/index.blade.php ENDPATH**/ ?>