

<?php $__env->startSection('title', 'Detail Peminjam'); ?>
<?php $__env->startSection('page-title', 'Detail Peminjam'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Peminjam</h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="avatar-lg mx-auto mb-3" style="width: 100px; height: 100px; background: #667eea; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <span style="font-size: 3rem; color: white; font-weight: bold;">
                            <?php echo e(strtoupper(substr($peminjam->name, 0, 1))); ?>

                        </span>
                    </div>
                    <h5 class="mb-1"><?php echo e($peminjam->name); ?></h5>
                    <span class="badge bg-primary">Peminjam</span>
                </div>

                <table class="table table-borderless">
                    <tr>
                        <th width="40%">Email</th>
                        <td><?php echo e($peminjam->email); ?></td>
                    </tr>
                    <tr>
                        <th>No. Telepon</th>
                        <td><?php echo e($peminjam->phone ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td><?php echo e($peminjam->address ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Terdaftar</th>
                        <td><?php echo e($peminjam->created_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Riwayat Peminjaman</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjam->peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                    <td>
                                        <?php
                                            $badgeClass = match($p->status) {
                                                'menunggu' => 'bg-warning text-dark',
                                                'disetujui' => 'bg-success',
                                                'ditolak' => 'bg-danger',
                                                'dipinjam' => 'bg-info',
                                                'dikembalikan' => 'bg-secondary',
                                                default => 'bg-secondary'
                                            };
                                        ?>
                                        <span class="badge <?php echo e($badgeClass); ?>">
                                            <?php echo e(ucfirst($p->status)); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-3">
                                        Belum ada riwayat peminjaman
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mt-3">
    <a href="<?php echo e(route('petugas.peminjam.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i> Kembali
    </a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/peminjam/show.blade.php ENDPATH**/ ?>