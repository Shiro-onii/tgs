

<?php $__env->startSection('title', 'Kelola Pengembalian'); ?>
<?php $__env->startSection('page-title', 'Kelola Data Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('admin.pengembalian.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Pengembalian
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode Peminjaman</th>
                        <th>Peminjam</th>
                        <th>Alat</th>
                        <th>Tgl Pengembalian</th>
                        <th>Jumlah</th>
                        <th>Kondisi</th>
                        <th>Denda</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pengembalians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($p->peminjaman->kode_peminjaman ?? '-'); ?></td>
                            <td><?php echo e($p->peminjaman->user->name ?? '-'); ?></td>
                            <td><?php echo e($p->peminjaman->alat->nama_alat ?? '-'); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pengembalian))); ?></td>
                            <td><?php echo e($p->jumlah_dikembalikan); ?></td>
                            <td>
                                <?php
                                    $kondisiBadge = match($p->kondisi_alat) {
                                        'baik' => 'bg-success',
                                        'rusak_ringan' => 'bg-warning text-dark',
                                        'rusak_berat' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                ?>
                                <span class="badge <?php echo e($kondisiBadge); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $p->kondisi_alat))); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($p->denda > 0 ? 'danger' : 'success'); ?>">
                                    Rp <?php echo e(number_format($p->denda, 0, ',', '.')); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.pengembalian.show', $p->id)); ?>" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.pengembalian.edit', $p->id)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.pengembalian.destroy', $p->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus pengembalian ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Belum ada data pengembalian
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($pengembalians->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/pengembalian/index.blade.php ENDPATH**/ ?>