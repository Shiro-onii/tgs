

<?php $__env->startSection('title', 'Approval Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Menyetujui Peminjaman'); ?>

<?php $__env->startSection('content'); ?>

<!-- Tabs untuk filter status -->
<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="menunggu-tab" data-bs-toggle="tab" data-bs-target="#menunggu" type="button">
            Menunggu Approval <span class="badge bg-warning text-dark"><?php echo e($peminjamans->where('status', 'menunggu')->count()); ?></span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="disetujui-tab" data-bs-toggle="tab" data-bs-target="#disetujui" type="button">
            Disetujui <span class="badge bg-success"><?php echo e($peminjamans->where('status', 'disetujui')->count()); ?></span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="dipinjam-tab" data-bs-toggle="tab" data-bs-target="#dipinjam" type="button">
            Dipinjam <span class="badge bg-info"><?php echo e($peminjamans->where('status', 'dipinjam')->count()); ?></span>
        </button>
    </li>
</ul>

<!-- Tab Content -->
<div class="tab-content">
    <!-- Menunggu Approval -->
    <div class="tab-pane fade show active" id="menunggu" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Keperluan</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans->where('status', 'menunggu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->user->name ?? '-'); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                    <td><?php echo e(Str::limit($p->keperluan, 40)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('petugas.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form action="<?php echo e(route('petugas.peminjaman.approve', $p->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Setujui peminjaman ini?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-success">
                                                <i class="fas fa-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('petugas.peminjaman.reject', $p->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Tolak peminjaman ini?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-times"></i> Tolak
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        Tidak ada peminjaman yang menunggu approval
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Disetujui -->
    <div class="tab-pane fade" id="disetujui" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans->where('status', 'disetujui'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->user->name ?? '-'); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('petugas.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        Tidak ada peminjaman yang disetujui
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Dipinjam -->
    <div class="tab-pane fade" id="dipinjam" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Kembali</th>
                                <th>Sisa Hari</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans->where('status', 'dipinjam'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $today = \Carbon\Carbon::now();
                                    $tglKembali = \Carbon\Carbon::parse($p->tanggal_kembali_rencana);
                                    $sisaHari = $today->diffInDays($tglKembali, false);
                                    $isOverdue = $sisaHari < 0;
                                ?>
                                <tr class="<?php echo e($isOverdue ? 'table-danger' : ''); ?>">
                                    <td><?php echo e($p->kode_peminjaman); ?></td>
                                    <td><?php echo e($p->user->name ?? '-'); ?></td>
                                    <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                                    <td><?php echo e($p->jumlah_pinjam); ?></td>
                                    <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($isOverdue ? 'danger' : 'success'); ?>">
                                            <?php echo e($isOverdue ? 'Terlambat ' . abs($sisaHari) : $sisaHari); ?> hari
                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('petugas.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        Tidak ada alat yang sedang dipinjam
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/peminjaman/index.blade.php ENDPATH**/ ?>