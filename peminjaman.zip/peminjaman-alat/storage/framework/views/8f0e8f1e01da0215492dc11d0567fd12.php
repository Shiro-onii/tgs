

<?php $__env->startSection('title', 'Detail Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Detail Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Peminjaman</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm table-borderless">
                    <tr>
                        <th width="30%">Kode Peminjaman</th>
                        <td>: <?php echo e($peminjaman->kode_peminjaman); ?></td>
                    </tr>
                    <tr>
                        <th>Peminjam</th>
                        <td>: <?php echo e($peminjaman->user->name ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Alat</th>
                        <td>: <?php echo e($peminjaman->alat->nama_alat ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Jumlah Pinjam</th>
                        <td>: <?php echo e($peminjaman->jumlah_pinjam); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Pinjam</th>
                        <td>: <?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_pinjam))); ?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Kembali (Rencana)</th>
                        <td>: <?php echo e(date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana))); ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <?php
                                $badgeClass = match($peminjaman->status) {
                                    'menunggu' => 'bg-warning text-dark',
                                    'disetujui' => 'bg-success',
                                    'dipinjam' => 'bg-info',
                                    'dikembalikan' => 'bg-secondary',
                                    'ditolak' => 'bg-danger',
                                    default => 'bg-secondary'
                                };
                            ?>
                            <span class="badge <?php echo e($badgeClass); ?>"><?php echo e(ucfirst($peminjaman->status)); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th>Keperluan</th>
                        <td>: <?php echo e($peminjaman->keperluan); ?></td>
                    </tr>
                    <tr>
                        <th>Petugas Menyetujui</th>
                        <td>: <?php echo e($peminjaman->petugas->name ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>Catatan Petugas</th>
                        <td>: <?php echo e($peminjaman->catatan_petugas ?? '-'); ?></td>
                    </tr>
                </table>

                <?php if($peminjaman->status === 'menunggu'): ?>
                    <div class="mt-3 d-flex gap-2">
                        <form action="<?php echo e(route('petugas.peminjaman.approve', $peminjaman->id)); ?>" method="POST" 
                              onsubmit="return confirm('Setujui peminjaman ini?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check me-1"></i> Setujui
                            </button>
                        </form>

                        <form action="<?php echo e(route('petugas.peminjaman.reject', $peminjaman->id)); ?>" method="POST" 
                              onsubmit="return confirm('Tolak peminjaman ini?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-times me-1"></i> Tolak
                            </button>
                        </form>
                    </div>
                <?php endif; ?>

                <a href="<?php echo e(route('petugas.peminjaman.index')); ?>" class="btn btn-secondary mt-3">
                    <i class="fas fa-arrow-left me-1"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/peminjaman/show.blade.php ENDPATH**/ ?>