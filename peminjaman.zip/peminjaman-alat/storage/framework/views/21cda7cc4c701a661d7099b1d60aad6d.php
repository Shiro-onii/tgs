

<?php $__env->startSection('title', 'Daftar Alat'); ?>
<?php $__env->startSection('page-title', 'Daftar Alat Tersedia'); ?>

<?php $__env->startSection('content'); ?>

<!-- Filter & Search -->
<div class="card mb-3">
    <div class="card-body">
        <form action="<?php echo e(route('peminjam.alat.index')); ?>" method="GET">
            <div class="row">
                <div class="col-md-5 mb-2">
                    <input type="text" name="search" class="form-control" placeholder="Cari alat..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-4 mb-2">
                    <select name="kategori" class="form-select">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kat->id); ?>" <?php echo e(request('kategori') == $kat->id ? 'selected' : ''); ?>>
                                <?php echo e($kat->nama_kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3 mb-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Cari
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Alat Cards -->
<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $alats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <?php if($alat->foto): ?>
                    <img src="<?php echo e(asset('storage/' . $alat->foto)); ?>" class="card-img-top" alt="<?php echo e($alat->nama_alat); ?>" style="height: 200px; object-fit: cover;">
                <?php else: ?>
                    <div class="bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                        <i class="fas fa-tools fa-4x text-muted"></i>
                    </div>
                <?php endif; ?>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0"><?php echo e($alat->nama_alat); ?></h5>
                        <span class="badge bg-success">Tersedia</span>
                    </div>
                    
                    <!-- ✅ TAMPIL HARGA -->
                    <h4 class="text-primary mb-2">
                        Rp <?php echo e(number_format($alat->harga, 0, ',', '.')); ?>

                    </h4>
                    
                    <p class="text-muted small mb-2">
                        <i class="fas fa-barcode me-1"></i> <?php echo e($alat->kode_alat); ?> 
                        <span class="ms-2"><i class="fas fa-tag me-1"></i> <?php echo e($alat->kategori->nama_kategori ?? '-'); ?></span>
                    </p>
                    <?php if($alat->merk): ?>
                        <p class="mb-2"><small><strong>Merk:</strong> <?php echo e($alat->merk); ?></small></p>
                    <?php endif; ?>
                    <?php if($alat->spesifikasi): ?>
                        <p class="mb-2 small"><?php echo e(Str::limit($alat->spesifikasi, 80)); ?></p>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="badge bg-info fs-6">
                            Tersedia: <?php echo e($alat->jumlah_tersedia); ?>

                        </span>
                        <a href="<?php echo e(route('peminjam.peminjaman.create', ['alat_id' => $alat->id])); ?>" class="btn btn-sm btn-success">
                            <i class="fas fa-hand-holding me-1"></i> Pinjam
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                    <h5>Tidak ada alat tersedia</h5>
                    <p class="text-muted">Silakan coba lagi nanti</p>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="mt-3">
    <?php echo e($alats->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjam/alat/index.blade.php ENDPATH**/ ?>