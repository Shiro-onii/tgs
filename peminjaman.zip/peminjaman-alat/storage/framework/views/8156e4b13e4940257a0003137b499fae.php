

<?php $__env->startSection('title', 'Edit Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Edit Data Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Edit Peminjaman</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.peminjaman.update', $peminjaman->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="alert alert-info">
                        <strong>Info:</strong> Kode Peminjaman: <strong><?php echo e($peminjaman->kode_peminjaman); ?></strong>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Peminjam</label>
                        <input type="text" class="form-control" value="<?php echo e($peminjaman->user->name); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Alat</label>
                        <input type="text" class="form-control" value="<?php echo e($peminjaman->alat->nama_alat); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="jumlah_pinjam" class="form-label">Jumlah <span class="text-danger">*</span></label>
                        <input type="number" class="form-control <?php $__errorArgs = ['jumlah_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="jumlah_pinjam" name="jumlah_pinjam" value="<?php echo e(old('jumlah_pinjam', $peminjaman->jumlah_pinjam)); ?>" min="1" required>
                        <?php $__errorArgs = ['jumlah_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pinjam" class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_pinjam" name="tanggal_pinjam" value="<?php echo e(old('tanggal_pinjam', $peminjaman->tanggal_pinjam)); ?>" required>
                                <?php $__errorArgs = ['tanggal_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_kembali_rencana" class="form-label">Tanggal Kembali (Rencana) <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tanggal_kembali_rencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="tanggal_kembali_rencana" name="tanggal_kembali_rencana" value="<?php echo e(old('tanggal_kembali_rencana', $peminjaman->tanggal_kembali_rencana)); ?>" required>
                                <?php $__errorArgs = ['tanggal_kembali_rencana'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="keperluan" class="form-label">Keperluan <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['keperluan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="keperluan" name="keperluan" rows="3" required><?php echo e(old('keperluan', $peminjaman->keperluan)); ?></textarea>
                        <?php $__errorArgs = ['keperluan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="menunggu" <?php echo e($peminjaman->status == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
                            <option value="disetujui" <?php echo e($peminjaman->status == 'disetujui' ? 'selected' : ''); ?>>Disetujui</option>
                            <option value="ditolak" <?php echo e($peminjaman->status == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                            <option value="dipinjam" <?php echo e($peminjaman->status == 'dipinjam' ? 'selected' : ''); ?>>Dipinjam</option>
                            <option value="dikembalikan" <?php echo e($peminjaman->status == 'dikembalikan' ? 'selected' : ''); ?>>Dikembalikan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="catatan_petugas" class="form-label">Catatan Petugas</label>
                        <textarea class="form-control" id="catatan_petugas" name="catatan_petugas" rows="2"><?php echo e(old('catatan_petugas', $peminjaman->catatan_petugas)); ?></textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update
                        </button>
                        <a href="<?php echo e(route('admin.peminjaman.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/peminjaman/edit.blade.php ENDPATH**/ ?>