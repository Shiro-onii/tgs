

<?php $__env->startSection('title', 'Kelola Peminjaman'); ?>
<?php $__env->startSection('page-title', 'Kelola Data Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('admin.peminjaman.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Peminjaman
        </a>
    </div>
</div>

<!-- Filter Tabs -->
<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item">
        <a class="nav-link <?php echo e(!request('status') ? 'active' : ''); ?>" href="<?php echo e(route('admin.peminjaman.index')); ?>">
            Semua <span class="badge bg-secondary"><?php echo e($peminjamans->total()); ?></span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'menunggu' ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.peminjaman.index', ['status' => 'menunggu'])); ?>">
            Menunggu <span class="badge bg-warning text-dark"><?php echo e($stats['menunggu'] ?? 0); ?></span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'disetujui' ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.peminjaman.index', ['status' => 'disetujui'])); ?>">
            Disetujui <span class="badge bg-success"><?php echo e($stats['disetujui'] ?? 0); ?></span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'dipinjam' ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.peminjaman.index', ['status' => 'dipinjam'])); ?>">
            Dipinjam <span class="badge bg-info"><?php echo e($stats['dipinjam'] ?? 0); ?></span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'dikembalikan' ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.peminjaman.index', ['status' => 'dikembalikan'])); ?>">
            Dikembalikan <span class="badge bg-secondary"><?php echo e($stats['dikembalikan'] ?? 0); ?></span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(request('status') == 'ditolak' ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.peminjaman.index', ['status' => 'ditolak'])); ?>">
            Ditolak <span class="badge bg-danger"><?php echo e($stats['ditolak'] ?? 0); ?></span>
        </a>
    </li>
</ul>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Peminjam</th>
                        <th>Alat</th>
                        <th>Jumlah</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($p->kode_peminjaman); ?></td>
                            <td><?php echo e($p->user->name ?? '-'); ?></td>
                            <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
                            <td><?php echo e($p->jumlah_pinjam); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                            <td>
                                <?php
                                    $badgeClass = match($p->status) {
                                        'menunggu' => 'bg-warning text-dark',
                                        'disetujui' => 'bg-success',
                                        'ditolak' => 'bg-danger',
                                        'dipinjam' => 'bg-info',
                                        'dikembalikan' => 'bg-secondary',
                                        default => 'bg-secondary'
                                    };
                                ?>
                                <span class="badge <?php echo e($badgeClass); ?>">
                                    <?php echo e(ucfirst($p->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.peminjaman.edit', $p->id)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if(!in_array($p->status, ['disetujui', 'dipinjam'])): ?>
                                    <form action="<?php echo e(route('admin.peminjaman.destroy', $p->id)); ?>" method="POST" class="d-inline" 
                                          onsubmit="return confirm('Yakin ingin menghapus?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Tidak ada data peminjaman
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($peminjamans->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/peminjaman/index.blade.php ENDPATH**/ ?>