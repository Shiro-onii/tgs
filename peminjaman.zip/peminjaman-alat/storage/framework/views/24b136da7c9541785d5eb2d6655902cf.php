

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


<?php if(auth()->user()->role === 'admin'): ?>
    <div class="row">
        
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total User</h6>
                            <h3 class="mb-0"><?php echo e($stats['total_users']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-users fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Alat</h6>
                            <h3 class="mb-0"><?php echo e($stats['total_alat']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-toolbox fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Sedang Dipinjam</h6>
                            <h3 class="mb-0"><?php echo e($stats['dipinjam']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-handshake fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Denda</h6>
                            <h3 class="mb-0">Rp <?php echo e(number_format($stats['total_denda'], 0, ',', '.')); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-money-bill fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Peminjaman Menunggu Approval</h5>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $pending_peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                            <div>
                                <strong><?php echo e($p->kode_peminjaman); ?></strong><br>
                                <small class="text-muted"><?php echo e($p->user->name); ?> - <?php echo e($p->alat->nama_alat); ?></small>
                            </div>
                            <span class="badge bg-warning text-dark">Menunggu</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted text-center py-3">Tidak ada peminjaman menunggu</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Alat Stok Menipis</h5>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $low_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                            <div>
                                <strong><?php echo e($alat->nama_alat); ?></strong><br>
                                <small class="text-muted"><?php echo e($alat->kode_alat); ?></small>
                            </div>
                            <span class="badge bg-danger"><?php echo e($alat->jumlah_tersedia); ?>/<?php echo e($alat->jumlah_total); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted text-center py-3">Semua stok aman</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>


<?php elseif(auth()->user()->role === 'petugas'): ?>
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Menunggu Approval</h6>
                            <h3 class="mb-0"><?php echo e($stats['menunggu']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-clock fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Sedang Dipinjam</h6>
                            <h3 class="mb-0"><?php echo e($stats['dipinjam']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-handshake fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Pengembalian</h6>
                            <h3 class="mb-0"><?php echo e($stats['pengembalian']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-undo fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Peminjaman Menunggu Approval</h5>
                    <a href="<?php echo e(route('petugas.peminjaman.index')); ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Peminjam</th>
                                    <th>Alat</th>
                                    <th>Jumlah</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $pending_peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($p->kode_peminjaman); ?></td>
                                        <td><?php echo e($p->user->name); ?></td>
                                        <td><?php echo e($p->alat->nama_alat); ?></td>
                                        <td><?php echo e($p->jumlah_pinjam); ?></td>
                                        <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('petugas.peminjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">Detail</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-3">Tidak ada peminjaman menunggu</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php else: ?>
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Peminjaman</h6>
                            <h3 class="mb-0"><?php echo e($stats['total_peminjaman']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-list fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Sedang Dipinjam</h6>
                            <h3 class="mb-0"><?php echo e($stats['sedang_dipinjam']); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-handshake fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Denda</h6>
                            <h3 class="mb-0">Rp <?php echo e(number_format($stats['total_denda'], 0, ',', '.')); ?></h3>
                        </div>
                        <div>
                            <i class="fas fa-money-bill fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Peminjaman Aktif Saya</h5>
                    <a href="<?php echo e(route('peminjam.peminjaman.index')); ?>" class="btn btn-sm btn-primary">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Alat</th>
                                    <th>Jumlah</th>
                                    <th>Tgl Pinjam</th>
                                    <th>Tgl Kembali</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $my_peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($p->kode_peminjaman); ?></td>
                                        <td><?php echo e($p->alat->nama_alat); ?></td>
                                        <td><?php echo e($p->jumlah_pinjam); ?></td>
                                        <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_pinjam))); ?></td>
                                        <td><?php echo e(date('d/m/Y', strtotime($p->tanggal_kembali_rencana))); ?></td>
                                        <td>
                                            <?php
                                                $badgeClass = match($p->status) {
                                                    'menunggu' => 'bg-warning text-dark',
                                                    'disetujui' => 'bg-success',
                                                    'ditolak' => 'bg-danger',
                                                    'dipinjam' => 'bg-info',
                                                    default => 'bg-secondary'
                                                };
                                            ?>
                                            <span class="badge <?php echo e($badgeClass); ?>"><?php echo e(ucfirst($p->status)); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-3">Belum ada peminjaman aktif</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/dashboard.blade.php ENDPATH**/ ?>