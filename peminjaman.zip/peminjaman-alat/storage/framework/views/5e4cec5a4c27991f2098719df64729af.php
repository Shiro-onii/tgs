

<?php $__env->startSection('title', 'Kelola Alat'); ?>
<?php $__env->startSection('page-title', 'Kelola Data Alat'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col-12">
        <a href="<?php echo e(route('admin.alat.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Alat
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Alat</th>
                        <th>Kategori</th>
                        <th>Harga</th>                      <!-- ✅ KOLOM BARU -->
                        <th>Stok</th>
                        <th>Kondisi</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $alats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($alat->kode_alat); ?></td>
                            <td>
                                <?php if($alat->foto): ?>
                                    <img src="<?php echo e(asset('storage/' . $alat->foto)); ?>" alt="<?php echo e($alat->nama_alat); ?>" 
                                         style="width: 40px; height: 40px; object-fit: cover; border-radius: 5px;" class="me-2">
                                <?php endif; ?>
                                <?php echo e($alat->nama_alat); ?>

                            </td>
                            <td><?php echo e($alat->kategori->nama_kategori ?? '-'); ?></td>
                            <td class="fw-bold text-primary">              <!-- ✅ TAMPIL HARGA -->
                                Rp <?php echo e(number_format($alat->harga, 0, ',', '.')); ?>

                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($alat->jumlah_tersedia > 0 ? 'success' : 'danger'); ?>">
                                    <?php echo e($alat->jumlah_tersedia); ?>/<?php echo e($alat->jumlah_total); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($alat->kondisi == 'baik' ? 'success' : 'warning'); ?>">
                                    <?php echo e(ucfirst($alat->kondisi)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.alat.edit', $alat->id)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.alat.destroy', $alat->id)); ?>" method="POST" class="d-inline" 
                                      onsubmit="return confirm('Yakin ingin menghapus alat ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada data alat
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            <?php echo e($alats->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/alat/index.blade.php ENDPATH**/ ?>