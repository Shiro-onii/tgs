@extends('layouts.app')

@section('title', 'Detail Peminjam')
@section('page-title', 'Detail Peminjam')

@section('content')

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Peminjam</h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <div class="avatar-lg mx-auto mb-3" style="width: 100px; height: 100px; background: #667eea; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <span style="font-size: 3rem; color: white; font-weight: bold;">
                            {{ strtoupper(substr($peminjam->name, 0, 1)) }}
                        </span>
                    </div>
                    <h5 class="mb-1">{{ $peminjam->name }}</h5>
                    <span class="badge bg-primary">Peminjam</span>
                </div>

                <table class="table table-borderless">
                    <tr>
                        <th width="40%">Email</th>
                        <td>{{ $peminjam->email }}</td>
                    </tr>
                    <tr>
                        <th>No. Telepon</th>
                        <td>{{ $peminjam->phone ?? '-' }}</td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td>{{ $peminjam->address ?? '-' }}</td>
                    </tr>
                    <tr>
                        <th>Terdaftar</th>
                        <td>{{ $peminjam->created_at->format('d/m/Y H:i') }}</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Riwayat Peminjaman</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjam->peminjamans as $p)
                                <tr>
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                    <td>
                                        @php
                                            $badgeClass = match($p->status) {
                                                'menunggu' => 'bg-warning text-dark',
                                                'disetujui' => 'bg-success',
                                                'ditolak' => 'bg-danger',
                                                'dipinjam' => 'bg-info',
                                                'dikembalikan' => 'bg-secondary',
                                                default => 'bg-secondary'
                                            };
                                        @endphp
                                        <span class="badge {{ $badgeClass }}">
                                            {{ ucfirst($p->status) }}
                                        </span>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-3">
                                        Belum ada riwayat peminjaman
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mt-3">
    <a href="{{ route('petugas.peminjam.index') }}" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i> Kembali
    </a>
</div>

@endsection