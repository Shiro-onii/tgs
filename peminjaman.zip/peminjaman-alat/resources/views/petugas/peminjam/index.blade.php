@extends('layouts.app')

@section('title', 'Daftar Peminjam')
@section('page-title', 'Kelola Data Peminjam')

@section('content')

<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('petugas.peminjam.create') }}" class="btn btn-primary">
            <i class="fas fa-user-plus me-2"></i> Registrasi Peminjam Baru
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>No. Telepon</th>
                        <th>Terdaftar</th>
                        <th>Total Peminjaman</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($peminjams as $peminjam)
                        <tr>
                            <td>{{ $peminjam->name }}</td>
                            <td>{{ $peminjam->email }}</td>
                            <td>{{ $peminjam->phone ?? '-' }}</td>
                            <td>{{ $peminjam->created_at->format('d/m/Y') }}</td>
                            <td>
                                <span class="badge bg-info">
                                    {{ $peminjam->peminjamans_count }} peminjaman
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('petugas.peminjam.show', $peminjam->id) }}" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Detail
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                Belum ada peminjam terdaftar
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $peminjams->links() }}
        </div>
    </div>
</div>

@endsection