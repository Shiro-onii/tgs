@extends('layouts.app')

@section('title', 'Detail Peminjaman')
@section('page-title', 'Detail Peminjaman')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Informasi Peminjaman</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm table-borderless">
                    <tr>
                        <th width="30%">Kode Peminjaman</th>
                        <td>: {{ $peminjaman->kode_peminjaman }}</td>
                    </tr>
                    <tr>
                        <th>Peminjam</th>
                        <td>: {{ $peminjaman->user->name ?? '-' }}</td>
                    </tr>
                    <tr>
                        <th>Alat</th>
                        <td>: {{ $peminjaman->alat->nama_alat ?? '-' }}</td>
                    </tr>
                    <tr>
                        <th>Jumlah Pinjam</th>
                        <td>: {{ $peminjaman->jumlah_pinjam }}</td>
                    </tr>
                    <tr>
                        <th>Tanggal Pinjam</th>
                        <td>: {{ date('d/m/Y', strtotime($peminjaman->tanggal_pinjam)) }}</td>
                    </tr>
                    <tr>
                        <th>Tanggal Kembali (Rencana)</th>
                        <td>: {{ date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana)) }}</td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            @php
                                $badgeClass = match($peminjaman->status) {
                                    'menunggu' => 'bg-warning text-dark',
                                    'disetujui' => 'bg-success',
                                    'dipinjam' => 'bg-info',
                                    'dikembalikan' => 'bg-secondary',
                                    'ditolak' => 'bg-danger',
                                    default => 'bg-secondary'
                                };
                            @endphp
                            <span class="badge {{ $badgeClass }}">{{ ucfirst($peminjaman->status) }}</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Keperluan</th>
                        <td>: {{ $peminjaman->keperluan }}</td>
                    </tr>
                    <tr>
                        <th>Petugas Menyetujui</th>
                        <td>: {{ $peminjaman->petugas->name ?? '-' }}</td>
                    </tr>
                    <tr>
                        <th>Catatan Petugas</th>
                        <td>: {{ $peminjaman->catatan_petugas ?? '-' }}</td>
                    </tr>
                </table>

                @if($peminjaman->status === 'menunggu')
                    <div class="mt-3 d-flex gap-2">
                        <form action="{{ route('petugas.peminjaman.approve', $peminjaman->id) }}" method="POST" 
                              onsubmit="return confirm('Setujui peminjaman ini?')">
                            @csrf
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check me-1"></i> Setujui
                            </button>
                        </form>

                        <form action="{{ route('petugas.peminjaman.reject', $peminjaman->id) }}" method="POST" 
                              onsubmit="return confirm('Tolak peminjaman ini?')">
                            @csrf
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-times me-1"></i> Tolak
                            </button>
                        </form>
                    </div>
                @endif

                <a href="{{ route('petugas.peminjaman.index') }}" class="btn btn-secondary mt-3">
                    <i class="fas fa-arrow-left me-1"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</div>
@endsection