@extends('layouts.app')

@section('title', 'Approval Peminjaman')
@section('page-title', 'Menyetujui Peminjaman')

@section('content')

<!-- Tabs untuk filter status -->
<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="menunggu-tab" data-bs-toggle="tab" data-bs-target="#menunggu" type="button">
            Menunggu Approval <span class="badge bg-warning text-dark">{{ $peminjamans->where('status', 'menunggu')->count() }}</span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="disetujui-tab" data-bs-toggle="tab" data-bs-target="#disetujui" type="button">
            Disetujui <span class="badge bg-success">{{ $peminjamans->where('status', 'disetujui')->count() }}</span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="dipinjam-tab" data-bs-toggle="tab" data-bs-target="#dipinjam" type="button">
            Dipinjam <span class="badge bg-info">{{ $peminjamans->where('status', 'dipinjam')->count() }}</span>
        </button>
    </li>
</ul>

<!-- Tab Content -->
<div class="tab-content">
    <!-- Menunggu Approval -->
    <div class="tab-pane fade show active" id="menunggu" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Keperluan</th>
                                <th width="20%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjamans->where('status', 'menunggu') as $p)
                                <tr>
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->user->name ?? '-' }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                    <td>{{ Str::limit($p->keperluan, 40) }}</td>
                                    <td>
                                        <a href="{{ route('petugas.peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form action="{{ route('petugas.peminjaman.approve', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Setujui peminjaman ini?')">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-success">
                                                <i class="fas fa-check"></i> Setujui
                                            </button>
                                        </form>
                                        <form action="{{ route('petugas.peminjaman.reject', $p->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Tolak peminjaman ini?')">
                                            @csrf
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-times"></i> Tolak
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        Tidak ada peminjaman yang menunggu approval
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Disetujui -->
    <div class="tab-pane fade" id="disetujui" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjamans->where('status', 'disetujui') as $p)
                                <tr>
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->user->name ?? '-' }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                                    <td>
                                        <a href="{{ route('petugas.peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        Tidak ada peminjaman yang disetujui
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Dipinjam -->
    <div class="tab-pane fade" id="dipinjam" role="tabpanel">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Peminjam</th>
                                <th>Alat</th>
                                <th>Jumlah</th>
                                <th>Tgl Kembali</th>
                                <th>Sisa Hari</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($peminjamans->where('status', 'dipinjam') as $p)
                                @php
                                    $today = \Carbon\Carbon::now();
                                    $tglKembali = \Carbon\Carbon::parse($p->tanggal_kembali_rencana);
                                    $sisaHari = $today->diffInDays($tglKembali, false);
                                    $isOverdue = $sisaHari < 0;
                                @endphp
                                <tr class="{{ $isOverdue ? 'table-danger' : '' }}">
                                    <td>{{ $p->kode_peminjaman }}</td>
                                    <td>{{ $p->user->name ?? '-' }}</td>
                                    <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                                    <td>{{ $p->jumlah_pinjam }}</td>
                                    <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                                    <td>
                                        <span class="badge bg-{{ $isOverdue ? 'danger' : 'success' }}">
                                            {{ $isOverdue ? 'Terlambat ' . abs($sisaHari) : $sisaHari }} hari
                                        </span>
                                    </td>
                                    <td>
                                        <a href="{{ route('petugas.peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        Tidak ada alat yang sedang dipinjam
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection