@extends('layouts.app')

@section('title', 'Tambah Peminjaman')
@section('page-title', 'Tambah Data Peminjaman')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Tambah Peminjaman</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.peminjaman.store') }}" method="POST">
                    @csrf
                    
                    <div class="mb-3">
                        <label for="user_id" class="form-label">Peminjam <span class="text-danger">*</span></label>
                        <select class="form-select @error('user_id') is-invalid @enderror" 
                                id="user_id" name="user_id" required>
                            <option value="">-- Pilih Peminjam --</option>
                            @foreach($users as $user)
                                <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected' : '' }}>
                                    {{ $user->name }} ({{ $user->email }})
                                </option>
                            @endforeach
                        </select>
                        @error('user_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="alat_id" class="form-label">Alat <span class="text-danger">*</span></label>
                        <select class="form-select @error('alat_id') is-invalid @enderror" 
                                id="alat_id" name="alat_id" required onchange="updateStokInfo()">
                            <option value="">-- Pilih Alat --</option>
                            @foreach($alats as $alat)
                                <option value="{{ $alat->id }}" 
                                        data-stok="{{ $alat->jumlah_tersedia }}"
                                        {{ old('alat_id') == $alat->id ? 'selected' : '' }}>
                                    {{ $alat->nama_alat }} - {{ $alat->kode_alat }}
                                </option>
                            @endforeach
                        </select>
                        <small id="stokInfo" class="text-muted"></small>
                        @error('alat_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="jumlah_pinjam" class="form-label">Jumlah <span class="text-danger">*</span></label>
                                <input type="number" class="form-control @error('jumlah_pinjam') is-invalid @enderror" 
                                       id="jumlah_pinjam" name="jumlah_pinjam" value="{{ old('jumlah_pinjam', 1) }}" min="1" required>
                                @error('jumlah_pinjam')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pinjam" class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('tanggal_pinjam') is-invalid @enderror" 
                                       id="tanggal_pinjam" name="tanggal_pinjam" value="{{ old('tanggal_pinjam', date('Y-m-d')) }}" required>
                                @error('tanggal_pinjam')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_kembali_rencana" class="form-label">Tanggal Kembali (Rencana) <span class="text-danger">*</span></label>
                        <input type="date" class="form-control @error('tanggal_kembali_rencana') is-invalid @enderror" 
                               id="tanggal_kembali_rencana" name="tanggal_kembali_rencana" value="{{ old('tanggal_kembali_rencana') }}" required>
                        @error('tanggal_kembali_rencana')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="keperluan" class="form-label">Keperluan <span class="text-danger">*</span></label>
                        <textarea class="form-control @error('keperluan') is-invalid @enderror" 
                                  id="keperluan" name="keperluan" rows="3" required>{{ old('keperluan') }}</textarea>
                        @error('keperluan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="auto_approve" name="auto_approve" value="1">
                        <label class="form-check-label" for="auto_approve">
                            Setujui Otomatis (Admin)
                        </label>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Simpan
                        </button>
                        <a href="{{ route('admin.peminjaman.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function updateStokInfo() {
    const select = document.getElementById('alat_id');
    const selected = select.options[select.selectedIndex];
    const stok = selected.getAttribute('data-stok');
    const jumlahInput = document.getElementById('jumlah_pinjam');
    
    if (stok) {
        document.getElementById('stokInfo').textContent = `Stok tersedia: ${stok}`;
        jumlahInput.max = stok;
    } else {
        document.getElementById('stokInfo').textContent = '';
        jumlahInput.max = '';
    }
}

window.addEventListener('load', updateStokInfo);
</script>
@endpush
@endsection