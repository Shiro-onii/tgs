@extends('layouts.app')

@section('title', 'Edit Peminjaman')
@section('page-title', 'Edit Data Peminjaman')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Edit Peminjaman</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.peminjaman.update', $peminjaman->id) }}" method="POST">
                    @csrf
                    @method('PUT')
                    
                    <div class="alert alert-info">
                        <strong>Info:</strong> Kode Peminjaman: <strong>{{ $peminjaman->kode_peminjaman }}</strong>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Peminjam</label>
                        <input type="text" class="form-control" value="{{ $peminjaman->user->name }}" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Alat</label>
                        <input type="text" class="form-control" value="{{ $peminjaman->alat->nama_alat }}" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="jumlah_pinjam" class="form-label">Jumlah <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('jumlah_pinjam') is-invalid @enderror" 
                               id="jumlah_pinjam" name="jumlah_pinjam" value="{{ old('jumlah_pinjam', $peminjaman->jumlah_pinjam) }}" min="1" required>
                        @error('jumlah_pinjam')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pinjam" class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('tanggal_pinjam') is-invalid @enderror" 
                                       id="tanggal_pinjam" name="tanggal_pinjam" value="{{ old('tanggal_pinjam', $peminjaman->tanggal_pinjam) }}" required>
                                @error('tanggal_pinjam')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_kembali_rencana" class="form-label">Tanggal Kembali (Rencana) <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('tanggal_kembali_rencana') is-invalid @enderror" 
                                       id="tanggal_kembali_rencana" name="tanggal_kembali_rencana" value="{{ old('tanggal_kembali_rencana', $peminjaman->tanggal_kembali_rencana) }}" required>
                                @error('tanggal_kembali_rencana')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="keperluan" class="form-label">Keperluan <span class="text-danger">*</span></label>
                        <textarea class="form-control @error('keperluan') is-invalid @enderror" 
                                  id="keperluan" name="keperluan" rows="3" required>{{ old('keperluan', $peminjaman->keperluan) }}</textarea>
                        @error('keperluan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="menunggu" {{ $peminjaman->status == 'menunggu' ? 'selected' : '' }}>Menunggu</option>
                            <option value="disetujui" {{ $peminjaman->status == 'disetujui' ? 'selected' : '' }}>Disetujui</option>
                            <option value="ditolak" {{ $peminjaman->status == 'ditolak' ? 'selected' : '' }}>Ditolak</option>
                            <option value="dipinjam" {{ $peminjaman->status == 'dipinjam' ? 'selected' : '' }}>Dipinjam</option>
                            <option value="dikembalikan" {{ $peminjaman->status == 'dikembalikan' ? 'selected' : '' }}>Dikembalikan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="catatan_petugas" class="form-label">Catatan Petugas</label>
                        <textarea class="form-control" id="catatan_petugas" name="catatan_petugas" rows="2">{{ old('catatan_petugas', $peminjaman->catatan_petugas) }}</textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update
                        </button>
                        <a href="{{ route('admin.peminjaman.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection