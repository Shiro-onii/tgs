@extends('layouts.app')

@section('title', 'Kelola Peminjaman')
@section('page-title', 'Kelola Data Peminjaman')

@section('content')
<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('admin.peminjaman.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Peminjaman
        </a>
    </div>
</div>

<!-- Filter Tabs -->
<ul class="nav nav-tabs mb-3" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{ !request('status') ? 'active' : '' }}" href="{{ route('admin.peminjaman.index') }}">
            Semua <span class="badge bg-secondary">{{ $peminjamans->total() }}</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ request('status') == 'menunggu' ? 'active' : '' }}" 
           href="{{ route('admin.peminjaman.index', ['status' => 'menunggu']) }}">
            Menunggu <span class="badge bg-warning text-dark">{{ $stats['menunggu'] ?? 0 }}</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ request('status') == 'disetujui' ? 'active' : '' }}" 
           href="{{ route('admin.peminjaman.index', ['status' => 'disetujui']) }}">
            Disetujui <span class="badge bg-success">{{ $stats['disetujui'] ?? 0 }}</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ request('status') == 'dipinjam' ? 'active' : '' }}" 
           href="{{ route('admin.peminjaman.index', ['status' => 'dipinjam']) }}">
            Dipinjam <span class="badge bg-info">{{ $stats['dipinjam'] ?? 0 }}</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ request('status') == 'dikembalikan' ? 'active' : '' }}" 
           href="{{ route('admin.peminjaman.index', ['status' => 'dikembalikan']) }}">
            Dikembalikan <span class="badge bg-secondary">{{ $stats['dikembalikan'] ?? 0 }}</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ request('status') == 'ditolak' ? 'active' : '' }}" 
           href="{{ route('admin.peminjaman.index', ['status' => 'ditolak']) }}">
            Ditolak <span class="badge bg-danger">{{ $stats['ditolak'] ?? 0 }}</span>
        </a>
    </li>
</ul>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Peminjam</th>
                        <th>Alat</th>
                        <th>Jumlah</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($peminjamans as $p)
                        <tr>
                            <td>{{ $p->kode_peminjaman }}</td>
                            <td>{{ $p->user->name ?? '-' }}</td>
                            <td>{{ $p->alat->nama_alat ?? '-' }}</td>
                            <td>{{ $p->jumlah_pinjam }}</td>
                            <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                            <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                            <td>
                                @php
                                    $badgeClass = match($p->status) {
                                        'menunggu' => 'bg-warning text-dark',
                                        'disetujui' => 'bg-success',
                                        'ditolak' => 'bg-danger',
                                        'dipinjam' => 'bg-info',
                                        'dikembalikan' => 'bg-secondary',
                                        default => 'bg-secondary'
                                    };
                                @endphp
                                <span class="badge {{ $badgeClass }}">
                                    {{ ucfirst($p->status) }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('admin.peminjaman.show', $p->id) }}" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="{{ route('admin.peminjaman.edit', $p->id) }}" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                @if(!in_array($p->status, ['disetujui', 'dipinjam']))
                                    <form action="{{ route('admin.peminjaman.destroy', $p->id) }}" method="POST" class="d-inline" 
                                          onsubmit="return confirm('Yakin ingin menghapus?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">
                                Tidak ada data peminjaman
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $peminjamans->links() }}
        </div>
    </div>
</div>
@endsection