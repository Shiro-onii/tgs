@extends('layouts.app')

@section('title', 'Kelola Alat')
@section('page-title', 'Kelola Data Alat')

@section('content')
<div class="row mb-3">
    <div class="col-12">
        <a href="{{ route('admin.alat.create') }}" class="btn btn-primary">
            <i class="fas fa-plus me-2"></i> Tambah Alat
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Alat</th>
                        <th>Kategori</th>
                        <th>Harga</th>                      <!-- ✅ KOLOM BARU -->
                        <th>Stok</th>
                        <th>Kondisi</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($alats as $alat)
                        <tr>
                            <td>{{ $alat->kode_alat }}</td>
                            <td>
                                @if($alat->foto)
                                    <img src="{{ asset('storage/' . $alat->foto) }}" alt="{{ $alat->nama_alat }}" 
                                         style="width: 40px; height: 40px; object-fit: cover; border-radius: 5px;" class="me-2">
                                @endif
                                {{ $alat->nama_alat }}
                            </td>
                            <td>{{ $alat->kategori->nama_kategori ?? '-' }}</td>
                            <td class="fw-bold text-primary">              <!-- ✅ TAMPIL HARGA -->
                                Rp {{ number_format($alat->harga, 0, ',', '.') }}
                            </td>
                            <td>
                                <span class="badge bg-{{ $alat->jumlah_tersedia > 0 ? 'success' : 'danger' }}">
                                    {{ $alat->jumlah_tersedia }}/{{ $alat->jumlah_total }}
                                </span>
                            </td>
                            <td>
                                <span class="badge bg-{{ $alat->kondisi == 'baik' ? 'success' : 'warning' }}">
                                    {{ ucfirst($alat->kondisi) }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('admin.alat.edit', $alat->id) }}" class="btn btn-sm btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="{{ route('admin.alat.destroy', $alat->id) }}" method="POST" class="d-inline" 
                                      onsubmit="return confirm('Yakin ingin menghapus alat ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                Belum ada data alat
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-3">
            {{ $alats->links() }}
        </div>
    </div>
</div>
@endsection