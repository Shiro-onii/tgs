@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')

{{-- DASHBOARD ADMIN --}}
@if(auth()->user()->role === 'admin')
    <div class="row">
        {{-- Stats Cards --}}
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total User</h6>
                            <h3 class="mb-0">{{ $stats['total_users'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-users fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Alat</h6>
                            <h3 class="mb-0">{{ $stats['total_alat'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-toolbox fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Sedang Dipinjam</h6>
                            <h3 class="mb-0">{{ $stats['dipinjam'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-handshake fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-4">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Denda</h6>
                            <h3 class="mb-0">Rp {{ number_format($stats['total_denda'], 0, ',', '.') }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-money-bill fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        {{-- Peminjaman Menunggu Approval --}}
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Peminjaman Menunggu Approval</h5>
                </div>
                <div class="card-body">
                    @forelse($pending_peminjaman as $p)
                        <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                            <div>
                                <strong>{{ $p->kode_peminjaman }}</strong><br>
                                <small class="text-muted">{{ $p->user->name }} - {{ $p->alat->nama_alat }}</small>
                            </div>
                            <span class="badge bg-warning text-dark">Menunggu</span>
                        </div>
                    @empty
                        <p class="text-muted text-center py-3">Tidak ada peminjaman menunggu</p>
                    @endforelse
                </div>
            </div>
        </div>

        {{-- Alat Stok Menipis --}}
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Alat Stok Menipis</h5>
                </div>
                <div class="card-body">
                    @forelse($low_stock as $alat)
                        <div class="d-flex justify-content-between align-items-center mb-3 pb-3 border-bottom">
                            <div>
                                <strong>{{ $alat->nama_alat }}</strong><br>
                                <small class="text-muted">{{ $alat->kode_alat }}</small>
                            </div>
                            <span class="badge bg-danger">{{ $alat->jumlah_tersedia }}/{{ $alat->jumlah_total }}</span>
                        </div>
                    @empty
                        <p class="text-muted text-center py-3">Semua stok aman</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

{{-- DASHBOARD PETUGAS --}}
@elseif(auth()->user()->role === 'petugas')
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Menunggu Approval</h6>
                            <h3 class="mb-0">{{ $stats['menunggu'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-clock fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Sedang Dipinjam</h6>
                            <h3 class="mb-0">{{ $stats['dipinjam'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-handshake fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Pengembalian</h6>
                            <h3 class="mb-0">{{ $stats['pengembalian'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-undo fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Peminjaman Menunggu Approval</h5>
                    <a href="{{ route('petugas.peminjaman.index') }}" class="btn btn-sm btn-primary">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Peminjam</th>
                                    <th>Alat</th>
                                    <th>Jumlah</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($pending_peminjaman as $p)
                                    <tr>
                                        <td>{{ $p->kode_peminjaman }}</td>
                                        <td>{{ $p->user->name }}</td>
                                        <td>{{ $p->alat->nama_alat }}</td>
                                        <td>{{ $p->jumlah_pinjam }}</td>
                                        <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                        <td>
                                            <a href="{{ route('petugas.peminjaman.show', $p->id) }}" class="btn btn-sm btn-info">Detail</a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-3">Tidak ada peminjaman menunggu</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

{{-- DASHBOARD PEMINJAM --}}
@else
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Peminjaman</h6>
                            <h3 class="mb-0">{{ $stats['total_peminjaman'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-list fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Sedang Dipinjam</h6>
                            <h3 class="mb-0">{{ $stats['sedang_dipinjam'] }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-handshake fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="mb-1">Total Denda</h6>
                            <h3 class="mb-0">Rp {{ number_format($stats['total_denda'], 0, ',', '.') }}</h3>
                        </div>
                        <div>
                            <i class="fas fa-money-bill fa-3x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Peminjaman Aktif Saya</h5>
                    <a href="{{ route('peminjam.peminjaman.index') }}" class="btn btn-sm btn-primary">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Alat</th>
                                    <th>Jumlah</th>
                                    <th>Tgl Pinjam</th>
                                    <th>Tgl Kembali</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($my_peminjaman as $p)
                                    <tr>
                                        <td>{{ $p->kode_peminjaman }}</td>
                                        <td>{{ $p->alat->nama_alat }}</td>
                                        <td>{{ $p->jumlah_pinjam }}</td>
                                        <td>{{ date('d/m/Y', strtotime($p->tanggal_pinjam)) }}</td>
                                        <td>{{ date('d/m/Y', strtotime($p->tanggal_kembali_rencana)) }}</td>
                                        <td>
                                            @php
                                                $badgeClass = match($p->status) {
                                                    'menunggu' => 'bg-warning text-dark',
                                                    'disetujui' => 'bg-success',
                                                    'ditolak' => 'bg-danger',
                                                    'dipinjam' => 'bg-info',
                                                    default => 'bg-secondary'
                                                };
                                            @endphp
                                            <span class="badge {{ $badgeClass }}">{{ ucfirst($p->status) }}</span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-3">Belum ada peminjaman aktif</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif

@endsection