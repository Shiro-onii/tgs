@extends('layouts.app')

@section('title', 'Kembalikan Alat')
@section('page-title', 'Pengembalian Alat')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Form Pengembalian Alat</h5>
            </div>
            <div class="card-body">
                <!-- Info Peminjaman -->
                <div class="alert alert-info">
                    <h6 class="alert-heading">Informasi Peminjaman</h6>
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <th width="30%">Kode</th>
                            <td>: {{ $peminjaman->kode_peminjaman }}</td>
                        </tr>
                        <tr>
                            <th>Alat</th>
                            <td>: {{ $peminjaman->alat->nama_alat }}</td>
                        </tr>
                        <tr>
                             <th>Harga Alat</th>
                             <td>: Rp {{ number_format($peminjaman->alat->harga, 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <th>Jumlah Pinjam</th>
                            <td>: {{ $peminjaman->jumlah_pinjam }} unit</td>
                        </tr>
                        <tr>
                            <th>Tgl Kembali (Rencana)</th>
                            <td>: {{ date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana)) }}</td>
                        </tr>
                    </table>
                </div>

                <form action="{{ route('peminjam.pengembalian.store') }}" method="POST">
                    @csrf
                    
                    <input type="hidden" name="peminjaman_id" value="{{ $peminjaman->id }}">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="jumlah_dikembalikan" class="form-label">Jumlah Dikembalikan <span class="text-danger">*</span></label>
                                <input type="number" class="form-control @error('jumlah_dikembalikan') is-invalid @enderror" 
                                       id="jumlah_dikembalikan" name="jumlah_dikembalikan" 
                                       value="{{ old('jumlah_dikembalikan', $peminjaman->jumlah_pinjam) }}" 
                                       min="1" max="{{ $peminjaman->jumlah_pinjam }}" required onchange="hitungDenda()">
                                @error('jumlah_dikembalikan')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tanggal_pengembalian" class="form-label">Tanggal Pengembalian <span class="text-danger">*</span></label>
                                <input type="date" class="form-control @error('tanggal_pengembalian') is-invalid @enderror" 
                                       id="tanggal_pengembalian" name="tanggal_pengembalian" 
                                       value="{{ old('tanggal_pengembalian', date('Y-m-d')) }}" 
                                       max="{{ date('Y-m-d') }}" required onchange="hitungDenda()">
                                @error('tanggal_pengembalian')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="kondisi_alat" class="form-label">Kondisi Alat <span class="text-danger">*</span></label>
                        <select class="form-select @error('kondisi_alat') is-invalid @enderror" 
                                id="kondisi_alat" name="kondisi_alat" required onchange="hitungDenda()">
                            <option value="baik" {{ old('kondisi_alat') == 'baik' ? 'selected' : '' }}>Baik (Tidak Ada Kerusakan)</option>
                            <option value="rusak_ringan" {{ old('kondisi_alat') == 'rusak_ringan' ? 'selected' : '' }}>Rusak Ringan (+ Rp 50.000)</option>
                            <option value="rusak_berat" {{ old('kondisi_alat') == 'rusak_berat' ? 'selected' : '' }}>Rusak Berat (+ Rp 200.000)</option>
                        </select>
                        @error('kondisi_alat')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan (Opsional)</label>
                        <textarea class="form-control @error('keterangan') is-invalid @enderror" 
                                  id="keterangan" name="keterangan" rows="3" placeholder="Tambahkan keterangan jika ada...">{{ old('keterangan') }}</textarea>
                        @error('keterangan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <!-- Perhitungan Denda -->
                    <div class="card bg-light mb-3">
                        <div class="card-body">
                            <h6 class="card-title">Perhitungan Denda</h6>
                            <div id="dendaInfo">
                                <p class="mb-1">Menghitung...</p>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-check me-2"></i> Kembalikan Alat
                        </button>
                        <a href="{{ route('peminjam.peminjaman.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left me-2"></i> Batal
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i> Informasi Denda</h6>
            </div>
            <div class="card-body">
                <h6>Denda Keterlambatan </h6>
                    <p class="small mb-3">
                        <strong>1% dari harga alat × hari terlambat × jumlah unit</strong><br>
                        <span class="text-muted">
                            Contoh: Harga Rp 1.000.000, terlambat 5 hari, 2 unit<br>
                            = 1% × Rp 1.000.000 × 5 × 2 = <strong>Rp 100.000</strong>
                        </span>
                    </p>

                <h6>Denda Kerusakan</h6>
                <ul class="small text-muted mb-0">
                    <li>Rusak Ringan: Rp 50.000 per unit</li>
                    <li>Rusak Berat: Rp 200.000 per unit</li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
const tglRencana = new Date('{{ $peminjaman->tanggal_kembali_rencana }}');
const HARGA_ALAT = {{ $peminjaman->alat->harga }};  
const PERSEN_DENDA = 0.01; // 1%                    
const DENDA_RUSAK_RINGAN = 50000;
const DENDA_RUSAK_BERAT = 200000;

function hitungDenda() {
    const tglKembali = new Date(document.getElementById('tanggal_pengembalian').value);
    const kondisi = document.getElementById('kondisi_alat').value;
    const jumlah = parseInt(document.getElementById('jumlah_dikembalikan').value) || 1;

    // Hitung keterlambatan
    const diffTime = tglKembali - tglRencana;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const hariTerlambat = diffDays > 0 ? diffDays : 0;

    // Denda keterlambatan
    const dendaTerlambat = HARGA_ALAT * PERSEN_DENDA * hariTerlambat * jumlah;

    // Denda kerusakan
    let dendaKerusakan = 0;
    if (kondisi === 'rusak_ringan') dendaKerusakan = DENDA_RUSAK_RINGAN * jumlah;
    if (kondisi === 'rusak_berat') dendaKerusakan = DENDA_RUSAK_BERAT * jumlah;

    // Total denda
    const totalDenda = dendaTerlambat + dendaKerusakan;

    // Tampilkan info
    let infoHTML = '';

    if (hariTerlambat > 0) {
        infoHTML += `<p class="mb-1"><strong>Keterlambatan:</strong><br>
            1% × Rp ${HARGA_ALAT.toLocaleString('id-ID')} × ${hariTerlambat} hari × ${jumlah} unit<br>
            = <strong>Rp ${dendaTerlambat.toLocaleString('id-ID')}</strong></p>`;
    } else {
        infoHTML += `<p class="mb-1"><strong>Keterlambatan:</strong> <span class="text-success">Tidak ada (Tepat waktu ✓)</span></p>`;
    }

    if (dendaKerusakan > 0) {
        const jenisKerusakan = kondisi === 'rusak_ringan' ? 'Rusak Ringan' : 'Rusak Berat';
        infoHTML += `<p class="mb-1"><strong>Kerusakan (${jenisKerusakan}):</strong> ${jumlah} unit × Rp ${dendaKerusakan/ jumlah} = Rp ${dendaKerusakan.toLocaleString('id-ID')}</p>`;
    }

    infoHTML += `<hr><h5 class="mb-0 ${totalDenda > 0 ? 'text-danger' : 'text-success'}">Total Denda: Rp ${totalDenda.toLocaleString('id-ID')}</h5>`;

    document.getElementById('dendaInfo').innerHTML = infoHTML;
}

// Hitung denda saat halaman load
window.addEventListener('load', hitungDenda);
</script>
@endpush