@extends('layouts.app')

@section('title', 'Detail Peminjaman')
@section('page-title', 'Detail Peminjaman')

@section('content')
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Detail Peminjaman #{{ $peminjaman->kode_peminjaman }}</h5>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="text-muted">Kode Peminjaman</h6>
                        <p class="mb-0 fw-bold">{{ $peminjaman->kode_peminjaman }}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Status</h6>
                        @php
                            $badgeClass = match($peminjaman->status) {
                                'menunggu' => 'bg-warning text-dark',
                                'disetujui' => 'bg-success',
                                'ditolak' => 'bg-danger',
                                'dipinjam' => 'bg-info',
                                'dikembalikan' => 'bg-secondary',
                                default => 'bg-secondary'
                            };
                        @endphp
                        <span class="badge {{ $badgeClass }} fs-6">{{ ucfirst($peminjaman->status) }}</span>
                    </div>
                </div>

                <hr>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6 class="text-muted">Peminjam</h6>
                        <p class="mb-0">{{ $peminjaman->user->name ?? '-' }}</p>
                        <small class="text-muted">{{ $peminjaman->user->email ?? '-' }}</small>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted">Alat</h6>
                        <p class="mb-0">{{ $peminjaman->alat->nama_alat ?? '-' }}</p>
                        <small class="text-muted">{{ $peminjaman->alat->kode_alat ?? '-' }}</small>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <h6 class="text-muted">Jumlah Pinjam</h6>
                        <p class="mb-0">{{ $peminjaman->jumlah_pinjam }} unit</p>
                    </div>
                    <div class="col-md-4">
                        <h6 class="text-muted">Tanggal Pinjam</h6>
                        <p class="mb-0">{{ date('d/m/Y', strtotime($peminjaman->tanggal_pinjam)) }}</p>
                    </div>
                    <div class="col-md-4">
                        <h6 class="text-muted">Tanggal Kembali (Rencana)</h6>
                        <p class="mb-0">{{ date('d/m/Y', strtotime($peminjaman->tanggal_kembali_rencana)) }}</p>
                    </div>
                </div>

                @if($peminjaman->tanggal_kembali_aktual)
                    <div class="mb-3">
                        <h6 class="text-muted">Tanggal Kembali (Aktual)</h6>
                        <p class="mb-0">{{ date('d/m/Y', strtotime($peminjaman->tanggal_kembali_aktual)) }}</p>
                    </div>
                @endif

                <div class="mb-3">
                    <h6 class="text-muted">Keperluan</h6>
                    <p class="mb-0">{{ $peminjaman->keperluan }}</p>
                </div>

                @if($peminjaman->catatan_petugas)
                    <div class="mb-3">
                        <h6 class="text-muted">Catatan Petugas</h6>
                        <p class="mb-0">{{ $peminjaman->catatan_petugas }}</p>
                    </div>
                @endif

                @if($peminjaman->disetujui_oleh)
                    <div class="mb-3">
                        <h6 class="text-muted">Disetujui Oleh</h6>
                        <p class="mb-0">{{ $peminjaman->petugas->name ?? '-' }}</p>
                    </div>
                @endif

                <hr>

                <div class="d-flex gap-2">
                    <a href="{{ route('peminjam.peminjaman.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        @if($peminjaman->alat)
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Informasi Alat</h6>
                </div>
                <div class="card-body">
                    @if($peminjaman->alat->foto)
                        <img src="{{ asset('storage/' . $peminjaman->alat->foto) }}" class="img-fluid rounded mb-3" alt="{{ $peminjaman->alat->nama_alat }}">
                    @endif
                    <h6>{{ $peminjaman->alat->nama_alat }}</h6>
                    <p class="text-muted small mb-2">{{ $peminjaman->alat->kode_alat }}</p>
                    @if($peminjaman->alat->spesifikasi)
                        <p class="small mb-0">{{ $peminjaman->alat->spesifikasi }}</p>
                    @endif
                </div>
            </div>
        @endif
    </div>
</div>
@endsection