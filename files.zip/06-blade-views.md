# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 6: Blade Template dan Views

### 📚 Apa itu Blade?

Blade adalah template engine bawaan Laravel. Blade membuat HTML lebih dinamis dan mudah ditulis.

#### 🎯 Perbedaan dengan HTML Biasa

**HTML Biasa (PHP):**
```php
<?php if ($user->isAdmin()): ?>
    <h1>Welcome Admin</h1>
<?php endif; ?>

<?php foreach ($items as $item): ?>
    <p><?= $item->name ?></p>
<?php endforeach; ?>
```

**Blade:**
```blade
@if($user->isAdmin())
    <h1>Welcome Admin</h1>
@endif

@foreach($items as $item)
    <p>{{ $item->name }}</p>
@endforeach
```

Lebih bersih, lebih mudah dibaca!

---

### 📁 Struktur File View

View disimpan di folder `resources/views/`:

```
resources/views/
├── layouts/
│   ├── app.blade.php       # Layout utama
│   ├── guest.blade.php     # Layout untuk guest
│   └── navigation.blade.php
├── components/             # Reusable components
│   ├── alert.blade.php
│   └── button.blade.php
├── kategori/
│   ├── index.blade.php
│   ├── create.blade.php
│   ├── edit.blade.php
│   └── show.blade.php
├── alat/
│   ├── index.blade.php
│   └── ...
└── dashboard.blade.php
```

**Konvensi Penamaan:**
- File view: `namaview.blade.php`
- Sub-folder sesuai resource: `kategori/index.blade.php`
- Panggil di controller: `return view('kategori.index')`

---

### 🎨 Blade Syntax Dasar

#### 1. Echo (Tampilkan Data)

```blade
{{-- Echo dengan HTML escaping (aman dari XSS) --}}
{{ $name }}
{{ $user->email }}
{{ $alat->nama_alat }}

{{-- Echo tanpa escaping (untuk HTML) --}}
{!! $htmlContent !!}

{{-- Echo dengan default value --}}
{{ $name ?? 'Guest' }}
{{ $user->phone ?? 'No Phone' }}
```

#### 2. Control Structures

```blade
{{-- IF ELSE --}}
@if($user->isAdmin())
    <p>Anda adalah Admin</p>
@elseif($user->isPetugas())
    <p>Anda adalah Petugas</p>
@else
    <p>Anda adalah Peminjam</p>
@endif

{{-- UNLESS (kebalikan if) --}}
@unless($user->isAdmin())
    <p>Anda bukan admin</p>
@endunless

{{-- ISSET --}}
@isset($alat->foto)
    <img src="{{ asset('storage/'.$alat->foto) }}">
@endisset

{{-- EMPTY --}}
@empty($items)
    <p>Tidak ada data</p>
@endempty

{{-- AUTH --}}
@auth
    <p>Anda sudah login</p>
@endauth

@guest
    <p>Silakan login</p>
@endguest
```

#### 3. Loops

```blade
{{-- FOR LOOP --}}
@for($i = 0; $i < 10; $i++)
    <p>Item {{ $i }}</p>
@endfor

{{-- FOREACH --}}
@foreach($items as $item)
    <p>{{ $item->name }}</p>
@endforeach

{{-- FORELSE (foreach dengan handling empty) --}}
@forelse($items as $item)
    <p>{{ $item->name }}</p>
@empty
    <p>Tidak ada data</p>
@endforelse

{{-- WHILE --}}
@while($condition)
    <p>Loop</p>
@endwhile

{{-- Loop Variable --}}
@foreach($items as $item)
    <p>
        Index: {{ $loop->index }}      {{-- 0, 1, 2... --}}
        Iteration: {{ $loop->iteration }} {{-- 1, 2, 3... --}}
        
        @if($loop->first)
            <span>First Item</span>
        @endif
        
        @if($loop->last)
            <span>Last Item</span>
        @endif
        
        Total: {{ $loop->count }}
    </p>
@endforeach
```

#### 4. Switch Case

```blade
@switch($status)
    @case('menunggu')
        <span class="badge badge-warning">Menunggu</span>
        @break
    
    @case('disetujui')
        <span class="badge badge-success">Disetujui</span>
        @break
    
    @case('ditolak')
        <span class="badge badge-danger">Ditolak</span>
        @break
    
    @default
        <span class="badge badge-secondary">{{ $status }}</span>
@endswitch
```

---

### 🏗️ Layout dan Inheritance

#### 1. Buat Layout Utama

File: `resources/views/layouts/app.blade.php`

```blade
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Sistem Peminjaman Alat')</title>
    
    {{-- CSS --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    @stack('styles')
</head>
<body>
    {{-- Navigation --}}
    @include('layouts.navigation')
    
    {{-- Alert Messages --}}
    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    
    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    
    {{-- Main Content --}}
    <main class="container mt-4">
        @yield('content')
    </main>
    
    {{-- Footer --}}
    <footer class="mt-5 py-3 bg-light">
        <div class="container text-center">
            <p>&copy; 2026 Sistem Peminjaman Alat</p>
        </div>
    </footer>
    
    {{-- JS --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
```

#### 2. Extend Layout di View

File: `resources/views/kategori/index.blade.php`

```blade
@extends('layouts.app')

@section('title', 'Daftar Kategori')

@push('styles')
<style>
    .kategori-card { 
        transition: all 0.3s; 
    }
    .kategori-card:hover { 
        transform: translateY(-5px); 
    }
</style>
@endpush

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1>Daftar Kategori</h1>
            <a href="{{ route('kategori.create') }}" class="btn btn-primary">
                Tambah Kategori
            </a>
        </div>
        
        <div class="card">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <th>Jumlah Alat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($kategoris as $kategori)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $kategori->nama_kategori }}</td>
                                <td>{{ $kategori->deskripsi ?? '-' }}</td>
                                <td>{{ $kategori->alat_count ?? 0 }}</td>
                                <td>
                                    <a href="{{ route('kategori.show', $kategori) }}" 
                                       class="btn btn-sm btn-info">
                                        Detail
                                    </a>
                                    <a href="{{ route('kategori.edit', $kategori) }}" 
                                       class="btn btn-sm btn-warning">
                                        Edit
                                    </a>
                                    <form action="{{ route('kategori.destroy', $kategori) }}" 
                                          method="POST" 
                                          class="d-inline"
                                          onsubmit="return confirm('Yakin ingin menghapus?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center">
                                    Tidak ada data kategori
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
                
                {{-- Pagination --}}
                {{ $kategoris->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    console.log('Kategori page loaded');
</script>
@endpush
```

**Penjelasan:**

- `@extends('layouts.app')`: Gunakan layout app
- `@section('title')`: Isi section title
- `@section('content')`: Isi section content
- `@push('styles')`: Tambahkan CSS khusus page ini
- `@push('scripts')`: Tambahkan JS khusus page ini

---

### 🎁 Components

Components adalah bagian view yang bisa digunakan berkali-kali.

#### 1. Buat Component Alert

File: `resources/views/components/alert.blade.php`

```blade
@props(['type' => 'info', 'message'])

<div class="alert alert-{{ $type }} alert-dismissible fade show" role="alert">
    {{ $message }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
```

**Cara Pakai:**

```blade
<x-alert type="success" message="Data berhasil disimpan!" />
<x-alert type="danger" message="Terjadi kesalahan!" />
```

#### 2. Component dengan Slot

File: `resources/views/components/card.blade.php`

```blade
@props(['title'])

<div class="card">
    <div class="card-header">
        <h5>{{ $title }}</h5>
    </div>
    <div class="card-body">
        {{ $slot }}
    </div>
</div>
```

**Cara Pakai:**

```blade
<x-card title="Informasi Alat">
    <p>Nama: {{ $alat->nama_alat }}</p>
    <p>Kode: {{ $alat->kode_alat }}</p>
</x-card>
```

---

### 📝 Forms

#### Form Tambah Kategori

File: `resources/views/kategori/create.blade.php`

```blade
@extends('layouts.app')

@section('title', 'Tambah Kategori')

@section('content')
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5>Tambah Kategori Baru</h5>
            </div>
            <div class="card-body">
                <form action="{{ route('kategori.store') }}" method="POST">
                    @csrf
                    
                    <div class="mb-3">
                        <label for="nama_kategori" class="form-label">
                            Nama Kategori <span class="text-danger">*</span>
                        </label>
                        <input type="text" 
                               class="form-control @error('nama_kategori') is-invalid @enderror" 
                               id="nama_kategori" 
                               name="nama_kategori" 
                               value="{{ old('nama_kategori') }}"
                               required>
                        @error('nama_kategori')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    
                    <div class="mb-3">
                        <label for="deskripsi" class="form-label">Deskripsi</label>
                        <textarea class="form-control @error('deskripsi') is-invalid @enderror" 
                                  id="deskripsi" 
                                  name="deskripsi" 
                                  rows="3">{{ old('deskripsi') }}</textarea>
                        @error('deskripsi')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="{{ route('kategori.index') }}" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
```

**Penjelasan Form:**

- `@csrf`: Token CSRF untuk keamanan (wajib ada!)
- `@error('field')`: Tampilkan error untuk field tertentu
- `old('field')`: Ambil input lama (saat validasi gagal)
- `is-invalid`: Class Bootstrap untuk error state

#### Form Edit

```blade
<form action="{{ route('kategori.update', $kategori) }}" method="POST">
    @csrf
    @method('PUT')
    
    <div class="mb-3">
        <label for="nama_kategori" class="form-label">Nama Kategori</label>
        <input type="text" 
               class="form-control @error('nama_kategori') is-invalid @enderror" 
               id="nama_kategori" 
               name="nama_kategori" 
               value="{{ old('nama_kategori', $kategori->nama_kategori) }}">
        @error('nama_kategori')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    
    {{-- Field lainnya... --}}
    
    <button type="submit" class="btn btn-primary">Update</button>
</form>
```

**Catatan:**
- `old('field', $default)`: Gunakan old input jika ada, kalau tidak pakai default
- `@method('PUT')`: Spoofing method untuk PUT (karena form HTML hanya support GET/POST)

---

### 🔗 Helper Functions

Laravel punya banyak helper untuk View:

```blade
{{-- URL & Route --}}
{{ url('/home') }}
{{ route('kategori.index') }}
{{ route('kategori.show', $kategori) }}
{{ route('kategori.edit', ['kategori' => $kategori->id]) }}

{{-- Asset --}}
{{ asset('css/app.css') }}
{{ asset('storage/alat/foto.jpg') }}

{{-- Mix (untuk compiled assets) --}}
{{ mix('css/app.css') }}
{{ mix('js/app.js') }}

{{-- Auth --}}
{{ auth()->user()->name }}
{{ auth()->id() }}
{{ auth()->check() ? 'Logged In' : 'Guest' }}

{{-- Session --}}
{{ session('success') }}

{{-- Config --}}
{{ config('app.name') }}

{{-- Trans (untuk multi-language) --}}
{{ __('Welcome') }}
{{ trans('messages.welcome') }}

{{-- Date Format --}}
{{ $kategori->created_at->format('d F Y') }}
{{ $kategori->created_at->diffForHumans() }} {{-- 2 days ago --}}

{{-- Number Format --}}
{{ number_format($alat->jumlah_total) }}
{{ number_format($denda, 0, ',', '.') }}

{{-- Str Helper --}}
{{ Str::limit($text, 100) }}
{{ Str::upper($text) }}
{{ Str::slug($title) }}
```

---

### 💡 Tips Blade

#### 1. Blade Directives

```blade
{{-- Include File --}}
@include('partials.header')
@include('partials.sidebar', ['active' => 'kategori'])

{{-- Include If Exists --}}
@includeIf('partials.header')
@includeWhen($showHeader, 'partials.header')

{{-- JSON --}}
@json($array)  {{-- Convert array to JSON --}}

{{-- Verbatim (skip blade processing) --}}
@verbatim
    <div>{{ This will not be processed by Blade }}</div>
@endverbatim

{{-- PHP Code --}}
@php
    $total = $items->count();
    $average = $items->avg('price');
@endphp

{{-- Once (execute only once) --}}
@once
    <script>
        console.log('This will be executed only once');
    </script>
@endonce
```

#### 2. Custom Directives

Bisa buat directive sendiri di `AppServiceProvider`:

```php
// app/Providers/AppServiceProvider.php
use Illuminate\Support\Facades\Blade;

public function boot()
{
    // Custom directive untuk role
    Blade::directive('role', function ($role) {
        return "<?php if(auth()->check() && auth()->user()->role === {$role}): ?>";
    });
    
    Blade::directive('endrole', function () {
        return "<?php endif; ?>";
    });
}
```

**Cara Pakai:**

```blade
@role('admin')
    <a href="/admin">Admin Panel</a>
@endrole
```

---

### 📝 Latihan

Buat halaman:

1. **List Alat** dengan:
   - Card untuk setiap alat
   - Foto alat (atau placeholder)
   - Badge untuk kondisi
   - Button detail/edit/hapus

2. **Detail Alat** dengan:
   - Informasi lengkap
   - Foto besar
   - Daftar peminjaman (jika ada)

3. **Form Tambah/Edit Alat** dengan:
   - Upload foto dengan preview
   - Select kategori
   - Validation error messages

---

### 🎯 Rangkuman

Di bagian ini Anda sudah belajar:

✅ Blade Template Syntax  
✅ Layouts & Inheritance  
✅ Components & Slots  
✅ Forms dengan CSRF  
✅ Error Handling di Form  
✅ Helper Functions  
✅ Custom Directives  

**Langkah Selanjutnya:**

Di bagian 7 (terakhir), kita akan praktek:
- Membuat fitur peminjaman lengkap
- Approval system
- Dashboard dengan statistik
- Tips deployment

---

*Anda sudah menguasai Blade! Saatnya praktek! 🎨*
