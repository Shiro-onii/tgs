# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 5: Controller dan CRUD Operations

### 📚 Apa itu Controller?

Controller adalah "pelayan" di konsep MVC yang mengatur alur aplikasi. Controller menerima request dari user, memproses data (via Model), dan mengembalikan response (biasanya View).

#### 🎯 Analogi Sederhana

Restoran:
- **User**: "Saya mau nasi goreng"
- **Controller (Pelayan)**: Terima pesanan → Kirim ke dapur → Ambil makanan → Sajikan ke pelanggan
- **Model (Dapur)**: Masak makanan
- **View (Penyajian)**: Tampilan makanan yang cantik

---

### 🔧 Membuat Controller

```bash
# Membuat controller biasa
php artisan make:controller NamaController

# Membuat resource controller (dengan method CRUD lengkap)
php artisan make:controller NamaController --resource

# Membuat controller + model
php artisan make:controller NamaController --model=NamaModel

# Membuat controller untuk API
php artisan make:controller Api/NamaController --api
```

**Resource Controller** otomatis membuat 7 method:
1. `index()` - Tampilkan daftar
2. `create()` - Form tambah data
3. `store()` - Simpan data baru
4. `show($id)` - Tampilkan detail
5. `edit($id)` - Form edit data
6. `update($id)` - Update data
7. `destroy($id)` - Hapus data

---

### 📝 CRUD untuk Kategori

Mari kita buat CRUD lengkap untuk Kategori step by step!

#### 1. Buat Controller

```bash
php artisan make:controller KategoriController --resource
```

Edit file `app/Http/Controllers/KategoriController.php`:

```php
<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Ambil semua data kategori dengan pagination
        $kategoris = Kategori::latest()->paginate(10);
        
        return view('kategori.index', compact('kategoris'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('kategori.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi input
        $validated = $request->validate([
            'nama_kategori' => 'required|string|max:100|unique:kategori,nama_kategori',
            'deskripsi' => 'nullable|string',
        ], [
            'nama_kategori.required' => 'Nama kategori wajib diisi',
            'nama_kategori.unique' => 'Nama kategori sudah ada',
        ]);

        // Simpan data
        Kategori::create($validated);

        // Redirect dengan pesan sukses
        return redirect()->route('kategori.index')
            ->with('success', 'Kategori berhasil ditambahkan');
    }

    /**
     * Display the specified resource.
     */
    public function show(Kategori $kategori)
    {
        // Load relasi alat
        $kategori->load('alat');
        
        return view('kategori.show', compact('kategori'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Kategori $kategori)
    {
        return view('kategori.edit', compact('kategori'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Kategori $kategori)
    {
        // Validasi input
        $validated = $request->validate([
            'nama_kategori' => 'required|string|max:100|unique:kategori,nama_kategori,'.$kategori->id,
            'deskripsi' => 'nullable|string',
        ]);

        // Update data
        $kategori->update($validated);

        // Redirect dengan pesan sukses
        return redirect()->route('kategori.index')
            ->with('success', 'Kategori berhasil diupdate');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Kategori $kategori)
    {
        try {
            $kategori->delete();
            
            return redirect()->route('kategori.index')
                ->with('success', 'Kategori berhasil dihapus');
        } catch (\Exception $e) {
            return redirect()->route('kategori.index')
                ->with('error', 'Kategori tidak bisa dihapus karena masih ada alat yang menggunakan kategori ini');
        }
    }
}
```

**Penjelasan Kode:**

1. **Route Model Binding**: `Kategori $kategori`
   - Laravel otomatis cari kategori berdasarkan ID di URL
   - Jika tidak ketemu, otomatis 404

2. **Validation**: `$request->validate(...)`
   - `required`: Wajib diisi
   - `string`: Harus teks
   - `max:100`: Maksimal 100 karakter
   - `unique:kategori,nama_kategori`: Harus unik di tabel kategori
   - `nullable`: Boleh kosong

3. **Flash Message**: `->with('success', '...')`
   - Pesan sementara yang muncul 1x setelah redirect
   - Bisa `success`, `error`, `warning`, `info`

4. **compact()**: Shorthand untuk `['kategoris' => $kategoris]`

#### 2. Buat Routes

Edit file `routes/web.php`:

```php
<?php

use App\Http\Controllers\KategoriController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // CRUD Kategori - hanya admin
    Route::middleware('role:admin')->group(function () {
        Route::resource('kategori', KategoriController::class);
    });
});

require __DIR__.'/auth.php';
```

**Resource Route** otomatis membuat 7 route:

| Method | URI | Action | Route Name |
|--------|-----|--------|------------|
| GET | /kategori | index | kategori.index |
| GET | /kategori/create | create | kategori.create |
| POST | /kategori | store | kategori.store |
| GET | /kategori/{id} | show | kategori.show |
| GET | /kategori/{id}/edit | edit | kategori.edit |
| PUT/PATCH | /kategori/{id} | update | kategori.update |
| DELETE | /kategori/{id} | destroy | kategori.destroy |

Cek route yang sudah dibuat:
```bash
php artisan route:list
```

---

### 🎨 Request Validation

Laravel punya banyak validation rules:

```php
$request->validate([
    // Required
    'name' => 'required',
    
    // String & Max Length
    'name' => 'required|string|max:255',
    
    // Email
    'email' => 'required|email|unique:users,email',
    
    // Numeric
    'age' => 'required|numeric|min:17|max:100',
    
    // Integer
    'quantity' => 'required|integer|between:1,100',
    
    // Date
    'birth_date' => 'required|date|before:today',
    'start_date' => 'required|date|after_or_equal:today',
    
    // File Upload
    'photo' => 'required|image|mimes:jpeg,png,jpg|max:2048', // max 2MB
    'document' => 'required|mimes:pdf,doc,docx|max:10240', // max 10MB
    
    // In (pilihan tertentu)
    'role' => 'required|in:admin,petugas,peminjam',
    
    // Confirmed (password confirmation)
    'password' => 'required|confirmed|min:8',
    
    // Unique (cek di database)
    'email' => 'required|unique:users,email',
    'email' => 'required|unique:users,email,'.$id, // kecuali ID ini (untuk update)
    
    // Exists (harus ada di database)
    'kategori_id' => 'required|exists:kategori,id',
    
    // Regex
    'phone' => 'required|regex:/^[0-9]{10,15}$/',
    
    // Array
    'items' => 'required|array|min:1',
    'items.*' => 'required|string',
    
    // Boolean
    'is_active' => 'required|boolean',
    
    // Nullable (boleh kosong)
    'description' => 'nullable|string|max:1000',
]);
```

**Custom Error Messages:**

```php
$request->validate([
    'nama_kategori' => 'required|unique:kategori',
], [
    'nama_kategori.required' => 'Nama kategori wajib diisi',
    'nama_kategori.unique' => 'Nama kategori sudah digunakan',
]);
```

---

### 📤 Response Types

Controller bisa return berbagai tipe response:

```php
// 1. View
return view('kategori.index', compact('kategoris'));

// 2. Redirect
return redirect()->route('kategori.index');
return redirect()->back(); // kembali ke halaman sebelumnya
return redirect('/home');

// 3. Redirect dengan Flash Message
return redirect()->route('kategori.index')
    ->with('success', 'Data berhasil disimpan');

// 4. Redirect dengan Input (untuk form error)
return redirect()->back()->withInput();

// 5. JSON (untuk API)
return response()->json([
    'success' => true,
    'data' => $kategori,
]);

// 6. Download File
return response()->download($pathToFile);

// 7. File (untuk display file)
return response()->file($pathToFile);

// 8. String/HTML
return '<h1>Hello World</h1>';

// 9. Array/Object (otomatis jadi JSON)
return $kategori; // otomatis jadi JSON
```

---

### 🔄 CRUD Pattern

Berikut pattern CRUD yang konsisten:

#### CREATE

```php
// 1. Form (GET)
public function create()
{
    return view('resource.create');
}

// 2. Store (POST)
public function store(Request $request)
{
    // Validate
    $validated = $request->validate([...]);
    
    // Create
    Model::create($validated);
    
    // Redirect
    return redirect()->route('resource.index')
        ->with('success', 'Data berhasil ditambahkan');
}
```

#### READ

```php
// List (GET)
public function index()
{
    $items = Model::latest()->paginate(10);
    return view('resource.index', compact('items'));
}

// Detail (GET)
public function show(Model $item)
{
    return view('resource.show', compact('item'));
}
```

#### UPDATE

```php
// 1. Form (GET)
public function edit(Model $item)
{
    return view('resource.edit', compact('item'));
}

// 2. Update (PUT/PATCH)
public function update(Request $request, Model $item)
{
    // Validate
    $validated = $request->validate([...]);
    
    // Update
    $item->update($validated);
    
    // Redirect
    return redirect()->route('resource.index')
        ->with('success', 'Data berhasil diupdate');
}
```

#### DELETE

```php
public function destroy(Model $item)
{
    try {
        $item->delete();
        
        return redirect()->route('resource.index')
            ->with('success', 'Data berhasil dihapus');
    } catch (\Exception $e) {
        return redirect()->route('resource.index')
            ->with('error', 'Data tidak bisa dihapus');
    }
}
```

---

### 📂 Upload File

Contoh upload foto untuk alat:

```php
public function store(Request $request)
{
    $validated = $request->validate([
        'nama_alat' => 'required|string|max:200',
        'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        // ... validasi lain
    ]);

    // Handle file upload
    if ($request->hasFile('foto')) {
        // Store di storage/app/public/alat
        $path = $request->file('foto')->store('alat', 'public');
        $validated['foto'] = $path;
    }

    Alat::create($validated);

    return redirect()->route('alat.index')
        ->with('success', 'Alat berhasil ditambahkan');
}

public function update(Request $request, Alat $alat)
{
    $validated = $request->validate([
        'nama_alat' => 'required|string|max:200',
        'foto' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    ]);

    // Handle file upload
    if ($request->hasFile('foto')) {
        // Hapus foto lama jika ada
        if ($alat->foto) {
            Storage::disk('public')->delete($alat->foto);
        }
        
        // Upload foto baru
        $path = $request->file('foto')->store('alat', 'public');
        $validated['foto'] = $path;
    }

    $alat->update($validated);

    return redirect()->route('alat.index')
        ->with('success', 'Alat berhasil diupdate');
}
```

**Setup Storage Link:**

```bash
# Buat symbolic link dari public/storage ke storage/app/public
php artisan storage:link
```

Sekarang file bisa diakses via URL:
- File disimpan di: `storage/app/public/alat/foto.jpg`
- Bisa diakses via: `http://localhost:8000/storage/alat/foto.jpg`

**Di Blade Template:**

```html
@if($alat->foto)
    <img src="{{ asset('storage/' . $alat->foto) }}" alt="{{ $alat->nama_alat }}">
@else
    <img src="{{ asset('images/no-image.png') }}" alt="No Image">
@endif
```

---

### 🔍 Search & Filter

Contoh implementasi search:

```php
public function index(Request $request)
{
    $query = Alat::query();

    // Search
    if ($request->has('search')) {
        $search = $request->search;
        $query->where(function($q) use ($search) {
            $q->where('nama_alat', 'LIKE', "%{$search}%")
              ->orWhere('kode_alat', 'LIKE', "%{$search}%");
        });
    }

    // Filter by kategori
    if ($request->has('kategori_id')) {
        $query->where('kategori_id', $request->kategori_id);
    }

    // Filter by kondisi
    if ($request->has('kondisi')) {
        $query->where('kondisi', $request->kondisi);
    }

    // Filter tersedia
    if ($request->has('tersedia') && $request->tersedia == '1') {
        $query->where('jumlah_tersedia', '>', 0);
    }

    // Get results
    $alats = $query->with('kategori')->latest()->paginate(10);
    
    // Get kategori untuk dropdown filter
    $kategoris = Kategori::all();

    return view('alat.index', compact('alats', 'kategoris'));
}
```

**Di View:**

```html
<form method="GET" action="{{ route('alat.index') }}">
    <input type="text" name="search" placeholder="Cari alat..." value="{{ request('search') }}">
    
    <select name="kategori_id">
        <option value="">Semua Kategori</option>
        @foreach($kategoris as $kategori)
            <option value="{{ $kategori->id }}" {{ request('kategori_id') == $kategori->id ? 'selected' : '' }}>
                {{ $kategori->nama_kategori }}
            </option>
        @endforeach
    </select>
    
    <button type="submit">Filter</button>
</form>
```

---

### 📝 Latihan

Buat CRUD untuk Alat dengan fitur:

1. **List Alat** dengan:
   - Search by nama/kode
   - Filter by kategori
   - Filter by kondisi
   - Pagination

2. **Create Alat** dengan:
   - Upload foto
   - Dropdown kategori

3. **Edit Alat** dengan:
   - Update foto (hapus foto lama)

4. **Delete Alat** dengan:
   - Konfirmasi delete
   - Hapus foto jika ada

**Hint: Controller Structure**

```php
class AlatController extends Controller
{
    public function index(Request $request)
    {
        // Search & Filter logic
        // Return view
    }

    public function create()
    {
        $kategoris = Kategori::all();
        return view('alat.create', compact('kategoris'));
    }

    public function store(Request $request)
    {
        // Validate (including foto)
        // Upload foto if exists
        // Create alat
        // Redirect
    }

    public function show(Alat $alat)
    {
        return view('alat.show', compact('alat'));
    }

    public function edit(Alat $alat)
    {
        $kategoris = Kategori::all();
        return view('alat.edit', compact('alat', 'kategoris'));
    }

    public function update(Request $request, Alat $alat)
    {
        // Validate
        // Delete old foto if new foto uploaded
        // Upload new foto
        // Update alat
        // Redirect
    }

    public function destroy(Alat $alat)
    {
        // Delete foto
        // Delete alat
        // Redirect
    }
}
```

---

### 🎯 Rangkuman

Di bagian ini Anda sudah belajar:

✅ Konsep Controller  
✅ Resource Controller (7 method CRUD)  
✅ Request Validation  
✅ Response Types  
✅ CRUD Pattern  
✅ Upload File  
✅ Search & Filter  
✅ Flash Messages  

**Langkah Selanjutnya:**

Di bagian 6, kita akan belajar:
- Blade Template Engine
- Layouts & Components
- Menampilkan data di View
- Forms & CSRF Protection

---

*Sekarang Anda bisa membuat CRUD lengkap! 💪*
