# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 2: Konsep MVC dan Database Design

### 📚 Konsep MVC (Model-View-Controller)

MVC adalah pola desain yang memisahkan aplikasi menjadi 3 bagian:

#### 🎯 Analogi Restoran

Bayangkan Anda di restoran:

1. **Model (Dapur & Gudang)**
   - Menyimpan bahan makanan
   - Mengolah bahan menjadi makanan
   - *Di Laravel:* Berinteraksi dengan database

2. **View (Menu & Penyajian)**
   - Menampilkan menu kepada pelanggan
   - Menyajikan makanan dengan cantik
   - *Di Laravel:* File HTML/Blade yang dilihat user

3. **Controller (Pelayan)**
   - Menerima pesanan dari pelanggan
   - Menyampaikan pesanan ke dapur
   - Mengambil makanan dari dapur
   - Menyajikan ke pelanggan
   - *Di Laravel:* Mengatur alur aplikasi

**Alur Kerja MVC di Laravel:**

```
User Request (http://localhost/alat)
         ↓
    Route (web.php)
         ↓
    Controller
         ↓
    Model → Database
         ↓
    Controller
         ↓
    View (Blade)
         ↓
    Response ke User
```

---

### 🗄️ Database Design

Mari kita rancang database untuk aplikasi peminjaman alat.

#### Tabel-tabel yang Dibutuhkan:

**1. users** (Tabel Pengguna)
```
- id (Primary Key)
- name (Nama lengkap)
- email (Email - unique)
- password (Password terenkripsi)
- role (admin/petugas/peminjam)
- phone (Nomor telepon)
- address (Alamat)
- created_at
- updated_at
```

**2. kategori** (Kategori Alat)
```
- id (Primary Key)
- nama_kategori
- deskripsi
- created_at
- updated_at
```

**3. alat** (Daftar Alat)
```
- id (Primary Key)
- kode_alat (Kode unik - unique)
- nama_alat
- kategori_id (Foreign Key → kategori.id)
- merk
- kondisi (baik/rusak_ringan/rusak_berat)
- jumlah_total
- jumlah_tersedia
- foto (Path ke file gambar)
- spesifikasi
- created_at
- updated_at
```

**4. peminjaman** (Transaksi Peminjaman)
```
- id (Primary Key)
- kode_peminjaman (Kode unik)
- user_id (Foreign Key → users.id) - Peminjam
- alat_id (Foreign Key → alat.id)
- jumlah_pinjam
- tanggal_pinjam
- tanggal_kembali_rencana
- tanggal_kembali_aktual
- keperluan
- status (menunggu/disetujui/ditolak/dipinjam/dikembalikan)
- catatan_petugas
- disetujui_oleh (Foreign Key → users.id) - Petugas
- created_at
- updated_at
```

**5. pengembalian** (Data Pengembalian)
```
- id (Primary Key)
- peminjaman_id (Foreign Key → peminjaman.id)
- tanggal_pengembalian
- kondisi_alat (baik/rusak_ringan/rusak_berat)
- jumlah_dikembalikan
- denda
- keterangan
- diterima_oleh (Foreign Key → users.id) - Petugas
- created_at
- updated_at
```

**6. activity_logs** (Log Aktivitas)
```
- id (Primary Key)
- user_id (Foreign Key → users.id)
- activity (Login/Logout/Create/Update/Delete/dll)
- description (Deskripsi aktivitas)
- ip_address
- user_agent
- created_at
- updated_at
```

---

### 📊 Relasi Antar Tabel

**1. users → peminjaman** (One to Many)
- Satu user bisa memiliki banyak peminjaman
- Satu peminjaman milik satu user

**2. kategori → alat** (One to Many)
- Satu kategori bisa memiliki banyak alat
- Satu alat milik satu kategori

**3. alat → peminjaman** (One to Many)
- Satu alat bisa dipinjam berkali-kali
- Satu peminjaman untuk satu alat

**4. peminjaman → pengembalian** (One to One)
- Satu peminjaman hanya punya satu pengembalian
- Satu pengembalian untuk satu peminjaman

**5. users → activity_logs** (One to Many)
- Satu user bisa punya banyak log aktivitas
- Satu log milik satu user

---

### 🔧 Migration di Laravel

Migration adalah cara membuat dan mengubah struktur database menggunakan kode PHP.

#### Keuntungan Migration:

1. **Version Control untuk Database**: Database bisa di-track seperti kode
2. **Mudah di-share**: Tim bisa punya struktur database yang sama
3. **Mudah rollback**: Bisa kembali ke versi sebelumnya
4. **Otomatis**: Tidak perlu buat tabel manual di phpMyAdmin

#### Perintah Artisan untuk Migration:

```bash
# Membuat migration baru
php artisan make:migration create_nama_tabel_table

# Menjalankan migration (membuat tabel)
php artisan migrate

# Rollback migration terakhir
php artisan migrate:rollback

# Rollback semua migration
php artisan migrate:reset

# Rollback semua, lalu migrate ulang
php artisan migrate:refresh

# Drop semua tabel, lalu migrate ulang
php artisan migrate:fresh

# Lihat status migration
php artisan migrate:status
```

---

### 📝 Membuat Migration untuk Aplikasi

Mari kita buat migration untuk semua tabel!

#### 1. Migration Tabel Kategori

```bash
php artisan make:migration create_kategori_table
```

Edit file migration di `database/migrations/xxxx_xx_xx_create_kategori_table.php`:

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('kategori', function (Blueprint $table) {
            $table->id();
            $table->string('nama_kategori', 100);
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('kategori');
    }
};
```

**Penjelasan Kode:**

- `$table->id()`: Membuat kolom `id` (Primary Key, Auto Increment)
- `$table->string('nama_kategori', 100)`: Kolom VARCHAR(100)
- `$table->text('deskripsi')`: Kolom TEXT
- `->nullable()`: Kolom boleh kosong
- `$table->timestamps()`: Membuat `created_at` dan `updated_at`
- `Schema::dropIfExists()`: Menghapus tabel jika ada (untuk rollback)

#### 2. Migration Tabel Alat

```bash
php artisan make:migration create_alat_table
```

Edit file migration:

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('alat', function (Blueprint $table) {
            $table->id();
            $table->string('kode_alat', 50)->unique();
            $table->string('nama_alat', 200);
            $table->foreignId('kategori_id')->constrained('kategori')->onDelete('cascade');
            $table->string('merk', 100)->nullable();
            $table->enum('kondisi', ['baik', 'rusak_ringan', 'rusak_berat'])->default('baik');
            $table->integer('jumlah_total')->default(0);
            $table->integer('jumlah_tersedia')->default(0);
            $table->string('foto')->nullable();
            $table->text('spesifikasi')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('alat');
    }
};
```

**Penjelasan Kode Baru:**

- `->unique()`: Kolom harus unik (tidak boleh duplikat)
- `$table->foreignId('kategori_id')`: Membuat Foreign Key
- `->constrained('kategori')`: Mereferensi ke tabel kategori
- `->onDelete('cascade')`: Jika kategori dihapus, alat juga terhapus
- `$table->enum()`: Kolom dengan pilihan tertentu
- `->default('baik')`: Nilai default
- `$table->integer()`: Kolom angka

#### 3. Migration Update Tabel Users

Laravel sudah membuat migration untuk users. Kita perlu update:

Edit `database/migrations/0001_01_01_000000_create_users_table.php`:

```php
public function up(): void
{
    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->string('email')->unique();
        $table->timestamp('email_verified_at')->nullable();
        $table->string('password');
        
        // Tambahan kolom untuk aplikasi kita
        $table->enum('role', ['admin', 'petugas', 'peminjam'])->default('peminjam');
        $table->string('phone', 20)->nullable();
        $table->text('address')->nullable();
        
        $table->rememberToken();
        $table->timestamps();
    });

    Schema::create('password_reset_tokens', function (Blueprint $table) {
        $table->string('email')->primary();
        $table->string('token');
        $table->timestamp('created_at')->nullable();
    });

    Schema::create('sessions', function (Blueprint $table) {
        $table->string('id')->primary();
        $table->foreignId('user_id')->nullable()->index();
        $table->string('ip_address', 45)->nullable();
        $table->text('user_agent')->nullable();
        $table->longText('payload');
        $table->integer('last_activity')->index();
    });
}
```

#### 4. Migration Tabel Peminjaman

```bash
php artisan make:migration create_peminjaman_table
```

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('peminjaman', function (Blueprint $table) {
            $table->id();
            $table->string('kode_peminjaman', 50)->unique();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('alat_id')->constrained('alat')->onDelete('cascade');
            $table->integer('jumlah_pinjam');
            $table->date('tanggal_pinjam');
            $table->date('tanggal_kembali_rencana');
            $table->date('tanggal_kembali_aktual')->nullable();
            $table->text('keperluan');
            $table->enum('status', [
                'menunggu', 
                'disetujui', 
                'ditolak', 
                'dipinjam', 
                'dikembalikan'
            ])->default('menunggu');
            $table->text('catatan_petugas')->nullable();
            $table->foreignId('disetujui_oleh')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('peminjaman');
    }
};
```

**Penjelasan Kode Baru:**

- `$table->date()`: Kolom tanggal
- `->onDelete('set null')`: Jika user dihapus, set kolom jadi NULL (tidak delete peminjaman)

#### 5. Migration Tabel Pengembalian

```bash
php artisan make:migration create_pengembalian_table
```

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pengembalian', function (Blueprint $table) {
            $table->id();
            $table->foreignId('peminjaman_id')->constrained('peminjaman')->onDelete('cascade');
            $table->date('tanggal_pengembalian');
            $table->enum('kondisi_alat', ['baik', 'rusak_ringan', 'rusak_berat'])->default('baik');
            $table->integer('jumlah_dikembalikan');
            $table->decimal('denda', 10, 2)->default(0);
            $table->text('keterangan')->nullable();
            $table->foreignId('diterima_oleh')->constrained('users')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pengembalian');
    }
};
```

**Penjelasan Kode Baru:**

- `$table->decimal(10, 2)`: Kolom untuk angka desimal (untuk uang)
  - 10 = total digit
  - 2 = digit di belakang koma
  - Contoh: 12345678.90

#### 6. Migration Tabel Activity Logs

```bash
php artisan make:migration create_activity_logs_table
```

```php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('activity_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users')->onDelete('set null');
            $table->string('activity', 100);
            $table->text('description');
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('activity_logs');
    }
};
```

---

### 🚀 Menjalankan Migration

Setelah semua migration dibuat, jalankan:

```bash
# Jalankan semua migration
php artisan migrate
```

Output yang diharapkan:
```
Migration table created successfully.
Migrating: 0001_01_01_000000_create_users_table
Migrated:  0001_01_01_000000_create_users_table (50.23ms)
Migrating: xxxx_xx_xx_create_kategori_table
Migrated:  xxxx_xx_xx_create_kategori_table (30.15ms)
...
```

**Cek di phpMyAdmin:**
- Buka http://localhost/phpmyadmin
- Pilih database `peminjaman_alat`
- Anda akan melihat semua tabel sudah terbuat!

---

### 🎨 Tipe Data Migration

Berikut referensi tipe data yang sering digunakan:

| Method | Tipe Data MySQL | Keterangan |
|--------|----------------|------------|
| `$table->id()` | BIGINT UNSIGNED | Primary Key |
| `$table->string('name', 100)` | VARCHAR(100) | Teks pendek |
| `$table->text('desc')` | TEXT | Teks panjang |
| `$table->integer('qty')` | INT | Angka bulat |
| `$table->decimal('price', 10, 2)` | DECIMAL(10,2) | Angka desimal |
| `$table->boolean('active')` | TINYINT(1) | True/False |
| `$table->date('tanggal')` | DATE | Tanggal |
| `$table->time('jam')` | TIME | Waktu |
| `$table->dateTime('waktu')` | DATETIME | Tanggal + Waktu |
| `$table->timestamp('created')` | TIMESTAMP | Timestamp |
| `$table->enum('role', [...])` | ENUM | Pilihan tertentu |
| `$table->json('data')` | JSON | Data JSON |
| `$table->foreignId('user_id')` | BIGINT UNSIGNED | Foreign Key |

**Modifiers:**
- `->nullable()`: Boleh kosong
- `->default('value')`: Nilai default
- `->unique()`: Harus unik
- `->unsigned()`: Hanya positif
- `->after('column')`: Posisi setelah kolom tertentu

---

### 📝 Latihan

1. Coba jalankan `php artisan migrate:rollback` untuk membatalkan migration terakhir
2. Coba jalankan `php artisan migrate` lagi
3. Buat migration baru untuk tabel `satuan` dengan kolom:
   - id
   - nama_satuan (string, unique)
   - created_at
   - updated_at

**Solusi Latihan:**
```bash
php artisan make:migration create_satuan_table
```

```php
Schema::create('satuan', function (Blueprint $table) {
    $table->id();
    $table->string('nama_satuan', 50)->unique();
    $table->timestamps();
});
```

---

### 🎯 Rangkuman

Di bagian ini Anda sudah belajar:

✅ Konsep MVC (Model-View-Controller)  
✅ Merancang struktur database  
✅ Relasi antar tabel  
✅ Membuat migration  
✅ Tipe data di migration  
✅ Foreign key dan constraint  

**Langkah Selanjutnya:**

Di bagian 3, kita akan belajar:
- Membuat Model (Eloquent ORM)
- Relasi di Model
- Query Builder
- Seeding data awal

---

*Tetap semangat belajar! 🚀*
