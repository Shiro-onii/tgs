# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 7: Tips, Best Practices & Deployment

### 🎯 Rangkuman Pembelajaran

Selamat! Anda telah mempelajari:

**Bagian 1-2: Fondasi**
✅ Instalasi Laravel & Tools  
✅ Konsep MVC  
✅ Database Design  
✅ Migration  

**Bagian 3-4: Data Layer**
✅ Model & Eloquent ORM  
✅ Relasi antar Model  
✅ Seeding Data  
✅ Authentication  

**Bagian 5-6: Application Layer**
✅ Controller & CRUD  
✅ Request Validation  
✅ Blade Template  
✅ Forms & Components  

---

### 💡 Best Practices Laravel

#### 1. Struktur Kode

**Controller:**
- Satu controller = satu resource
- Jangan taruh business logic di controller
- Gunakan Service/Repository pattern untuk logic kompleks

```php
// ❌ BAD: Business logic di controller
public function store(Request $request)
{
    $validated = $request->validate([...]);
    
    // Complex business logic
    if ($alat->jumlah_tersedia < $request->jumlah_pinjam) {
        // ...
    }
    
    DB::beginTransaction();
    // Multiple database operations...
    DB::commit();
}

// ✅ GOOD: Gunakan Service
public function store(Request $request)
{
    $validated = $request->validate([...]);
    
    $this->peminjamanService->createPeminjaman($validated);
    
    return redirect()->route('peminjaman.index')
        ->with('success', 'Peminjaman berhasil dibuat');
}
```

**Model:**
- Hanya untuk database operations & relasi
- Gunakan Accessors untuk format data
- Gunakan Scopes untuk query yang sering dipakai

**Views:**
- Pisahkan layouts, components, dan pages
- Jangan taruh logic kompleks di view
- Gunakan components untuk reusable elements

#### 2. Security

**CSRF Protection:**
```blade
{{-- Selalu gunakan @csrf di form --}}
<form method="POST" action="{{ route('kategori.store') }}">
    @csrf
    {{-- ... --}}
</form>
```

**XSS Protection:**
```blade
{{-- Gunakan {{ }} untuk auto-escape HTML --}}
{{ $user->name }}  {{-- Safe --}}

{{-- Hanya gunakan {!! !!} jika yakin data aman --}}
{!! $trustedHtml !!}
```

**SQL Injection Protection:**
```php
// ✅ GOOD: Eloquent otomatis protect
Alat::where('kategori_id', $id)->get();

// ❌ BAD: Raw query tanpa binding
DB::select("SELECT * FROM alat WHERE kategori_id = $id");

// ✅ GOOD: Raw query dengan binding
DB::select("SELECT * FROM alat WHERE kategori_id = ?", [$id]);
```

**Mass Assignment Protection:**
```php
// Di Model, selalu define $fillable atau $guarded
protected $fillable = ['nama', 'email', 'password'];
```

**Password Hashing:**
```php
// ✅ GOOD: Gunakan Hash
use Illuminate\Support\Facades\Hash;

$user->password = Hash::make($request->password);

// Di Model User, gunakan cast 'hashed'
protected $casts = [
    'password' => 'hashed',
];
```

#### 3. Performance

**Eager Loading (N+1 Problem):**
```php
// ❌ BAD: N+1 queries
$peminjamans = Peminjaman::all();
foreach ($peminjamans as $peminjaman) {
    echo $peminjaman->user->name; // Query untuk setiap peminjaman
}

// ✅ GOOD: Eager loading
$peminjamans = Peminjaman::with('user', 'alat')->all();
foreach ($peminjamans as $peminjaman) {
    echo $peminjaman->user->name; // Tidak ada query tambahan
}
```

**Caching:**
```php
// Cache data yang jarang berubah
$kategoris = Cache::remember('kategoris', 3600, function () {
    return Kategori::all();
});

// Clear cache saat data berubah
Cache::forget('kategoris');
```

**Pagination:**
```php
// Selalu gunakan pagination untuk list data
$alats = Alat::paginate(10);
```

#### 4. Code Organization

**Service Pattern:**
```php
// app/Services/PeminjamanService.php
class PeminjamanService
{
    public function createPeminjaman($data)
    {
        DB::beginTransaction();
        try {
            // Generate kode peminjaman
            $data['kode_peminjaman'] = $this->generateKode();
            
            // Create peminjaman
            $peminjaman = Peminjaman::create($data);
            
            // Update jumlah alat
            $alat = Alat::find($data['alat_id']);
            $alat->jumlah_tersedia -= $data['jumlah_pinjam'];
            $alat->save();
            
            // Log activity
            ActivityLog::log('CREATE_PEMINJAMAN', 
                "Membuat peminjaman {$peminjaman->kode_peminjaman}");
            
            DB::commit();
            return $peminjaman;
        } catch (\Exception $e) {
            DB::rollback();
            throw $e;
        }
    }
    
    private function generateKode()
    {
        // Logic generate kode
        return 'PJM' . date('Ymd') . rand(1000, 9999);
    }
}
```

**Request Validation:**
```php
// app/Http/Requests/StorePeminjamanRequest.php
class StorePeminjamanRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        return [
            'alat_id' => 'required|exists:alat,id',
            'jumlah_pinjam' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date|after_or_equal:today',
            'keperluan' => 'required|string',
        ];
    }
    
    public function messages()
    {
        return [
            'alat_id.required' => 'Alat wajib dipilih',
            'jumlah_pinjam.min' => 'Jumlah minimal 1',
        ];
    }
}

// Gunakan di controller
public function store(StorePeminjamanRequest $request)
{
    // Validasi otomatis dilakukan
    $peminjaman = $this->peminjamanService->createPeminjaman($request->validated());
}
```

---

### 🚀 Deployment

#### Persiapan Deploy

**1. Environment Configuration**

Edit `.env` untuk production:
```env
APP_NAME="Sistem Peminjaman Alat"
APP_ENV=production
APP_DEBUG=false  # WAJIB false di production!
APP_URL=https://yourdomain.com

DB_CONNECTION=mysql
DB_HOST=your_db_host
DB_PORT=3306
DB_DATABASE=your_db_name
DB_USERNAME=your_db_user
DB_PASSWORD=your_db_password

# Generate key baru
# php artisan key:generate
```

**2. Optimize untuk Production**

```bash
# Cache config
php artisan config:cache

# Cache routes
php artisan route:cache

# Cache views
php artisan view:cache

# Optimize autoloader
composer install --optimize-autoloader --no-dev

# Link storage
php artisan storage:link
```

**3. Keamanan**

```bash
# Set permission yang benar
chmod -R 755 /path/to/project
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data /path/to/project
```

#### Deploy ke Shared Hosting

**1. Upload Files**
- Upload semua file kecuali `node_modules` dan `vendor`
- Upload via FTP/SFTP atau Git

**2. Install Dependencies**
```bash
# SSH ke server
composer install --no-dev
npm install
npm run build
```

**3. Setup Database**
```bash
php artisan migrate --force
php artisan db:seed --force
```

**4. Setup .htaccess**

File `public/.htaccess`:
```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews -Indexes
    </IfModule>

    RewriteEngine On

    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

    # Redirect Trailing Slashes
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_URI} (.+)/$
    RewriteRule ^ %1 [L,R=301]

    # Send Requests To Front Controller
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]
</IfModule>
```

#### Deploy ke VPS (Ubuntu)

**1. Install Requirements**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install PHP 8.2
sudo apt install php8.2 php8.2-fpm php8.2-mysql php8.2-xml php8.2-mbstring php8.2-curl php8.2-zip

# Install Composer
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install MySQL
sudo apt install mysql-server
```

**2. Install Nginx**
```bash
sudo apt install nginx

# Config Nginx
sudo nano /etc/nginx/sites-available/peminjaman-alat
```

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    root /var/www/peminjaman-alat/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/peminjaman-alat /etc/nginx/sites-enabled/

# Test config
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

**3. Deploy Application**
```bash
cd /var/www
sudo git clone https://github.com/yourusername/peminjaman-alat.git
cd peminjaman-alat

# Install dependencies
composer install --no-dev
npm install
npm run build

# Setup environment
cp .env.example .env
nano .env  # Edit database config

# Generate key
php artisan key:generate

# Run migrations
php artisan migrate --force
php artisan db:seed --force

# Set permissions
sudo chown -R www-data:www-data /var/www/peminjaman-alat
sudo chmod -R 755 /var/www/peminjaman-alat
sudo chmod -R 775 storage bootstrap/cache

# Link storage
php artisan storage:link

# Optimize
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

**4. SSL Certificate (Let's Encrypt)**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

---

### 🔧 Troubleshooting

**Problem: 500 Internal Server Error**
```bash
# Check error log
tail -f storage/logs/laravel.log

# Common fixes:
php artisan cache:clear
php artisan config:clear
chmod -R 775 storage bootstrap/cache
```

**Problem: Storage files not accessible**
```bash
# Check symbolic link
ls -la public/storage

# Re-create link if needed
rm public/storage
php artisan storage:link
```

**Problem: Database connection failed**
- Check credentials di `.env`
- Check MySQL service: `sudo systemctl status mysql`
- Check firewall: `sudo ufw status`

**Problem: CSS/JS not loading**
```bash
# Rebuild assets
npm run build

# Check permissions
chmod -R 755 public
```

---

### 📝 Checklist Deploy

Sebelum go-live:

**Security:**
- [ ] APP_DEBUG=false
- [ ] APP_ENV=production
- [ ] Generate APP_KEY baru
- [ ] Ganti semua default password
- [ ] Setup firewall (ufw)
- [ ] Install SSL certificate
- [ ] Disable directory listing

**Performance:**
- [ ] Enable caching (config, route, view)
- [ ] Optimize images
- [ ] Minify CSS/JS
- [ ] Setup CDN (optional)
- [ ] Enable gzip compression

**Database:**
- [ ] Backup database
- [ ] Setup automated backup
- [ ] Check indexes
- [ ] Optimize queries

**Monitoring:**
- [ ] Setup error logging
- [ ] Setup uptime monitoring
- [ ] Setup performance monitoring

---

### 🎓 Belajar Lebih Lanjut

**Official Resources:**
- Laravel Docs: https://laravel.com/docs
- Laracasts: https://laracasts.com (video tutorials)
- Laravel News: https://laravel-news.com

**Rekomendasi Belajar:**
1. **Laravel Packages** untuk extend functionality
2. **Laravel Queue** untuk background jobs
3. **Laravel Broadcasting** untuk real-time features
4. **Laravel Testing** untuk quality assurance
5. **API Development** dengan Laravel Sanctum

**Advanced Topics:**
- Repository Pattern
- Design Patterns (Factory, Observer, etc.)
- Event & Listeners
- Jobs & Queues
- WebSockets & Real-time
- Testing (Unit, Feature, Browser)

---

### 🎉 Penutup

Selamat! Anda sudah menyelesaikan panduan lengkap Laravel untuk membuat aplikasi peminjaman alat.

**Yang sudah Anda kuasai:**
- ✅ Setup & instalasi Laravel
- ✅ Database design & migration
- ✅ Model & Eloquent ORM
- ✅ Authentication & authorization
- ✅ CRUD operations
- ✅ Blade template & components
- ✅ File upload
- ✅ Validation
- ✅ Best practices
- ✅ Deployment

**Langkah selanjutnya:**
1. Selesaikan fitur peminjaman lengkap
2. Tambahkan dashboard dengan chart/statistik
3. Buat laporan (export PDF/Excel)
4. Deploy ke production
5. Expand dengan fitur baru (notifikasi, API, dll)

**Tips Sukses:**
- 🔥 Praktek, praktek, praktek!
- 📖 Baca dokumentasi official
- 💬 Join komunitas Laravel Indonesia
- 🐛 Jangan takut error - error adalah guru terbaik
- 🚀 Build real projects, bukan hanya tutorial

---

**Terima kasih sudah belajar!**

Semoga sukses dengan project Laravel Anda! 🎊

*"The only way to learn programming is by writing programs." - Dennis Ritchie*

---

**Need Help?**
- Laravel Indonesia: https://id-laravel.com
- Stack Overflow: Tag "laravel"
- GitHub Issues: Untuk bug reports
- Discord: Laravel Indonesia Community

**Keep Learning, Keep Building! 💪🚀**
