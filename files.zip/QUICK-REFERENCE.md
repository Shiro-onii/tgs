# 🚀 Quick Reference - Laravel 12

Panduan ringkas untuk referensi cepat saat coding.

---

## 📦 Artisan Commands

```bash
# Project
php artisan serve                    # Jalankan server (localhost:8000)
php artisan key:generate            # Generate APP_KEY
php artisan storage:link            # Link storage ke public

# Database
php artisan migrate                 # Jalankan migration
php artisan migrate:fresh           # Drop semua table & migrate ulang
php artisan migrate:fresh --seed    # Fresh + seeding
php artisan db:seed                 # Jalankan seeder
php artisan migrate:rollback        # Rollback migration terakhir

# Make Commands
php artisan make:model NamaModel                    # Buat model
php artisan make:model NamaModel -m                 # Model + migration
php artisan make:model NamaModel -mc                # Model + migration + controller
php artisan make:controller NamaController          # Buat controller
php artisan make:controller NamaController --resource  # Resource controller
php artisan make:migration create_nama_table        # Buat migration
php artisan make:seeder NamaSeeder                  # Buat seeder
php artisan make:middleware NamaMiddleware          # Buat middleware
php artisan make:request NamaRequest                # Buat form request

# Cache
php artisan config:cache            # Cache config
php artisan route:cache             # Cache routes
php artisan view:cache              # Cache views
php artisan cache:clear             # Clear cache
php artisan config:clear            # Clear config cache
php artisan route:clear             # Clear route cache
php artisan view:clear              # Clear view cache

# Info
php artisan route:list              # Lihat semua routes
php artisan migrate:status          # Status migration
```

---

## 🗄️ Migration

```php
// Tipe Data Umum
$table->id();                       // BIGINT UNSIGNED (Primary Key)
$table->string('name', 100);        // VARCHAR(100)
$table->text('description');        // TEXT
$table->integer('qty');             // INT
$table->decimal('price', 10, 2);    // DECIMAL(10,2)
$table->boolean('active');          // TINYINT(1)
$table->date('tanggal');           // DATE
$table->datetime('waktu');         // DATETIME
$table->timestamp('created');      // TIMESTAMP
$table->enum('role', ['admin', 'user']);  // ENUM
$table->foreignId('user_id');      // Foreign Key

// Modifiers
->nullable()                        // Boleh NULL
->default('value')                  // Default value
->unique()                          // Unique constraint
->unsigned()                        // Unsigned (hanya positif)
->after('column')                   // Posisi setelah kolom tertentu

// Foreign Key
$table->foreignId('kategori_id')
      ->constrained('kategori')     // Reference ke tabel kategori
      ->onDelete('cascade');        // Delete cascade

// Timestamps
$table->timestamps();               // created_at & updated_at
$table->softDeletes();             // deleted_at (soft delete)
```

---

## 🎨 Eloquent Model

```php
// Definisi Model
protected $table = 'nama_tabel';            // Nama tabel
protected $primaryKey = 'id';               // Primary key
public $incrementing = true;                // Auto increment
protected $keyType = 'int';                 // Tipe primary key
public $timestamps = true;                  // Timestamps

// Mass Assignment
protected $fillable = ['name', 'email'];    // Kolom yang boleh mass assign
protected $guarded = ['id'];                // Kolom yang tidak boleh

// Hidden & Visible
protected $hidden = ['password'];           // Disembunyikan di JSON
protected $visible = ['name', 'email'];     // Yang ditampilkan di JSON

// Casting
protected $casts = [
    'email_verified_at' => 'datetime',
    'is_active' => 'boolean',
    'price' => 'decimal:2',
];

// Relasi
public function kategori()
{
    return $this->belongsTo(Kategori::class);  // Many to One
}

public function alat()
{
    return $this->hasMany(Alat::class);        // One to Many
}

public function pengembalian()
{
    return $this->hasOne(Pengembalian::class); // One to One
}

// Accessor
public function getFullNameAttribute()
{
    return $this->first_name . ' ' . $this->last_name;
}
// Usage: $user->full_name

// Scope
public function scopeActive($query)
{
    return $query->where('is_active', true);
}
// Usage: User::active()->get()
```

---

## 💾 Eloquent CRUD

```php
// CREATE
$model = Model::create(['name' => 'John']);
$model = new Model();
$model->name = 'John';
$model->save();

// READ
$all = Model::all();                        // Semua data
$model = Model::find(1);                    // By ID
$model = Model::findOrFail(1);             // By ID or 404
$first = Model::first();                    // Data pertama
$where = Model::where('name', 'John')->get();
$paginate = Model::paginate(10);           // Pagination

// UPDATE
$model = Model::find(1);
$model->name = 'Jane';
$model->save();

Model::where('id', 1)->update(['name' => 'Jane']);

// DELETE
$model = Model::find(1);
$model->delete();

Model::destroy(1);                          // By ID
Model::destroy([1, 2, 3]);                  // Multiple IDs
Model::where('name', 'John')->delete();

// Soft Delete
$model->delete();                           // Soft delete
$model->forceDelete();                      // Hard delete
Model::withTrashed()->get();               // Include soft deleted
Model::onlyTrashed()->get();               // Only soft deleted
$model->restore();                          // Restore soft deleted
```

---

## 🔍 Query Builder

```php
// WHERE
->where('column', 'value')
->where('column', '>', 5)
->orWhere('column', 'value')
->whereIn('column', [1, 2, 3])
->whereNotIn('column', [1, 2, 3])
->whereBetween('column', [1, 10])
->whereNull('column')
->whereNotNull('column')
->whereDate('created_at', '2024-01-01')
->whereMonth('created_at', 1)
->whereYear('created_at', 2024)

// ORDER & LIMIT
->orderBy('name', 'asc')
->latest()                      // orderBy created_at desc
->oldest()                      // orderBy created_at asc
->limit(10)
->offset(20)
->take(5)
->skip(10)

// SELECT
->select('id', 'name')
->distinct()
->pluck('name')                 // Array of names
->pluck('name', 'id')          // [id => name]

// GROUP & HAVING
->groupBy('category_id')
->having('total', '>', 100)

// JOIN
->join('kategori', 'alat.kategori_id', '=', 'kategori.id')
->leftJoin('kategori', 'alat.kategori_id', '=', 'kategori.id')

// WITH (Eager Loading)
->with('kategori')
->with(['kategori', 'peminjaman'])
->with(['kategori' => function($query) {
    $query->where('active', true);
}])

// AGGREGATE
->count()
->sum('price')
->avg('price')
->min('price')
->max('price')
```

---

## 🛡️ Validation Rules

```php
$request->validate([
    'name' => 'required|string|max:255',
    'email' => 'required|email|unique:users,email',
    'password' => 'required|confirmed|min:8',
    'age' => 'required|numeric|min:17|max:100',
    'phone' => 'required|regex:/^[0-9]{10,15}$/',
    'photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
    'role' => 'required|in:admin,user,guest',
    'category_id' => 'required|exists:categories,id',
    'tags' => 'required|array|min:1',
    'tags.*' => 'required|string',
    'birth_date' => 'required|date|before:today',
    'start_date' => 'required|date|after_or_equal:today',
]);
```

---

## 🎭 Blade Directives

```blade
{{-- Echo --}}
{{ $variable }}                     <!-- Escaped -->
{!! $html !!}                      <!-- Unescaped -->
{{ $var ?? 'default' }}            <!-- With default -->

{{-- Control Structures --}}
@if($condition)
@elseif($condition)
@else
@endif

@unless($condition)
@endunless

@isset($variable)
@endisset

@empty($variable)
@endempty

@auth
@endauth

@guest
@endguest

{{-- Loops --}}
@for($i = 0; $i < 10; $i++)
@endfor

@foreach($items as $item)
    {{ $loop->index }}              <!-- 0, 1, 2... -->
    {{ $loop->iteration }}          <!-- 1, 2, 3... -->
    @if($loop->first)
    @endif
    @if($loop->last)
    @endif
@endforeach

@forelse($items as $item)
@empty
    <p>No items</p>
@endforelse

@while($condition)
@endwhile

{{-- Switch --}}
@switch($status)
    @case('active')
        @break
    @default
@endswitch

{{-- Include & Extend --}}
@include('partials.header')
@extends('layouts.app')
@section('content')
@endsection
@yield('content')

{{-- Components --}}
<x-alert type="success" message="Saved!" />

{{-- CSRF --}}
@csrf
@method('PUT')
@method('DELETE')

{{-- Error --}}
@error('field')
    {{ $message }}
@enderror
```

---

## 🎯 Routes

```php
// Basic
Route::get('/url', [Controller::class, 'method']);
Route::post('/url', [Controller::class, 'method']);
Route::put('/url', [Controller::class, 'method']);
Route::delete('/url', [Controller::class, 'method']);

// Named Route
Route::get('/profile', [ProfileController::class, 'show'])
     ->name('profile.show');

// Route Parameters
Route::get('/user/{id}', [UserController::class, 'show']);
Route::get('/post/{post}/comment/{comment}', function($post, $comment) {
    // ...
});

// Resource Routes (7 routes)
Route::resource('kategori', KategoriController::class);

// Middleware
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
});

// Prefix
Route::prefix('admin')->group(function () {
    Route::get('/users', [AdminController::class, 'users']);
});
```

---

## 📝 Controller

```php
// Return View
return view('kategori.index', compact('kategoris'));
return view('kategori.index', ['kategoris' => $kategoris]);

// Redirect
return redirect()->route('kategori.index');
return redirect()->back();
return redirect('/home');

// Redirect with Flash
return redirect()->route('kategori.index')
       ->with('success', 'Data saved!');

// Redirect with Input
return redirect()->back()->withInput();

// JSON
return response()->json(['data' => $data]);

// Download
return response()->download($path);
```

---

## 💼 Helper Functions

```php
// URL
url('/home')
route('kategori.index')
route('kategori.show', $kategori)
asset('css/app.css')
asset('storage/foto.jpg')

// Auth
auth()->user()
auth()->id()
auth()->check()

// Session
session('key')
session(['key' => 'value'])
session()->flash('success', 'Saved!')

// Request
request('name')
request()->all()
request()->input('name')
request()->has('name')
request()->file('photo')

// Response
response()->json($data)
response()->download($path)

// String
Str::limit($text, 100)
Str::slug($title)
Str::upper($text)
Str::random(10)

// Array
collect([1, 2, 3])->sum()
collect($users)->pluck('name')
```

---

## 🔐 Authentication

```php
// Login
Auth::attempt(['email' => $email, 'password' => $password])

// Logout
Auth::logout()

// Check
if (Auth::check()) {
    // User logged in
}

// Get User
$user = Auth::user()
$id = Auth::id()

// Blade
@auth
    <p>Logged in</p>
@endauth

@guest
    <p>Please login</p>
@endguest
```

---

## 📁 File Upload

```php
// Store
if ($request->hasFile('photo')) {
    $path = $request->file('photo')->store('photos', 'public');
    // $path = "photos/filename.jpg"
}

// Store with custom name
$path = $request->file('photo')->storeAs(
    'photos',
    'custom-name.jpg',
    'public'
);

// Delete
Storage::disk('public')->delete($path);

// Check exists
Storage::disk('public')->exists($path);

// Get URL
asset('storage/' . $path)
```

---

## 🎨 Collection Methods

```php
$collection = collect([1, 2, 3, 4, 5]);

$collection->map(function($item) { return $item * 2; })
$collection->filter(function($item) { return $item > 2; })
$collection->sum()
$collection->avg()
$collection->count()
$collection->first()
$collection->last()
$collection->pluck('name')
$collection->unique()
$collection->sort()
$collection->reverse()
$collection->chunk(2)
$collection->take(3)
$collection->skip(2)
```

---

Simpan file ini untuk referensi cepat saat coding! 🚀
