# 📚 Panduan Lengkap Belajar Laravel 12
## Membuat Aplikasi Peminjaman Alat dari Nol

> Panduan step-by-step untuk pemula yang belum pernah belajar Laravel

---

## 🎯 Tentang Panduan Ini

Panduan ini dirancang khusus untuk Anda yang:
- ✅ Belum pernah belajar Laravel sama sekali
- ✅ Ingin belajar dari dasar dengan penjelasan lengkap
- ✅ Membutuhkan contoh praktis yang bisa langsung dipraktekkan
- ✅ Ingin membuat aplikasi nyata (bukan hanya teori)

## 📖 Daftar Isi

### [Bagian 1: Persiapan dan Instalasi](01-persiapan-instalasi.md)
- Pengenalan Laravel
- Software yang dibutuhkan (PHP, Composer, Node.js, MySQL, VS Code, Git)
- Instalasi Laravel 12
- Struktur folder Laravel
- Testing instalasi

### [Bagian 2: Konsep MVC dan Database](02-mvc-database.md)
- Konsep MVC dengan analogi sederhana
- Database design untuk aplikasi peminjaman alat
- Relasi antar tabel
- Migration di Laravel
- Membuat migration untuk semua tabel

### [Bagian 3: Model dan Eloquent ORM](03-model-eloquent.md)
- Apa itu Model dan ORM
- Membuat Model untuk semua tabel
- Relasi di Model (hasOne, hasMany, belongsTo)
- CRUD dengan Eloquent
- Query Builder
- Accessor, Scope, dan Eager Loading

### [Bagian 4: Seeding dan Authentication](04-seeding-authentication.md)
- Seeder untuk data awal
- Install Laravel Breeze
- Login dan Register
- Middleware untuk proteksi route
- Custom Middleware untuk check role
- Customize form dan redirect

### [Bagian 5: Controller dan CRUD](05-controller-crud.md)
- Apa itu Controller
- Resource Controller
- Request Validation
- CRUD Pattern lengkap
- Upload File
- Search & Filter
- Flash Messages

### [Bagian 6: Blade Template dan Views](06-blade-views.md)
- Apa itu Blade
- Blade Syntax (echo, loops, conditions)
- Layout dan Inheritance
- Components & Slots
- Forms dengan CSRF
- Error Handling di Form
- Helper Functions

### [Bagian 7: Tips, Best Practices & Deployment](07-tips-deployment.md)
- Rangkuman pembelajaran
- Best Practices Laravel
- Security tips
- Performance optimization
- Deploy ke Shared Hosting
- Deploy ke VPS (Ubuntu + Nginx)
- SSL Certificate
- Troubleshooting
- Resources untuk belajar lebih lanjut

---

## 🚀 Cara Menggunakan Panduan Ini

1. **Baca Secara Berurutan**
   - Mulai dari Bagian 1 hingga Bagian 7
   - Jangan skip bagian - setiap bagian membangun dari bagian sebelumnya

2. **Praktek Sambil Belajar**
   - Ketik ulang setiap kode (jangan copy-paste)
   - Coba modifikasi kode untuk eksperimen
   - Kerjakan setiap latihan yang diberikan

3. **Gunakan sebagai Reference**
   - Bookmark untuk referensi cepat
   - Kembali saat lupa konsep tertentu

---

## 💻 Aplikasi yang Akan Dibuat

**Nama:** Sistem Peminjaman Alat

**Fitur Utama:**
- Authentication (Login/Register/Logout)
- Role-based Access (Admin, Petugas, Peminjam)
- CRUD Kategori Alat
- CRUD Alat (dengan upload foto)
- CRUD User
- Pengajuan Peminjaman
- Persetujuan Peminjaman (oleh Petugas/Admin)
- Pengembalian Alat
- Activity Log
- Dashboard dengan statistik
- Laporan

**Role & Akses:**

| Fitur | Admin | Petugas | Peminjam |
|-------|-------|---------|----------|
| Login/Logout | ✅ | ✅ | ✅ |
| CRUD User | ✅ | ❌ | ❌ |
| CRUD Kategori | ✅ | ❌ | ❌ |
| CRUD Alat | ✅ | ❌ | ❌ |
| CRUD Data Peminjaman | ✅ | ✅ | ❌ |
| CRUD Pengembalian | ✅ | ✅ | ❌ |
| Menyetujui Peminjaman | ✅ | ✅ | ❌ |
| Memantau Pengembalian | ✅ | ✅ | ❌ |
| Mencetak Laporan | ✅ | ✅ | ❌ |
| Melihat Daftar Alat | ✅ | ✅ | ✅ |
| Mengajukan Peminjaman | ✅ | ✅ | ✅ |
| Mengembalikan Alat | ✅ | ✅ | ✅ |
| Log Aktivitas | ✅ | ❌ | ❌ |

---

## 🗄️ Database Schema

**Tabel:**
1. users (pengguna sistem)
2. kategori (kategori alat)
3. alat (daftar alat)
4. peminjaman (transaksi peminjaman)
5. pengembalian (data pengembalian)
6. activity_logs (log aktivitas)

**Entity Relationship Diagram:**
```
users (1) ──── (N) peminjaman
users (1) ──── (N) activity_logs
kategori (1) ──── (N) alat
alat (1) ──── (N) peminjaman
peminjaman (1) ──── (1) pengembalian
```

---

## 📋 Prerequisites

Sebelum mulai, Anda perlu:
- Komputer dengan Windows/Mac/Linux
- Koneksi internet untuk download software
- Text editor (akan diajari install VS Code)
- Semangat belajar! 💪

**Tidak perlu:**
- ❌ Pengalaman Laravel sebelumnya
- ❌ Pengalaman framework PHP lain
- ❌ Pengetahuan advanced tentang PHP

**Yang perlu tahu (basic):**
- ✅ HTML & CSS dasar
- ✅ PHP dasar (variable, array, function, if-else, loop)
- ✅ Database dasar (tabel, kolom, relasi)

---

## ⏱️ Estimasi Waktu Belajar

- **Bagian 1-2:** 3-4 jam (instalasi + database)
- **Bagian 3-4:** 4-5 jam (model + auth)
- **Bagian 5-6:** 5-6 jam (controller + view)
- **Bagian 7:** 2-3 jam (deployment)

**Total:** ~15-18 jam untuk menyelesaikan semua

**Tips:** Jangan terburu-buru! Lebih baik paham 1 konsep dengan benar daripada terburu-buru tapi bingung.

---

## 🎓 Apa yang Akan Anda Kuasai

Setelah menyelesaikan panduan ini, Anda akan bisa:

**Teknis:**
- ✅ Setup dan konfigurasi Laravel
- ✅ Membuat database dengan migration
- ✅ Membuat Model dengan relasi
- ✅ Membuat CRUD lengkap
- ✅ Upload file
- ✅ Authentication & Authorization
- ✅ Validation
- ✅ Blade Template
- ✅ Deploy aplikasi

**Konsep:**
- ✅ MVC Pattern
- ✅ ORM (Object-Relational Mapping)
- ✅ Route Model Binding
- ✅ Middleware
- ✅ Service Pattern
- ✅ Request/Response Lifecycle

---

## 📞 Butuh Bantuan?

Jika menemui kesulitan:

1. **Baca ulang bagian yang bingung**
2. **Cek error message dengan teliti**
3. **Cari di dokumentasi official:** https://laravel.com/docs
4. **Stack Overflow** dengan tag "laravel"
5. **Komunitas Laravel Indonesia:**
   - Website: https://id-laravel.com
   - Telegram/Discord: Cari "Laravel Indonesia"

---

## 📝 Notes

- Kode contoh ditulis untuk Laravel 12
- Menggunakan PHP 8.2
- Database: MySQL/MariaDB
- Front-end: Blade + Bootstrap 5
- Auth: Laravel Breeze

---

## 🙏 Kontribusi

Jika menemukan typo, error, atau ingin menambahkan penjelasan:
- Silakan buat issue atau pull request
- Feedback sangat dihargai!

---

## 📜 Lisensi

Panduan ini bebas digunakan untuk belajar. Silakan share ke teman-teman yang ingin belajar Laravel!

---

## 🎉 Selamat Belajar!

Remember:
> "The only way to learn programming is by writing programs." - Dennis Ritchie

**Mulai sekarang dari [Bagian 1: Persiapan dan Instalasi](01-persiapan-instalasi.md)**

**Happy Coding! 🚀**
