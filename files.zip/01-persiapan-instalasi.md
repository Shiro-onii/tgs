# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 1: Persiapan dan Instalasi

### 📚 Pengenalan

Selamat datang di panduan pembelajaran Laravel 12! Kita akan membuat aplikasi peminjaman alat dari nol. Aplikasi ini memiliki:

**3 Role Pengguna:**
- **Admin**: Mengelola semua data sistem
- **Petugas**: Mengelola peminjaman dan pengembalian
- **Peminjam**: Mengajukan dan mengelola peminjaman mereka

**Fitur Utama:**
- Login & Logout
- CRUD (Create, Read, Update, Delete) untuk:
  - User
  - Alat
  - Kategori
  - Data Peminjaman
  - Pengembalian
- Log Aktivitas
- Persetujuan Peminjaman
- Pencetakan Laporan
- Daftar Alat

---

### 🎯 Apa itu Laravel?

Laravel adalah framework PHP yang mempermudah pembuatan aplikasi web. Bayangkan Laravel seperti "template" atau "kerangka" yang sudah menyiapkan banyak hal untuk Anda, sehingga Anda tidak perlu membuat semuanya dari nol.

**Analogi sederhana:**
- Membuat aplikasi tanpa framework = membangun rumah dari nol (buat fondasi, tembok, atap sendiri)
- Membuat aplikasi dengan Laravel = membangun rumah dengan kerangka yang sudah ada (tinggal atur ruangan dan dekorasi)

**Keuntungan Laravel:**
1. **MVC (Model-View-Controller)**: Memisahkan kode menjadi bagian-bagian yang rapi
2. **ORM Eloquent**: Berbicara dengan database tanpa menulis SQL rumit
3. **Migration**: Mengelola struktur database seperti mengelola kode
4. **Authentication**: Sistem login sudah siap pakai
5. **Routing**: Mengatur URL dengan mudah

---

### 🛠️ Software yang Dibutuhkan

#### 1. **PHP (versi 8.2 atau lebih baru)**
PHP adalah bahasa pemrograman yang digunakan Laravel.

**Download:**
- Windows: https://windows.php.net/download/
- Download versi "Thread Safe" ZIP
- Ekstrak ke `C:\php`

**Cara Install di Windows:**
```bash
# 1. Ekstrak file zip ke C:\php
# 2. Tambahkan ke PATH:
#    - Buka "Edit system environment variables"
#    - Klik "Environment Variables"
#    - Di "System variables", pilih "Path", klik "Edit"
#    - Klik "New", tambahkan: C:\php
#    - Klik OK semua

# 3. Cek instalasi:
php -v
```

**Konfigurasi PHP:**
```bash
# Copy php.ini-development menjadi php.ini
# Lalu edit php.ini, aktifkan extension dengan menghapus tanda ;

extension=curl
extension=fileinfo
extension=gd
extension=mbstring
extension=pdo_mysql
extension=openssl
extension=zip
```

#### 2. **Composer (Package Manager untuk PHP)**
Composer seperti "toko aplikasi" untuk mengunduh dan mengelola library PHP.

**Download & Install:**
- https://getcomposer.org/download/
- Jalankan installer, ikuti instruksi
- Pastikan memilih path PHP yang benar (C:\php\php.exe)

**Cek instalasi:**
```bash
composer -V
# Harus muncul: Composer version 2.x.x
```

#### 3. **Node.js dan NPM**
Digunakan untuk mengelola asset front-end (CSS, JavaScript).

**Download & Install:**
- https://nodejs.org/
- Pilih versi LTS (Long Term Support)
- Jalankan installer

**Cek instalasi:**
```bash
node -v
npm -v
```

#### 4. **Database MySQL/MariaDB**

**Pilihan A: XAMPP (Paling Mudah)**
- Download: https://www.apachefriends.org/
- Install, jalankan Apache dan MySQL dari Control Panel

**Pilihan B: MySQL Standalone**
- Download: https://dev.mysql.com/downloads/mysql/
- Install dengan default settings
- Catat password root yang Anda buat

#### 5. **Code Editor: Visual Studio Code**
Text editor profesional dengan banyak fitur.

**Download & Install:**
- https://code.visualstudio.com/
- Install, lalu tambahkan extension:
  - PHP Intelephense
  - Laravel Blade Snippets
  - Laravel Snippets
  - Laravel goto view
  - DotENV

**Cara Install Extension:**
1. Buka VS Code
2. Klik icon Extensions (Ctrl+Shift+X)
3. Cari nama extension
4. Klik Install

#### 6. **Git (Version Control)**
Untuk mengelola versi kode.

**Download & Install:**
- https://git-scm.com/
- Install dengan default settings

**Cek instalasi:**
```bash
git --version
```

---

### 📦 Instalasi Laravel 12

Setelah semua software terinstall, saatnya membuat project Laravel!

#### Langkah 1: Buat Project Laravel Baru

```bash
# Buka Terminal/Command Prompt
# Pindah ke folder tempat Anda ingin menyimpan project
cd C:\xampp\htdocs

# atau
cd D:\projects

# Buat project Laravel baru bernama "peminjaman-alat"
composer create-project laravel/laravel peminjaman-alat

# Tunggu beberapa menit (mengunduh semua dependencies)
```

#### Langkah 2: Masuk ke Folder Project

```bash
cd peminjaman-alat
```

#### Langkah 3: Install Dependencies Front-end

```bash
npm install
```

#### Langkah 4: Konfigurasi Environment

```bash
# File .env sudah dibuat otomatis
# Buka dengan VS Code:
code .

# Edit file .env:
```

**Isi file .env:**
```env
APP_NAME="Sistem Peminjaman Alat"
APP_ENV=local
APP_KEY=base64:xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
APP_DEBUG=true
APP_URL=http://localhost:8000

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=peminjaman_alat
DB_USERNAME=root
DB_PASSWORD=

# Jika pakai XAMPP, password kosong
# Jika pakai MySQL standalone, isi dengan password Anda
```

#### Langkah 5: Buat Database

**Cara 1: Pakai phpMyAdmin (XAMPP)**
1. Buka browser: http://localhost/phpmyadmin
2. Klik "New" di sidebar
3. Nama database: `peminjaman_alat`
4. Collation: `utf8mb4_unicode_ci`
5. Klik "Create"

**Cara 2: Pakai MySQL Command Line**
```bash
mysql -u root -p

# Setelah login:
CREATE DATABASE peminjaman_alat;
exit;
```

#### Langkah 6: Generate Application Key

```bash
php artisan key:generate
```

#### Langkah 7: Jalankan Server Development

```bash
php artisan serve
```

Buka browser: **http://localhost:8000**

Jika muncul halaman Laravel, **SELAMAT!** 🎉 Instalasi berhasil!

---

### 🏗️ Struktur Folder Laravel

Mari pahami struktur folder Laravel:

```
peminjaman-alat/
│
├── app/                    # Kode aplikasi utama
│   ├── Http/
│   │   ├── Controllers/   # File yang menangani logic
│   │   └── Middleware/    # Filter untuk request
│   ├── Models/            # File untuk berinteraksi dengan database
│   └── Providers/         # Service providers
│
├── bootstrap/             # File untuk bootstrap framework
│
├── config/                # File konfigurasi
│
├── database/              # Database related files
│   ├── migrations/       # File untuk membuat struktur database
│   ├── seeders/          # File untuk mengisi data awal
│   └── factories/        # File untuk generate data dummy
│
├── public/                # File yang bisa diakses publik
│   ├── css/
│   ├── js/
│   └── index.php         # Entry point aplikasi
│
├── resources/             # Resource files
│   ├── views/            # File tampilan (HTML)
│   ├── css/
│   └── js/
│
├── routes/                # File routing
│   └── web.php           # Routes untuk web
│
├── storage/               # File temporary & logs
│
├── tests/                 # File testing
│
├── vendor/                # Dependencies (jangan diedit!)
│
├── .env                   # Environment configuration
├── artisan               # Command line tool
├── composer.json         # PHP dependencies
└── package.json          # Node dependencies
```

**Folder Penting yang Sering Digunakan:**
- **app/Models**: Tempat Model (representasi tabel database)
- **app/Http/Controllers**: Tempat Controller (logic aplikasi)
- **resources/views**: Tempat file tampilan (HTML/Blade)
- **routes/web.php**: Tempat mendefinisikan URL
- **database/migrations**: Tempat membuat struktur database
- **public**: Tempat file CSS, JS, gambar

---

### 🧪 Testing Instalasi

Mari coba buat halaman sederhana untuk memastikan semua berjalan baik.

#### 1. Buat Route Baru

Edit file `routes/web.php`:

```php
<?php

use Illuminate\Support\Facades\Route;

// Route yang sudah ada
Route::get('/', function () {
    return view('welcome');
});

// Route baru untuk testing
Route::get('/test', function () {
    return '<h1>Halo, Laravel 12!</h1><p>Instalasi berhasil! 🎉</p>';
});
```

Akses: http://localhost:8000/test

#### 2. Buat View Baru

Buat file `resources/views/test.blade.php`:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Test Laravel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
            text-align: center;
        }
        .success {
            color: green;
            background: #d4edda;
            padding: 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="success">
        <h1>✅ Laravel 12 Berhasil Terinstall!</h1>
        <p>Sekarang Anda siap membuat aplikasi peminjaman alat</p>
        <p>Waktu sekarang: {{ date('d F Y, H:i:s') }}</p>
    </div>
</body>
</html>
```

Update route di `routes/web.php`:

```php
Route::get('/test', function () {
    return view('test');
});
```

Refresh: http://localhost:8000/test

---

### ✅ Checklist Instalasi

Pastikan semua ini sudah berjalan:

- [ ] PHP terinstall (cek: `php -v`)
- [ ] Composer terinstall (cek: `composer -V`)
- [ ] Node.js terinstall (cek: `node -v`)
- [ ] MySQL/XAMPP berjalan
- [ ] Database `peminjaman_alat` sudah dibuat
- [ ] Project Laravel berjalan di http://localhost:8000
- [ ] Halaman test berhasil ditampilkan

---

### 🚀 Langkah Selanjutnya

Di bagian berikutnya, kita akan belajar:

1. **Konsep MVC di Laravel**
2. **Membuat Database dengan Migration**
3. **Membuat Model untuk setiap tabel**
4. **Seeding data awal**
5. **Membuat Authentication (Login/Register)**

---

### 💡 Tips Belajar

1. **Jangan terburu-buru**: Pahami setiap konsep sebelum lanjut
2. **Praktek sambil baca**: Ketik ulang kode, jangan copy-paste
3. **Coba modifikasi**: Ubah-ubah kode untuk lihat hasilnya
4. **Baca error message**: Error adalah guru terbaik
5. **Gunakan dokumentasi**: https://laravel.com/docs/12.x

---

### ❓ Troubleshooting

**Problem: "php not found" atau "composer not found"**
- Solusi: Pastikan sudah menambahkan ke PATH environment variable

**Problem: Database connection error**
- Cek MySQL/XAMPP sudah berjalan
- Cek kredensial di file .env
- Cek nama database sudah dibuat

**Problem: Port 8000 already in use**
- Solusi: Gunakan port lain: `php artisan serve --port=8001`

**Problem: Missing extension**
- Solusi: Edit php.ini, aktifkan extension yang dibutuhkan

---

### 📝 Latihan

Sebelum lanjut ke bagian berikutnya, coba:

1. Buat route baru `/profil` yang menampilkan nama Anda
2. Buat view untuk route tersebut
3. Tambahkan CSS sederhana untuk mempercantik tampilan

**Selamat belajar! 🚀**

---

*Panduan ini dibuat untuk pemula yang belum pernah menggunakan Laravel sebelumnya.*
