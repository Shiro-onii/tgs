# Panduan Belajar Laravel 12 - Aplikasi Peminjaman Alat
## Bagian 3: Model dan Eloquent ORM

### 📚 Apa itu Model?

Model adalah representasi dari tabel database dalam bentuk class PHP. Dengan model, Anda bisa berinteraksi dengan database tanpa menulis SQL.

#### 🎯 Analogi Sederhana

Bayangkan database seperti lemari arsip:
- **Tanpa Model**: Anda harus buka lemari, cari folder, baca dokumen (menulis SQL manual)
- **Dengan Model**: Anda punya asisten (Model) yang mengambilkan dokumen untuk Anda

**Contoh:**
```php
// Tanpa Model (SQL Manual)
$result = DB::select('SELECT * FROM alat WHERE kategori_id = ?', [1]);

// Dengan Model (Eloquent)
$alat = Alat::where('kategori_id', 1)->get();
```

---

### 🔧 Membuat Model

Laravel menyediakan command untuk membuat model:

```bash
# Membuat model saja
php artisan make:model NamaModel

# Membuat model + migration
php artisan make:model NamaModel -m

# Membuat model + migration + controller
php artisan make:model NamaModel -mc

# Membuat model + migration + controller + seeder + factory
php artisan make:model NamaModel -a
```

**Konvensi Penamaan:**
- Nama Model: **Singular** (tunggal), PascalCase
  - Contoh: `User`, `Alat`, `Kategori`
- Nama Tabel: **Plural** (jamak), snake_case
  - Contoh: `users`, `alat`, `kategori`

Laravel otomatis mapping:
- Model `User` → Tabel `users`
- Model `Kategori` → Tabel `kategoris` (Laravel otomatis pluralize)
- Jika nama tabel berbeda, bisa di-override

---

### 📝 Membuat Model untuk Aplikasi

Mari kita buat semua model yang dibutuhkan!

#### 1. Model Kategori

```bash
php artisan make:model Kategori
```

Edit file `app/Models/Kategori.php`:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Kategori extends Model
{
    use HasFactory;

    // Nama tabel (jika berbeda dari konvensi)
    protected $table = 'kategori';

    // Primary key (default: 'id')
    protected $primaryKey = 'id';

    // Auto increment (default: true)
    public $incrementing = true;

    // Tipe data primary key (default: 'int')
    protected $keyType = 'int';

    // Timestamps (default: true)
    public $timestamps = true;

    // Mass assignment (kolom yang boleh diisi massal)
    protected $fillable = [
        'nama_kategori',
        'deskripsi',
    ];

    // Kolom yang disembunyikan saat serialize (ke JSON)
    protected $hidden = [];

    // Casting tipe data
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relasi: Kategori punya banyak Alat
     */
    public function alat()
    {
        return $this->hasMany(Alat::class, 'kategori_id', 'id');
    }
}
```

**Penjelasan Kode:**

1. **$fillable**: Kolom yang boleh diisi menggunakan `create()` atau `update()`
   - Untuk keamanan (Mass Assignment Protection)
   - Hanya kolom di sini yang bisa diisi massal

2. **$hidden**: Kolom yang disembunyikan saat convert ke JSON
   - Biasa untuk password, token, dll

3. **$casts**: Konversi tipe data otomatis
   - Laravel otomatis convert string dari database ke tipe yang ditentukan

4. **Relasi**: Method untuk mendefinisikan hubungan antar tabel

#### 2. Model Alat

```bash
php artisan make:model Alat
```

Edit file `app/Models/Alat.php`:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Alat extends Model
{
    use HasFactory;

    protected $table = 'alat';

    protected $fillable = [
        'kode_alat',
        'nama_alat',
        'kategori_id',
        'merk',
        'kondisi',
        'jumlah_total',
        'jumlah_tersedia',
        'foto',
        'spesifikasi',
    ];

    protected $casts = [
        'jumlah_total' => 'integer',
        'jumlah_tersedia' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Relasi: Alat milik satu Kategori
     */
    public function kategori()
    {
        return $this->belongsTo(Kategori::class, 'kategori_id', 'id');
    }

    /**
     * Relasi: Alat punya banyak Peminjaman
     */
    public function peminjaman()
    {
        return $this->hasMany(Peminjaman::class, 'alat_id', 'id');
    }

    /**
     * Accessor: Get foto URL
     */
    public function getFotoUrlAttribute()
    {
        if ($this->foto) {
            return asset('storage/' . $this->foto);
        }
        return asset('images/no-image.png');
    }

    /**
     * Scope: Filter alat yang tersedia
     */
    public function scopeTersedia($query)
    {
        return $query->where('jumlah_tersedia', '>', 0);
    }

    /**
     * Scope: Filter berdasarkan kondisi
     */
    public function scopeKondisi($query, $kondisi)
    {
        return $query->where('kondisi', $kondisi);
    }
}
```

**Penjelasan Kode Baru:**

1. **Accessor** (`getFotoUrlAttribute`):
   - Method khusus untuk mendapatkan nilai yang sudah dimodifikasi
   - Bisa dipanggil: `$alat->foto_url`
   - Format: `get{NamaKolom}Attribute`

2. **Scope** (`scopeTersedia`, `scopeKondisi`):
   - Method untuk query yang sering dipakai
   - Bisa dipanggil: `Alat::tersedia()->get()`
   - Format: `scope{NamaScope}`

#### 3. Model User (Update)

Laravel sudah membuat model User, kita perlu update:

Edit file `app/Models/User.php`:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'address',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed', // Laravel 12: otomatis hash password
    ];

    /**
     * Relasi: User punya banyak Peminjaman
     */
    public function peminjaman()
    {
        return $this->hasMany(Peminjaman::class, 'user_id', 'id');
    }

    /**
     * Relasi: User punya banyak Activity Logs
     */
    public function activityLogs()
    {
        return $this->hasMany(ActivityLog::class, 'user_id', 'id');
    }

    /**
     * Relasi: User menyetujui banyak Peminjaman (sebagai petugas)
     */
    public function peminjaman_disetujui()
    {
        return $this->hasMany(Peminjaman::class, 'disetujui_oleh', 'id');
    }

    /**
     * Scope: Filter berdasarkan role
     */
    public function scopeRole($query, $role)
    {
        return $query->where('role', $role);
    }

    /**
     * Check apakah user adalah Admin
     */
    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    /**
     * Check apakah user adalah Petugas
     */
    public function isPetugas()
    {
        return $this->role === 'petugas';
    }

    /**
     * Check apakah user adalah Peminjam
     */
    public function isPeminjam()
    {
        return $this->role === 'peminjam';
    }
}
```

#### 4. Model Peminjaman

```bash
php artisan make:model Peminjaman
```

Edit file `app/Models/Peminjaman.php`:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Peminjaman extends Model
{
    use HasFactory;

    protected $table = 'peminjaman';

    protected $fillable = [
        'kode_peminjaman',
        'user_id',
        'alat_id',
        'jumlah_pinjam',
        'tanggal_pinjam',
        'tanggal_kembali_rencana',
        'tanggal_kembali_aktual',
        'keperluan',
        'status',
        'catatan_petugas',
        'disetujui_oleh',
    ];

    protected $casts = [
        'tanggal_pinjam' => 'date',
        'tanggal_kembali_rencana' => 'date',
        'tanggal_kembali_aktual' => 'date',
        'jumlah_pinjam' => 'integer',
    ];

    /**
     * Relasi: Peminjaman milik satu User (peminjam)
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    /**
     * Relasi: Peminjaman milik satu Alat
     */
    public function alat()
    {
        return $this->belongsTo(Alat::class, 'alat_id', 'id');
    }

    /**
     * Relasi: Peminjaman disetujui oleh satu User (petugas)
     */
    public function petugas()
    {
        return $this->belongsTo(User::class, 'disetujui_oleh', 'id');
    }

    /**
     * Relasi: Peminjaman punya satu Pengembalian
     */
    public function pengembalian()
    {
        return $this->hasOne(Pengembalian::class, 'peminjaman_id', 'id');
    }

    /**
     * Scope: Filter berdasarkan status
     */
    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope: Peminjaman yang menunggu persetujuan
     */
    public function scopeMenunggu($query)
    {
        return $query->where('status', 'menunggu');
    }

    /**
     * Scope: Peminjaman yang sedang dipinjam
     */
    public function scopeDipinjam($query)
    {
        return $query->where('status', 'dipinjam');
    }

    /**
     * Check apakah terlambat
     */
    public function isTerlambat()
    {
        if ($this->status === 'dipinjam') {
            return now()->isAfter($this->tanggal_kembali_rencana);
        }
        return false;
    }

    /**
     * Hitung durasi peminjaman (hari)
     */
    public function getDurasiAttribute()
    {
        return $this->tanggal_pinjam->diffInDays($this->tanggal_kembali_rencana);
    }
}
```

#### 5. Model Pengembalian

```bash
php artisan make:model Pengembalian
```

Edit file `app/Models/Pengembalian.php`:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pengembalian extends Model
{
    use HasFactory;

    protected $table = 'pengembalian';

    protected $fillable = [
        'peminjaman_id',
        'tanggal_pengembalian',
        'kondisi_alat',
        'jumlah_dikembalikan',
        'denda',
        'keterangan',
        'diterima_oleh',
    ];

    protected $casts = [
        'tanggal_pengembalian' => 'date',
        'jumlah_dikembalikan' => 'integer',
        'denda' => 'decimal:2',
    ];

    /**
     * Relasi: Pengembalian milik satu Peminjaman
     */
    public function peminjaman()
    {
        return $this->belongsTo(Peminjaman::class, 'peminjaman_id', 'id');
    }

    /**
     * Relasi: Pengembalian diterima oleh satu User (petugas)
     */
    public function petugas()
    {
        return $this->belongsTo(User::class, 'diterima_oleh', 'id');
    }

    /**
     * Check apakah ada denda
     */
    public function hasDenda()
    {
        return $this->denda > 0;
    }
}
```

#### 6. Model ActivityLog

```bash
php artisan make:model ActivityLog
```

Edit file `app/Models/ActivityLog.php`:

```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ActivityLog extends Model
{
    use HasFactory;

    protected $table = 'activity_logs';

    protected $fillable = [
        'user_id',
        'activity',
        'description',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    /**
     * Relasi: Activity Log milik satu User
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    /**
     * Static method untuk log aktivitas
     */
    public static function log($activity, $description)
    {
        return self::create([
            'user_id' => auth()->id(),
            'activity' => $activity,
            'description' => $description,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }
}
```

---

### 🔗 Jenis Relasi di Eloquent

#### 1. **One to One** (hasOne / belongsTo)

Satu record di tabel A punya satu record di tabel B.

**Contoh:** Peminjaman → Pengembalian

```php
// Di Model Peminjaman
public function pengembalian()
{
    return $this->hasOne(Pengembalian::class, 'peminjaman_id', 'id');
    // hasOne(Model, foreign_key, local_key)
}

// Di Model Pengembalian
public function peminjaman()
{
    return $this->belongsTo(Peminjaman::class, 'peminjaman_id', 'id');
    // belongsTo(Model, foreign_key, owner_key)
}

// Cara Pakai:
$peminjaman = Peminjaman::find(1);
$pengembalian = $peminjaman->pengembalian; // Object Pengembalian atau null
```

#### 2. **One to Many** (hasMany / belongsTo)

Satu record di tabel A punya banyak record di tabel B.

**Contoh:** Kategori → Alat

```php
// Di Model Kategori (One)
public function alat()
{
    return $this->hasMany(Alat::class, 'kategori_id', 'id');
}

// Di Model Alat (Many)
public function kategori()
{
    return $this->belongsTo(Kategori::class, 'kategori_id', 'id');
}

// Cara Pakai:
$kategori = Kategori::find(1);
$alat = $kategori->alat; // Collection dari Alat
$alat_count = $kategori->alat()->count(); // Hitung jumlah alat

$alat = Alat::find(1);
$kategori = $alat->kategori; // Object Kategori
```

#### 3. **Many to Many** (belongsToMany)

Banyak record di tabel A bisa punya banyak record di tabel B (perlu tabel pivot).

*Tidak dipakai di aplikasi kita, tapi untuk pengetahuan:*

```php
// Contoh: User bisa punya banyak Role, Role bisa punya banyak User
// Butuh tabel pivot: role_user

// Di Model User
public function roles()
{
    return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id');
}

// Di Model Role
public function users()
{
    return $this->belongsToMany(User::class, 'role_user', 'role_id', 'user_id');
}
```

---

### 💾 CRUD dengan Eloquent

#### Create (Buat Data Baru)

```php
// Method 1: Buat object, set property, save
$kategori = new Kategori();
$kategori->nama_kategori = 'Elektronik';
$kategori->deskripsi = 'Alat-alat elektronik';
$kategori->save();

// Method 2: Mass assignment (lebih simple)
$kategori = Kategori::create([
    'nama_kategori' => 'Elektronik',
    'deskripsi' => 'Alat-alat elektronik',
]);

// Method 3: firstOrCreate (buat jika belum ada)
$kategori = Kategori::firstOrCreate(
    ['nama_kategori' => 'Elektronik'], // Kondisi pencarian
    ['deskripsi' => 'Alat-alat elektronik'] // Data tambahan jika buat baru
);

// Method 4: updateOrCreate (update jika ada, buat jika tidak)
$kategori = Kategori::updateOrCreate(
    ['nama_kategori' => 'Elektronik'],
    ['deskripsi' => 'Alat-alat elektronik terbaru']
);
```

#### Read (Baca Data)

```php
// Ambil semua data
$kategori = Kategori::all();

// Ambil data dengan kondisi
$kategori = Kategori::where('nama_kategori', 'Elektronik')->get();

// Ambil satu data berdasarkan ID
$kategori = Kategori::find(1);

// Ambil satu data atau throw exception jika tidak ada
$kategori = Kategori::findOrFail(1);

// Ambil data pertama
$kategori = Kategori::first();

// Ambil data pertama dengan kondisi
$kategori = Kategori::where('nama_kategori', 'Elektronik')->first();

// Ambil data dengan relasi (Eager Loading)
$kategori = Kategori::with('alat')->get();

// Paginasi
$kategori = Kategori::paginate(10); // 10 data per halaman

// Count
$total = Kategori::count();

// Pluck (ambil hanya kolom tertentu)
$nama = Kategori::pluck('nama_kategori'); // Array nama kategori
$options = Kategori::pluck('nama_kategori', 'id'); // [id => nama]
```

#### Update (Ubah Data)

```php
// Method 1: Find, set property, save
$kategori = Kategori::find(1);
$kategori->nama_kategori = 'Elektronik Terbaru';
$kategori->save();

// Method 2: Mass update
$kategori = Kategori::find(1);
$kategori->update([
    'nama_kategori' => 'Elektronik Terbaru',
    'deskripsi' => 'Deskripsi baru',
]);

// Method 3: Update tanpa find (query builder)
Kategori::where('id', 1)->update([
    'nama_kategori' => 'Elektronik Terbaru',
]);
```

#### Delete (Hapus Data)

```php
// Method 1: Find lalu delete
$kategori = Kategori::find(1);
$kategori->delete();

// Method 2: Delete langsung dengan ID
Kategori::destroy(1);

// Method 3: Delete multiple dengan array ID
Kategori::destroy([1, 2, 3]);

// Method 4: Delete dengan query
Kategori::where('nama_kategori', 'Test')->delete();
```

---

### 🔍 Query Builder

Laravel menyediakan banyak method untuk query database:

```php
// WHERE
Alat::where('kategori_id', 1)->get();
Alat::where('kondisi', 'baik')->get();
Alat::where('jumlah_tersedia', '>', 0)->get();

// WHERE dengan multiple kondisi
Alat::where('kategori_id', 1)
    ->where('kondisi', 'baik')
    ->where('jumlah_tersedia', '>', 0)
    ->get();

// OR WHERE
Alat::where('kondisi', 'baik')
    ->orWhere('kondisi', 'rusak_ringan')
    ->get();

// WHERE IN
Alat::whereIn('kategori_id', [1, 2, 3])->get();

// WHERE NULL / NOT NULL
Alat::whereNull('foto')->get();
Alat::whereNotNull('foto')->get();

// WHERE BETWEEN
Peminjaman::whereBetween('tanggal_pinjam', ['2024-01-01', '2024-12-31'])->get();

// WHERE DATE
Peminjaman::whereDate('tanggal_pinjam', '2024-01-15')->get();
Peminjaman::whereYear('tanggal_pinjam', 2024)->get();
Peminjaman::whereMonth('tanggal_pinjam', 1)->get();

// ORDER BY
Alat::orderBy('nama_alat', 'asc')->get();
Alat::orderBy('created_at', 'desc')->get();
Alat::latest()->get(); // Sama dengan orderBy('created_at', 'desc')
Alat::oldest()->get(); // Sama dengan orderBy('created_at', 'asc')

// LIMIT & OFFSET
Alat::take(5)->get(); // Ambil 5 data
Alat::skip(10)->take(5)->get(); // Skip 10, ambil 5

// SELECT kolom tertentu
Alat::select('id', 'nama_alat', 'kode_alat')->get();

// DISTINCT
Peminjaman::distinct()->pluck('user_id');

// GROUP BY & HAVING
Peminjaman::select('user_id', DB::raw('COUNT(*) as total'))
    ->groupBy('user_id')
    ->having('total', '>', 5)
    ->get();

// JOIN
Alat::join('kategori', 'alat.kategori_id', '=', 'kategori.id')
    ->select('alat.*', 'kategori.nama_kategori')
    ->get();

// LEFT JOIN
Alat::leftJoin('kategori', 'alat.kategori_id', '=', 'kategori.id')->get();

// SEARCH (LIKE)
Alat::where('nama_alat', 'LIKE', '%laptop%')->get();
```

---

### 🎯 Eager Loading vs Lazy Loading

**N+1 Problem:**

```php
// ❌ BAD: Lazy Loading (N+1 queries)
$peminjaman = Peminjaman::all(); // 1 query
foreach ($peminjaman as $item) {
    echo $item->user->name; // N queries (1 untuk setiap peminjaman)
    echo $item->alat->nama_alat; // N queries
}
// Total: 1 + (N × 2) queries

// ✅ GOOD: Eager Loading (2 queries saja)
$peminjaman = Peminjaman::with(['user', 'alat'])->all(); // 1 + 2 = 3 queries
foreach ($peminjaman as $item) {
    echo $item->user->name; // Tidak ada query tambahan
    echo $item->alat->nama_alat; // Tidak ada query tambahan
}
// Total: 3 queries
```

**Eager Loading dengan Kondisi:**

```php
// Load relasi dengan filter
$kategori = Kategori::with(['alat' => function($query) {
    $query->where('kondisi', 'baik')
          ->where('jumlah_tersedia', '>', 0);
}])->get();

// Load nested relasi
$peminjaman = Peminjaman::with(['user', 'alat.kategori'])->get();
```

---

### 📝 Latihan

Buat file testing di `routes/web.php`:

```php
Route::get('/test-model', function () {
    // 1. Buat kategori baru
    $kategori = Kategori::create([
        'nama_kategori' => 'Elektronik',
        'deskripsi' => 'Alat-alat elektronik'
    ]);
    
    // 2. Buat alat baru
    $alat = Alat::create([
        'kode_alat' => 'ELK001',
        'nama_alat' => 'Laptop ASUS',
        'kategori_id' => $kategori->id,
        'merk' => 'ASUS',
        'kondisi' => 'baik',
        'jumlah_total' => 5,
        'jumlah_tersedia' => 5,
        'spesifikasi' => 'Intel i5, RAM 8GB'
    ]);
    
    // 3. Ambil data dengan relasi
    $kategori_with_alat = Kategori::with('alat')->first();
    
    return [
        'kategori' => $kategori,
        'alat' => $alat,
        'kategori_with_alat' => $kategori_with_alat
    ];
});
```

Akses: http://localhost:8000/test-model

---

### 🎯 Rangkuman

Di bagian ini Anda sudah belajar:

✅ Konsep Model dan Eloquent ORM  
✅ Membuat Model  
✅ Mass Assignment dan Protected Properties  
✅ Relasi antar Model (hasOne, hasMany, belongsTo)  
✅ CRUD dengan Eloquent  
✅ Query Builder  
✅ Accessor dan Scope  
✅ Eager Loading vs Lazy Loading  

**Langkah Selanjutnya:**

Di bagian 4, kita akan belajar:
- Seeding data awal
- Factory untuk generate dummy data
- Authentication (Login/Register)
- Middleware untuk proteksi route

---

*Tetap semangat! Anda sudah menguasai fondasi Laravel! 🚀*
