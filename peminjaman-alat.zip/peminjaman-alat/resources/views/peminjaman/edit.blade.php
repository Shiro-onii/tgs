@extends('layouts.app')
@section('title', 'Edit Peminjaman')

@section('content')
<h3>Edit Peminjaman</h3>

<form action="{{ route('peminjaman.update', $peminjaman->id) }}" method="POST">
    @csrf
    @method('PUT')

    <div class="mb-3">
        <label>Alat</label>
        <select name="alat_id" class="form-select" disabled>
            <option value="{{ $peminjaman->alat->id }}">{{ $peminjaman->alat->nama_alat }}</option>
        </select>
    </div>

    <div class="mb-3">
        <label>Jumlah Pinjam</label>
        <input type="number" class="form-control" value="{{ $peminjaman->jumlah_pinjam }}" disabled>
    </div>

    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-select" required>
            <option value="menunggu" {{ $peminjaman->status == 'menunggu' ? 'selected' : '' }}>Menunggu</option>
            <option value="dipinjam" {{ $peminjaman->status == 'dipinjam' ? 'selected' : '' }}>Dipinjam</option>
            <option value="dikembalikan" {{ $peminjaman->status == 'dikembalikan' ? 'selected' : '' }}>Dikembalikan</option>
            <option value="ditolak" {{ $peminjaman->status == 'ditolak' ? 'selected' : '' }}>Ditolak</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    <a href="{{ route('peminjaman.index') }}" class="btn btn-secondary">Batal</a>
</form>
@endsection
