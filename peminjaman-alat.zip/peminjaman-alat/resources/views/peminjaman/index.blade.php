@extends('layouts.app')
@section('title', 'Daftar Peminjaman')

@section('content')
<h3>Daftar Peminjaman</h3>

<a href="{{ route('peminjaman.create') }}" class="btn btn-primary btn-sm mb-3">+ Ajukan Peminjaman</a>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Alat</th>
            <th>Jumlah</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        @forelse($peminjaman as $p)
        <tr>
            <td>{{ $p->kode_peminjaman }}</td>
            <td>{{ $p->alat->nama_alat ?? '-' }}</td>
            <td>{{ $p->jumlah_pinjam }}</td>
            <td>{{ $p->tanggal_pinjam->format('d/m/Y') }}</td>
            <td>{{ $p->tanggal_kembali_rencana->format('d/m/Y') }}</td>
            <td>
                @if($p->status == 'menunggu')
                    <span class="badge bg-warning text-dark">Menunggu</span>
                @elseif($p->status == 'dipinjam')
                    <span class="badge bg-success">Dipinjam</span>
                @elseif($p->status == 'dikembalikan')
                    <span class="badge bg-primary">Dikembalikan</span>
                @else
                    <span class="badge bg-danger">Ditolak</span>
                @endif
            </td>
        </tr>
        @empty
        <tr><td colspan="6" class="text-center">Belum ada peminjaman</td></tr>
        @endforelse
    </tbody>
</table>
@endsection
