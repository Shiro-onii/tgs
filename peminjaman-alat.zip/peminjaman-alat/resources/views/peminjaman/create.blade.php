@extends('layouts.app')
@section('title', 'Ajukan Peminjaman')

@section('content')
<h3>Ajukan Peminjaman</h3>

<form action="{{ route('peminjaman.store') }}" method="POST">
    @csrf

    <div class="mb-3">
        <label>Alat</label>
        <select name="alat_id" class="form-select" required>
            <option value="">-- Pilih Alat --</option>
            @foreach($alat as $a)
            <option value="{{ $a->id }}">{{ $a->nama_alat }} (tersedia: {{ $a->jumlah_tersedia }})</option>
            @endforeach
        </select>
    </div>

    <div class="mb-3">
        <label>Jumlah Pinjam</label>
        <input type="number" name="jumlah_pinjam" class="form-control" value="1" required>
    </div>

    <div class="mb-3">
        <label>Tanggal Pinjam</label>
        <input type="date" name="tanggal_pinjam" class="form-control" value="{{ date('Y-m-d') }}" required>
    </div>

    <div class="mb-3">
        <label>Tanggal Kembali Rencana</label>
        <input type="date" name="tanggal_kembali_rencana" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-success">Kirim Permintaan</button>
    <a href="{{ route('peminjaman.index') }}" class="btn btn-secondary">Batal</a>
</form>
@endsection
