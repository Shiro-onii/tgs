@extends('layouts.app')

@section('title', 'Daftar Kategori')

@push('styles')
<style>
    .kategori-card { 
        transition: all 0.3s; 
    }
    .kategori-card:hover { 
        transform: translateY(-5px); 
    }
</style>
@endpush

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1>Daftar Kategori</h1>
            <a href="{{ route('kategori.create') }}" class="btn btn-primary">
                Tambah Kategori
            </a>
        </div>
        
        <div class="card">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <th>Jumlah Alat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($kategoris as $kategori)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $kategori->nama_kategori }}</td>
                                <td>{{ $kategori->deskripsi ?? '-' }}</td>
                                <td>{{ $kategori->alat_count ?? 0 }}</td>
                                <td>
                                    <a href="{{ route('kategori.show', $kategori) }}" 
                                       class="btn btn-sm btn-info">
                                        Detail
                                    </a>
                                    <a href="{{ route('kategori.edit', $kategori) }}" 
                                       class="btn btn-sm btn-warning">
                                        Edit
                                    </a>
                                    <form action="{{ route('kategori.destroy', $kategori) }}" 
                                          method="POST" 
                                          class="d-inline"
                                          onsubmit="return confirm('Yakin ingin menghapus?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center">
                                    Tidak ada data kategori
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
                
                {{-- Pagination --}}
                {{ $kategoris->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    console.log('Kategori page loaded');
</script>
@endpush