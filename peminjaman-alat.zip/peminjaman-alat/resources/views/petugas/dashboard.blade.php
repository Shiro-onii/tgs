@extends('layouts.app')
@section('title', 'Dashboard Petugas')

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="mb-3">Dashboard Petugas</h3>
        <p>Selamat datang, <strong>{{ auth()->user()->name }}</strong>!</p>
        <p>Gunakan halaman ini untuk memverifikasi peminjaman dan mencetak laporan.</p>
        <hr>

        <a href="{{ route('petugas.verifikasi.index') }}" class="btn btn-primary btn-sm">
            Verifikasi Peminjaman
        </a>
        <a href="{{ route('petugas.laporan.index') }}" class="btn btn-success btn-sm">
            Laporan Peminjaman
        </a>
    </div>
</div>
@endsection
