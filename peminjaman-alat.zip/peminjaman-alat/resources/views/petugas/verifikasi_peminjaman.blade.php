@extends('layouts.app')
@section('title', 'Verifikasi Peminjaman')

@section('content')
<h3 class="mb-3">Verifikasi Peminjaman</h3>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Peminjam</th>
            <th>Alat</th>
            <th>Jumlah</th>
            <th>Tanggal Pinjam</th>
            <th>Status</th>
            <th>Catatan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($peminjaman as $p)
        <tr>
            <td>{{ $p->kode_peminjaman }}</td>
            <td>{{ $p->user->name ?? '-' }}</td>
            <td>{{ $p->alat->nama_alat ?? '-' }}</td>
            <td>{{ $p->jumlah_pinjam }}</td>
            <td>{{ $p->tanggal_pinjam->format('d/m/Y') }}</td>
            <td>
                @if($p->status == 'menunggu')
                    <span class="badge bg-warning text-dark">Menunggu</span>
                @elseif($p->status == 'dipinjam')
                    <span class="badge bg-success">Dipinjam</span>
                @elseif($p->status == 'ditolak')
                    <span class="badge bg-danger">Ditolak</span>
                @else
                    <span class="badge bg-secondary">{{ ucfirst($p->status) }}</span>
                @endif
            </td>
            <td>{{ $p->catatan_petugas ?? '-' }}</td>
            <td>
                @if($p->status === 'menunggu')
                <form action="{{ route('petugas.verifikasi.update', $p->id) }}" method="POST" class="d-inline">
                    @csrf
                    <input type="hidden" name="status" value="dipinjam">
                    <button type="submit" class="btn btn-success btn-sm mb-1"
                        onclick="return confirm('Setujui peminjaman ini?')">Setujui</button>
                </form>
                <form action="{{ route('petugas.verifikasi.update', $p->id) }}" method="POST" class="d-inline">
                    @csrf
                    <input type="hidden" name="status" value="ditolak">
                    <button type="submit" class="btn btn-danger btn-sm"
                        onclick="return confirm('Tolak peminjaman ini?')">Tolak</button>
                </form>
                @else
                <em>-</em>
                @endif
            </td>
        </tr>
        @empty
        <tr><td colspan="8" class="text-center">Belum ada data peminjaman</td></tr>
        @endforelse
    </tbody>
</table>
@endsection
