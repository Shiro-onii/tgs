<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Peminjaman Alat</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        th { background-color: #ddd; }
        h3 { text-align: center; margin-bottom: 5px; }
        .periode { text-align: center; font-size: 11px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h3>Laporan Peminjaman & Pengembalian Alat</h3>
    @if($tanggal_awal && $tanggal_akhir)
        <div class="periode">Periode: {{ date('d/m/Y', strtotime($tanggal_awal)) }} - {{ date('d/m/Y', strtotime($tanggal_akhir)) }}</div>
    @endif

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Peminjam</th>
                <th>Alat</th>
                <th>Jumlah</th>
                <th>Tgl Pinjam</th>
                <th>Tgl Kembali</th>
            </tr>
        </thead>
        <tbody>
            @foreach($peminjaman as $i => $p)
            <tr>
                <td>{{ $i+1 }}</td>
                <td>{{ $p->kode_peminjaman }}</td>
                <td>{{ $p->user->name }}</td>
                <td>{{ $p->alat->nama_alat }}</td>
                <td>{{ $p->jumlah_pinjam }}</td>
                <td>{{ $p->tanggal_pinjam->format('d/m/Y') }}</td>
                <td>{{ $p->tanggal_kembali_aktual?->format('d/m/Y') ?? '-' }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <p style="margin-top:20px; text-align:right;">
        Dicetak pada: {{ now()->format('d/m/Y H:i') }}
    </p>
</body>
</html>
