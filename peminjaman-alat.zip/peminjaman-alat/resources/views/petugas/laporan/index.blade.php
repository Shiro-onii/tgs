@extends('layouts.app')
@section('title', 'Laporan Peminjaman & Pengembalian')

@section('content')
<h3>Laporan Peminjaman & Pengembalian</h3>

<form method="GET" action="{{ route('petugas.laporan.index') }}" class="row g-3 mb-3">
    <div class="col-md-4">
        <label>Tanggal Awal</label>
        <input type="date" name="tanggal_awal" class="form-control" value="{{ $tanggal_awal }}">
    </div>
    <div class="col-md-4">
        <label>Tanggal Akhir</label>
        <input type="date" name="tanggal_akhir" class="form-control" value="{{ $tanggal_akhir }}">
    </div>
    <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary me-2">Filter</button>
        <a href="{{ route('petugas.laporan.cetak', request()->all()) }}" target="_blank" class="btn btn-success">Cetak PDF</a>
    </div>
</form>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Peminjam</th>
            <th>Alat</th>
            <th>Jumlah</th>
            <th>Tgl Pinjam</th>
            <th>Tgl Kembali</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        @forelse($peminjaman as $p)
        <tr>
            <td>{{ $p->kode_peminjaman }}</td>
            <td>{{ $p->user->name }}</td>
            <td>{{ $p->alat->nama_alat }}</td>
            <td>{{ $p->jumlah_pinjam }}</td>
            <td>{{ $p->tanggal_pinjam->format('d/m/Y') }}</td>
            <td>{{ $p->tanggal_kembali_aktual?->format('d/m/Y') ?? '-' }}</td>
            <td><span class="badge bg-success">Dikembalikan</span></td>
        </tr>
        @empty
        <tr><td colspan="7" class="text-center">Tidak ada data</td></tr>
        @endforelse
    </tbody>
</table>
@endsection
