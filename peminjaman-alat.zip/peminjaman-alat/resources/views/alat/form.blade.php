<div class="mb-3">
    <label>Kode Alat</label>
    <input type="text" name="kode_alat" class="form-control" value="{{ old('kode_alat', $alat->kode_alat ?? '') }}" required>
</div>

<div class="mb-3">
    <label>Nama Alat</label>
    <input type="text" name="nama_alat" class="form-control" value="{{ old('nama_alat', $alat->nama_alat ?? '') }}" required>
</div>

<div class="mb-3">
    <label>Kategori</label>
    <select name="kategori_id" class="form-select" required>
        <option value="">-- Pilih Kategori --</option>
        @foreach($kategori as $k)
        <option value="{{ $k->id }}" {{ old('kategori_id', $alat->kategori_id ?? '') == $k->id ? 'selected' : '' }}>
            {{ $k->nama_kategori }}
        </option>
        @endforeach
    </select>
</div>

<div class="mb-3">
    <label>Merk</label>
    <input type="text" name="merk" class="form-control" value="{{ old('merk', $alat->merk ?? '') }}">
</div>

<div class="mb-3">
    <label>Kondisi</label>
    <select name="kondisi" class="form-select">
        <option value="baik" {{ old('kondisi', $alat->kondisi ?? '') == 'baik' ? 'selected' : '' }}>Baik</option>
        <option value="rusak" {{ old('kondisi', $alat->kondisi ?? '') == 'rusak' ? 'selected' : '' }}>Rusak</option>
    </select>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label>Jumlah Total</label>
        <input type="number" name="jumlah_total" class="form-control" value="{{ old('jumlah_total', $alat->jumlah_total ?? 1) }}" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Jumlah Tersedia</label>
        <input type="number" name="jumlah_tersedia" class="form-control" value="{{ old('jumlah_tersedia', $alat->jumlah_tersedia ?? 0) }}" required>
    </div>
</div>

<div class="mb-3">
    <label>Spesifikasi</label>
    <textarea name="spesifikasi" class="form-control">{{ old('spesifikasi', $alat->spesifikasi ?? '') }}</textarea>
</div>
