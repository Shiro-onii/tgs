@extends('layouts.app')
@section('title', 'Edit Alat')

@section('content')
<h3>Edit Alat</h3>
<form action="{{ route('alat.update', $alat->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    @include('alat.form', ['alat' => $alat])
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <a href="{{ route('alat.index') }}" class="btn btn-secondary">Batal</a>
</form>
@endsection
