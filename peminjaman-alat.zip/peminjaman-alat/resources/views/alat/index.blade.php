@extends('layouts.app')
@section('title', 'Daftar Alat')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Alat</h3>

    {{-- Tombol tambah hanya untuk admin --}}
    @if(auth()->user()->isAdmin())
        <a href="{{ route('alat.create') }}" class="btn btn-primary btn-sm">+ Tambah Alat</a>
    @endif
</div>

<table class="table table-striped table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Nama</th>
            <th>Kategori</th>
            <th>Kondisi</th>
            <th>Tersedia</th>
            @if(auth()->user()->isAdmin())
                <th>Aksi</th>
            @elseif(auth()->user()->isPeminjam())
                <th>Aksi</th>
            @endif
        </tr>
    </thead>
    <tbody>
        @forelse($alat as $a)
        <tr>
            <td>{{ $a->kode_alat }}</td>
            <td>{{ $a->nama_alat }}</td>
            <td>{{ $a->kategori->nama_kategori ?? '-' }}</td>
            <td>{{ ucfirst($a->kondisi) }}</td>
            <td>{{ $a->jumlah_tersedia }}</td>

            {{-- TOMBOL SESUAI ROLE --}}
            <td>
                @if(auth()->user()->isAdmin())
                    <a href="{{ route('alat.edit', $a->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('alat.destroy', $a->id) }}" method="POST" class="d-inline">
                        @csrf @method('DELETE')
                        <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
                    </form>
                @elseif(auth()->user()->isPeminjam())
                    <a href="{{ route('peminjaman.create', ['alat_id' => $a->id]) }}" class="btn btn-success btn-sm">
                        Pinjam
                    </a>
                @endif
            </td>
        </tr>
        @empty
        <tr><td colspan="7" class="text-center">Belum ada alat</td></tr>
        @endforelse
    </tbody>
</table>

<div class="mt-3">
    {{ $alat->links() }}
</div>
@endsection
