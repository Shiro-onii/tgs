@extends('layouts.app')
@section('title', 'Tambah Alat')

@section('content')
<h3>Tambah Alat</h3>
<form action="{{ route('alat.store') }}" method="POST" enctype="multipart/form-data">
    @csrf
    @include('alat.form')
    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="{{ route('alat.index') }}" class="btn btn-secondary">Batal</a>
</form>
@endsection
