@extends('layouts.app')
@section('title', 'Edit User')

@section('content')
<h3>Edit User</h3>
<form action="{{ route('user.update', $user->id) }}" method="POST">
    @csrf
    @method('PUT')
    @include('user.form', ['user' => $user])
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <a href="{{ route('user.index') }}" class="btn btn-secondary">Batal</a>
</form>
@endsection
