@extends('layouts.app')
@section('title', 'Log Aktivitas')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Log Aktivitas</h3>
    <form action="{{ route('activity_log.clear') }}" method="POST" onsubmit="return confirm('Hapus semua log?')">
        @csrf
        @method('DELETE')
        <button class="btn btn-danger btn-sm">Hapus Semua Log</button>
    </form>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Waktu</th>
            <th>User</th>
            <th>Aktivitas</th>
            <th>Deskripsi</th>
            <th>IP</th>
            <th>Browser</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($logs as $index => $log)
        <tr>
            <td>{{ $logs->firstItem() + $index }}</td>
            <td>{{ $log->created_at->format('d/m/Y H:i:s') }}</td>
            <td>{{ $log->user->name ?? '-' }} ({{ $log->user->role ?? '-' }})</td>
            <td>{{ $log->activity }}</td>
            <td>{{ $log->description }}</td>
            <td>{{ $log->ip_address }}</td>
            <td style="max-width: 200px; word-wrap:break-word;">{{ $log->user_agent }}</td>
            <td>
                <form action="{{ route('activity_log.destroy', $log->id) }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-sm btn-danger" onclick="return confirm('Hapus log ini?')">Hapus</button>
                </form>
            </td>
        </tr>
        @empty
        <tr><td colspan="8" class="text-center">Belum ada log aktivitas</td></tr>
        @endforelse
    </tbody>
</table>

<div class="mt-3">
    {{ $logs->links() }}
</div>
@endsection
