@extends('layouts.app')
@section('title', 'Dashboard Admin')

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="mb-3">Dashboard Admin</h3>
        <p>Selamat datang, <strong>{{ auth()->user()->name }}</strong>!</p>
        <p>Gunakan halaman ini untuk mengelola data kategori, alat, dan peminjaman.</p>
        <hr>
        <a href="{{ url('/kategori') }}" class="btn btn-primary btn-sm">Kelola Kategori</a>
        <a href="{{ url('/alat') }}" class="btn btn-success btn-sm">Kelola Alat</a>
        <a href="{{ url('/peminjaman') }}" class="btn btn-warning btn-sm">Kelola Peminjaman</a>
        <a href="{{ url('/pengembalian') }}" class="btn btn-info btn-sm">Kelola Pengembalian</a>
        <a href="{{ url('/user') }}" class="btn btn-secondary btn-sm">Kelola User</a>
    </div>
</div>
@endsection
