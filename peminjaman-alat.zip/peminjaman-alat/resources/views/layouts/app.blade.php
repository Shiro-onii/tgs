<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Sistem Peminjaman Alat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Peminjaman Alat</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            @auth
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                {{-- ========== MENU ADMIN ========== --}}
                @if(auth()->user()->isAdmin())
                    <li class="nav-item"><a class="nav-link" href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('user.index') }}">User</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('alat.index') }}">Alat</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('kategori.index') }}">Kategori</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjaman.index') }}">Peminjaman</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('pengembalian.index') }}">Pengembalian</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('activity_log.index') }}">Log Aktivitas</a></li>

                {{-- ========== MENU PETUGAS ========== --}}
                @elseif(auth()->user()->isPetugas())
                    <li class="nav-item"><a class="nav-link" href="{{ route('petugas.dashboard') }}">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('petugas.verifikasi.index') }}">Verifikasi Peminjaman</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('petugas.laporan.index') }}">Laporan</a></li>

                {{-- ========== MENU PEMINJAM ========== --}}
                @elseif(auth()->user()->isPeminjam())
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjam.dashboard') }}">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjam.alat.index') }}">Lihat Alat</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjaman.index') }}">Peminjaman Saya</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('pengembalian.index') }}">Pengembalian</a></li>
                @endif
            </ul>
            @endauth

            <div class="ms-auto d-flex align-items-center text-white">
                @auth
                    <span class="me-3">{{ auth()->user()->name }} ({{ ucfirst(auth()->user()->role) }})</span>
                    <form action="{{ route('logout') }}" method="POST" class="d-inline">
                        @csrf
                        <button class="btn btn-outline-light btn-sm" type="submit">Logout</button>
                    </form>
                @endauth
            </div>
        </div>
    </div>
</nav>

<div class="container mt-4">
    {{-- Alert message --}}
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    {{-- Main content --}}
    @yield('content')
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
