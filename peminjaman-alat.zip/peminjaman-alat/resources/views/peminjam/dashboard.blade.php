@extends('layouts.app')
@section('title', 'Dashboard Peminjam')

@section('content')
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="mb-3">Dashboard Peminjam</h3>
        <p>Selamat datang, <strong>{{ auth()->user()->name }}</strong>!</p>
        <p>Gunakan halaman ini untuk melihat alat, meminjam, dan mengembalikan alat.</p>
        <hr>

        <a href="{{ route('peminjam.alat.index') }}" class="btn btn-success btn-sm">
            Lihat Alat
        </a>
        <a href="{{ route('peminjaman.index') }}" class="btn btn-primary btn-sm">
            Peminjaman Saya
        </a>
        <a href="{{ route('pengembalian.index') }}" class="btn btn-warning btn-sm text-white">
            Pengembalian
        </a>
    </div>
</div>
@endsection
