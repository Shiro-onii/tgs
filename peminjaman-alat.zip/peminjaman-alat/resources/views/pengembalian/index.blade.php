@extends('layouts.app')
@section('title', 'Daftar Pengembalian')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Pengembalian</h3>

    @if(auth()->user()->isPeminjam())
        <a href="{{ route('pengembalian.create') }}" class="btn btn-primary btn-sm">+ Tambah Pengembalian</a>
    @endif
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode Peminjaman</th>
            <th>Alat</th>
            <th>Peminjam</th>
            <th>Tanggal Pengembalian</th>
            <th>Jumlah</th>
            <th>Kondisi</th>
            <th>Denda</th>
            <th>Keterangan</th>
            <th>Diterima Oleh</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($pengembalian as $p)
        <tr>
            <td>{{ $p->peminjaman->kode_peminjaman ?? '-' }}</td>
            <td>{{ $p->peminjaman->alat->nama_alat ?? '-' }}</td>
            <td>{{ $p->peminjaman->user->name ?? '-' }}</td>
            <td>{{ \Carbon\Carbon::parse($p->tanggal_pengembalian)->format('d/m/Y') }}</td>
            <td>{{ $p->jumlah_dikembalikan }}</td>
            <td>{{ ucfirst($p->kondisi_alat) }}</td>
            <td>{{ $p->denda ? 'Rp ' . number_format($p->denda, 0, ',', '.') : '-' }}</td>
            <td>{{ $p->keterangan ?? '-' }}</td>
            <td>{{ $p->diterimaOleh->name ?? '-' }}</td>
            <td>
                @if(auth()->user()->isAdmin())
                <form action="{{ route('pengembalian.destroy', $p->id) }}" method="POST" class="d-inline">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus data ini?')">Hapus</button>
                </form>
                @else
                <em>-</em>
                @endif
            </td>
        </tr>
        @empty
        <tr><td colspan="10" class="text-center">Belum ada data pengembalian</td></tr>
        @endforelse
    </tbody>
</table>
@endsection
