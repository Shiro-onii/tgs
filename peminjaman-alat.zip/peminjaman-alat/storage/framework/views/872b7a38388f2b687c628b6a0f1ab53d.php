
<?php $__env->startSection('title', 'Daftar Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<h3>Daftar Peminjaman</h3>

<a href="<?php echo e(route('peminjaman.create')); ?>" class="btn btn-primary btn-sm mb-3">+ Ajukan Peminjaman</a>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Alat</th>
            <th>Jumlah</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->kode_peminjaman); ?></td>
            <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
            <td><?php echo e($p->jumlah_pinjam); ?></td>
            <td><?php echo e($p->tanggal_pinjam->format('d/m/Y')); ?></td>
            <td><?php echo e($p->tanggal_kembali_rencana->format('d/m/Y')); ?></td>
            <td>
                <?php if($p->status == 'menunggu'): ?>
                    <span class="badge bg-warning text-dark">Menunggu</span>
                <?php elseif($p->status == 'dipinjam'): ?>
                    <span class="badge bg-success">Dipinjam</span>
                <?php elseif($p->status == 'dikembalikan'): ?>
                    <span class="badge bg-primary">Dikembalikan</span>
                <?php else: ?>
                    <span class="badge bg-danger">Ditolak</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="text-center">Belum ada peminjaman</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjaman/index.blade.php ENDPATH**/ ?>