
<?php $__env->startSection('title', 'Verifikasi Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="mb-3">Verifikasi Peminjaman</h3>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Peminjam</th>
            <th>Alat</th>
            <th>Jumlah</th>
            <th>Tanggal Pinjam</th>
            <th>Status</th>
            <th>Catatan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->kode_peminjaman); ?></td>
            <td><?php echo e($p->user->name ?? '-'); ?></td>
            <td><?php echo e($p->alat->nama_alat ?? '-'); ?></td>
            <td><?php echo e($p->jumlah_pinjam); ?></td>
            <td><?php echo e($p->tanggal_pinjam->format('d/m/Y')); ?></td>
            <td>
                <?php if($p->status == 'menunggu'): ?>
                    <span class="badge bg-warning text-dark">Menunggu</span>
                <?php elseif($p->status == 'dipinjam'): ?>
                    <span class="badge bg-success">Dipinjam</span>
                <?php elseif($p->status == 'ditolak'): ?>
                    <span class="badge bg-danger">Ditolak</span>
                <?php else: ?>
                    <span class="badge bg-secondary"><?php echo e(ucfirst($p->status)); ?></span>
                <?php endif; ?>
            </td>
            <td><?php echo e($p->catatan_petugas ?? '-'); ?></td>
            <td>
                <?php if($p->status === 'menunggu'): ?>
                <form action="<?php echo e(route('petugas.verifikasi.update', $p->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="dipinjam">
                    <button type="submit" class="btn btn-success btn-sm mb-1"
                        onclick="return confirm('Setujui peminjaman ini?')">Setujui</button>
                </form>
                <form action="<?php echo e(route('petugas.verifikasi.update', $p->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="ditolak">
                    <button type="submit" class="btn btn-danger btn-sm"
                        onclick="return confirm('Tolak peminjaman ini?')">Tolak</button>
                </form>
                <?php else: ?>
                <em>-</em>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="text-center">Belum ada data peminjaman</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/verifikasi_peminjaman.blade.php ENDPATH**/ ?>