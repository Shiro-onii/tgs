<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Peminjaman Alat</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        th { background-color: #ddd; }
        h3 { text-align: center; margin-bottom: 5px; }
        .periode { text-align: center; font-size: 11px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h3>Laporan Peminjaman & Pengembalian Alat</h3>
    <?php if($tanggal_awal && $tanggal_akhir): ?>
        <div class="periode">Periode: <?php echo e(date('d/m/Y', strtotime($tanggal_awal))); ?> - <?php echo e(date('d/m/Y', strtotime($tanggal_akhir))); ?></div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Peminjam</th>
                <th>Alat</th>
                <th>Jumlah</th>
                <th>Tgl Pinjam</th>
                <th>Tgl Kembali</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i+1); ?></td>
                <td><?php echo e($p->kode_peminjaman); ?></td>
                <td><?php echo e($p->user->name); ?></td>
                <td><?php echo e($p->alat->nama_alat); ?></td>
                <td><?php echo e($p->jumlah_pinjam); ?></td>
                <td><?php echo e($p->tanggal_pinjam->format('d/m/Y')); ?></td>
                <td><?php echo e($p->tanggal_kembali_aktual?->format('d/m/Y') ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <p style="margin-top:20px; text-align:right;">
        Dicetak pada: <?php echo e(now()->format('d/m/Y H:i')); ?>

    </p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/laporan/pdf.blade.php ENDPATH**/ ?>