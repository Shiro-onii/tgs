
<?php $__env->startSection('title', 'Ajukan Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<h3>Ajukan Peminjaman</h3>

<form action="<?php echo e(route('peminjaman.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label>Alat</label>
        <select name="alat_id" class="form-select" required>
            <option value="">-- Pilih Alat --</option>
            <?php $__currentLoopData = $alat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($a->id); ?>"><?php echo e($a->nama_alat); ?> (tersedia: <?php echo e($a->jumlah_tersedia); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Jumlah Pinjam</label>
        <input type="number" name="jumlah_pinjam" class="form-control" value="1" required>
    </div>

    <div class="mb-3">
        <label>Tanggal Pinjam</label>
        <input type="date" name="tanggal_pinjam" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
    </div>

    <div class="mb-3">
        <label>Tanggal Kembali Rencana</label>
        <input type="date" name="tanggal_kembali_rencana" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-success">Kirim Permintaan</button>
    <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-secondary">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjaman/create.blade.php ENDPATH**/ ?>