
<?php $__env->startSection('title', 'Daftar Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Pengembalian</h3>

    <?php if(auth()->user()->isPeminjam()): ?>
        <a href="<?php echo e(route('pengembalian.create')); ?>" class="btn btn-primary btn-sm">+ Tambah Pengembalian</a>
    <?php endif; ?>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode Peminjaman</th>
            <th>Alat</th>
            <th>Peminjam</th>
            <th>Tanggal Pengembalian</th>
            <th>Jumlah</th>
            <th>Kondisi</th>
            <th>Denda</th>
            <th>Keterangan</th>
            <th>Diterima Oleh</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pengembalian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->peminjaman->kode_peminjaman ?? '-'); ?></td>
            <td><?php echo e($p->peminjaman->alat->nama_alat ?? '-'); ?></td>
            <td><?php echo e($p->peminjaman->user->name ?? '-'); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($p->tanggal_pengembalian)->format('d/m/Y')); ?></td>
            <td><?php echo e($p->jumlah_dikembalikan); ?></td>
            <td><?php echo e(ucfirst($p->kondisi_alat)); ?></td>
            <td><?php echo e($p->denda ? 'Rp ' . number_format($p->denda, 0, ',', '.') : '-'); ?></td>
            <td><?php echo e($p->keterangan ?? '-'); ?></td>
            <td><?php echo e($p->diterimaOleh->name ?? '-'); ?></td>
            <td>
                <?php if(auth()->user()->isAdmin()): ?>
                <form action="<?php echo e(route('pengembalian.destroy', $p->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus data ini?')">Hapus</button>
                </form>
                <?php else: ?>
                <em>-</em>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="10" class="text-center">Belum ada data pengembalian</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/pengembalian/index.blade.php ENDPATH**/ ?>