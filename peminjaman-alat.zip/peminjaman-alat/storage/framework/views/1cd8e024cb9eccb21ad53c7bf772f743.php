

<?php $__env->startSection('title', 'Daftar Kategori'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .kategori-card { 
        transition: all 0.3s; 
    }
    .kategori-card:hover { 
        transform: translateY(-5px); 
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1>Daftar Kategori</h1>
            <a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary">
                Tambah Kategori
            </a>
        </div>
        
        <div class="card">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <th>Jumlah Alat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($kategori->nama_kategori); ?></td>
                                <td><?php echo e($kategori->deskripsi ?? '-'); ?></td>
                                <td><?php echo e($kategori->alat_count ?? 0); ?></td>
                                <td>
                                    <a href="<?php echo e(route('kategori.show', $kategori)); ?>" 
                                       class="btn btn-sm btn-info">
                                        Detail
                                    </a>
                                    <a href="<?php echo e(route('kategori.edit', $kategori)); ?>" 
                                       class="btn btn-sm btn-warning">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('kategori.destroy', $kategori)); ?>" 
                                          method="POST" 
                                          class="d-inline"
                                          onsubmit="return confirm('Yakin ingin menghapus?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center">
                                    Tidak ada data kategori
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                
                <?php echo e($kategoris->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    console.log('Kategori page loaded');
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/kategori/index.blade.php ENDPATH**/ ?>