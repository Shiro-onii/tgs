
<?php $__env->startSection('title', 'Daftar Alat'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Alat</h3>

    
    <?php if(auth()->user()->isAdmin()): ?>
        <a href="<?php echo e(route('alat.create')); ?>" class="btn btn-primary btn-sm">+ Tambah Alat</a>
    <?php endif; ?>
</div>

<table class="table table-striped table-bordered">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Nama</th>
            <th>Kategori</th>
            <th>Kondisi</th>
            <th>Tersedia</th>
            <?php if(auth()->user()->isAdmin()): ?>
                <th>Aksi</th>
            <?php elseif(auth()->user()->isPeminjam()): ?>
                <th>Aksi</th>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $alat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($a->kode_alat); ?></td>
            <td><?php echo e($a->nama_alat); ?></td>
            <td><?php echo e($a->kategori->nama_kategori ?? '-'); ?></td>
            <td><?php echo e(ucfirst($a->kondisi)); ?></td>
            <td><?php echo e($a->jumlah_tersedia); ?></td>

            
            <td>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a href="<?php echo e(route('alat.edit', $a->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('alat.destroy', $a->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
                    </form>
                <?php elseif(auth()->user()->isPeminjam()): ?>
                    <a href="<?php echo e(route('peminjaman.create', ['alat_id' => $a->id])); ?>" class="btn btn-success btn-sm">
                        Pinjam
                    </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="text-center">Belum ada alat</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="mt-3">
    <?php echo e($alat->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/alat/index.blade.php ENDPATH**/ ?>