
<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
<h3>Edit User</h3>
<form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('user.form', ['user' => $user], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/user/edit.blade.php ENDPATH**/ ?>