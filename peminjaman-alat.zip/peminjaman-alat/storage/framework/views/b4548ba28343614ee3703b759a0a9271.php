<div class="mb-3">
    <label>Nama</label>
    <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Email</label>
    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $user->email ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Role</label>
    <select name="role" class="form-select" required>
        <option value="">-- Pilih Role --</option>
        <option value="admin" <?php echo e(old('role', $user->role ?? '') == 'admin' ? 'selected' : ''); ?>>Admin</option>
        <option value="petugas" <?php echo e(old('role', $user->role ?? '') == 'petugas' ? 'selected' : ''); ?>>Petugas</option>
        <option value="peminjam" <?php echo e(old('role', $user->role ?? '') == 'peminjam' ? 'selected' : ''); ?>>Peminjam</option>
    </select>
</div>

<div class="mb-3">
    <label>Password</label>
    <input type="password" name="password" class="form-control" <?php echo e(isset($user) ? '' : 'required'); ?>>
</div>

<div class="mb-3">
    <label>Konfirmasi Password</label>
    <input type="password" name="password_confirmation" class="form-control" <?php echo e(isset($user) ? '' : 'required'); ?>>
</div>

<div class="mb-3">
    <label>Telepon</label>
    <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $user->phone ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Alamat</label>
    <textarea name="address" class="form-control"><?php echo e(old('address', $user->address ?? '')); ?></textarea>
</div>
<?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/user/form.blade.php ENDPATH**/ ?>