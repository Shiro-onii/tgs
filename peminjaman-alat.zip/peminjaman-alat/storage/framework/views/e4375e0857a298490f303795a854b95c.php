
<?php $__env->startSection('title', 'Tambah Alat'); ?>

<?php $__env->startSection('content'); ?>
<h3>Tambah Alat</h3>
<form action="<?php echo e(route('alat.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('alat.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="<?php echo e(route('alat.index')); ?>" class="btn btn-secondary">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/alat/create.blade.php ENDPATH**/ ?>