<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Sistem Peminjaman Alat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Peminjaman Alat</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <?php if(auth()->guard()->check()): ?>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                
                <?php if(auth()->user()->isAdmin()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.index')); ?>">User</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('alat.index')); ?>">Alat</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('kategori.index')); ?>">Kategori</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('peminjaman.index')); ?>">Peminjaman</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pengembalian.index')); ?>">Pengembalian</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('activity_log.index')); ?>">Log Aktivitas</a></li>

                
                <?php elseif(auth()->user()->isPetugas()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('petugas.dashboard')); ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('petugas.verifikasi.index')); ?>">Verifikasi Peminjaman</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('petugas.laporan.index')); ?>">Laporan</a></li>

                
                <?php elseif(auth()->user()->isPeminjam()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('peminjam.dashboard')); ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('peminjam.alat.index')); ?>">Lihat Alat</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('peminjaman.index')); ?>">Peminjaman Saya</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pengembalian.index')); ?>">Pengembalian</a></li>
                <?php endif; ?>
            </ul>
            <?php endif; ?>

            <div class="ms-auto d-flex align-items-center text-white">
                <?php if(auth()->guard()->check()): ?>
                    <span class="me-3"><?php echo e(auth()->user()->name); ?> (<?php echo e(ucfirst(auth()->user()->role)); ?>)</span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-light btn-sm" type="submit">Logout</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<div class="container mt-4">
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <?php echo $__env->yieldContent('content'); ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/layouts/app.blade.php ENDPATH**/ ?>