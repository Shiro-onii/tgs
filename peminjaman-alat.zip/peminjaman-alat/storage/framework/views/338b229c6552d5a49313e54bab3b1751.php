
<?php $__env->startSection('title', 'Log Aktivitas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Log Aktivitas</h3>
    <form action="<?php echo e(route('activity_log.clear')); ?>" method="POST" onsubmit="return confirm('Hapus semua log?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger btn-sm">Hapus Semua Log</button>
    </form>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Waktu</th>
            <th>User</th>
            <th>Aktivitas</th>
            <th>Deskripsi</th>
            <th>IP</th>
            <th>Browser</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($logs->firstItem() + $index); ?></td>
            <td><?php echo e($log->created_at->format('d/m/Y H:i:s')); ?></td>
            <td><?php echo e($log->user->name ?? '-'); ?> (<?php echo e($log->user->role ?? '-'); ?>)</td>
            <td><?php echo e($log->activity); ?></td>
            <td><?php echo e($log->description); ?></td>
            <td><?php echo e($log->ip_address); ?></td>
            <td style="max-width: 200px; word-wrap:break-word;"><?php echo e($log->user_agent); ?></td>
            <td>
                <form action="<?php echo e(route('activity_log.destroy', $log->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger" onclick="return confirm('Hapus log ini?')">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="text-center">Belum ada log aktivitas</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="mt-3">
    <?php echo e($logs->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/activity_log/index.blade.php ENDPATH**/ ?>