
<?php $__env->startSection('title', 'Dashboard Petugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="mb-3">Dashboard Petugas</h3>
        <p>Selamat datang, <strong><?php echo e(auth()->user()->name); ?></strong>!</p>
        <p>Gunakan halaman ini untuk memverifikasi peminjaman dan mencetak laporan.</p>
        <hr>

        <a href="<?php echo e(route('petugas.verifikasi.index')); ?>" class="btn btn-primary btn-sm">
            Verifikasi Peminjaman
        </a>
        <a href="<?php echo e(route('petugas.laporan.index')); ?>" class="btn btn-success btn-sm">
            Laporan Peminjaman
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/dashboard.blade.php ENDPATH**/ ?>