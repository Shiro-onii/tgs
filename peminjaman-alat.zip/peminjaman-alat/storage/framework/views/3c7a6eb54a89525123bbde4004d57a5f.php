<div class="mb-3">
    <label>Kode Alat</label>
    <input type="text" name="kode_alat" class="form-control" value="<?php echo e(old('kode_alat', $alat->kode_alat ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Nama Alat</label>
    <input type="text" name="nama_alat" class="form-control" value="<?php echo e(old('nama_alat', $alat->nama_alat ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Kategori</label>
    <select name="kategori_id" class="form-select" required>
        <option value="">-- Pilih Kategori --</option>
        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($k->id); ?>" <?php echo e(old('kategori_id', $alat->kategori_id ?? '') == $k->id ? 'selected' : ''); ?>>
            <?php echo e($k->nama_kategori); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-3">
    <label>Merk</label>
    <input type="text" name="merk" class="form-control" value="<?php echo e(old('merk', $alat->merk ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Kondisi</label>
    <select name="kondisi" class="form-select">
        <option value="baik" <?php echo e(old('kondisi', $alat->kondisi ?? '') == 'baik' ? 'selected' : ''); ?>>Baik</option>
        <option value="rusak" <?php echo e(old('kondisi', $alat->kondisi ?? '') == 'rusak' ? 'selected' : ''); ?>>Rusak</option>
    </select>
</div>

<div class="row">
    <div class="col-md-6 mb-3">
        <label>Jumlah Total</label>
        <input type="number" name="jumlah_total" class="form-control" value="<?php echo e(old('jumlah_total', $alat->jumlah_total ?? 1)); ?>" required>
    </div>
    <div class="col-md-6 mb-3">
        <label>Jumlah Tersedia</label>
        <input type="number" name="jumlah_tersedia" class="form-control" value="<?php echo e(old('jumlah_tersedia', $alat->jumlah_tersedia ?? 0)); ?>" required>
    </div>
</div>

<div class="mb-3">
    <label>Spesifikasi</label>
    <textarea name="spesifikasi" class="form-control"><?php echo e(old('spesifikasi', $alat->spesifikasi ?? '')); ?></textarea>
</div>
<?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/alat/form.blade.php ENDPATH**/ ?>