
<?php $__env->startSection('title', 'Laporan Peminjaman & Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<h3>Laporan Peminjaman & Pengembalian</h3>

<form method="GET" action="<?php echo e(route('petugas.laporan.index')); ?>" class="row g-3 mb-3">
    <div class="col-md-4">
        <label>Tanggal Awal</label>
        <input type="date" name="tanggal_awal" class="form-control" value="<?php echo e($tanggal_awal); ?>">
    </div>
    <div class="col-md-4">
        <label>Tanggal Akhir</label>
        <input type="date" name="tanggal_akhir" class="form-control" value="<?php echo e($tanggal_akhir); ?>">
    </div>
    <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary me-2">Filter</button>
        <a href="<?php echo e(route('petugas.laporan.cetak', request()->all())); ?>" target="_blank" class="btn btn-success">Cetak PDF</a>
    </div>
</form>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>Kode</th>
            <th>Peminjam</th>
            <th>Alat</th>
            <th>Jumlah</th>
            <th>Tgl Pinjam</th>
            <th>Tgl Kembali</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->kode_peminjaman); ?></td>
            <td><?php echo e($p->user->name); ?></td>
            <td><?php echo e($p->alat->nama_alat); ?></td>
            <td><?php echo e($p->jumlah_pinjam); ?></td>
            <td><?php echo e($p->tanggal_pinjam->format('d/m/Y')); ?></td>
            <td><?php echo e($p->tanggal_kembali_aktual?->format('d/m/Y') ?? '-'); ?></td>
            <td><span class="badge bg-success">Dikembalikan</span></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="text-center">Tidak ada data</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/petugas/laporan/index.blade.php ENDPATH**/ ?>