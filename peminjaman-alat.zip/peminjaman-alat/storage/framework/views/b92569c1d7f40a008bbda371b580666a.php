
<?php $__env->startSection('title', 'Dashboard Peminjam'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="mb-3">Dashboard Peminjam</h3>
        <p>Selamat datang, <strong><?php echo e(auth()->user()->name); ?></strong>!</p>
        <p>Gunakan halaman ini untuk melihat alat, meminjam, dan mengembalikan alat.</p>
        <hr>

        <a href="<?php echo e(route('peminjam.alat.index')); ?>" class="btn btn-success btn-sm">
            Lihat Alat
        </a>
        <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-primary btn-sm">
            Peminjaman Saya
        </a>
        <a href="<?php echo e(route('pengembalian.index')); ?>" class="btn btn-warning btn-sm text-white">
            Pengembalian
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/peminjam/dashboard.blade.php ENDPATH**/ ?>