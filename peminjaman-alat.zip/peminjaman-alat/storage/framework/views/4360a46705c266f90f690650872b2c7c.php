
<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="mb-3">Dashboard Admin</h3>
        <p>Selamat datang, <strong><?php echo e(auth()->user()->name); ?></strong>!</p>
        <p>Gunakan halaman ini untuk mengelola data kategori, alat, dan peminjaman.</p>
        <hr>
        <a href="<?php echo e(url('/kategori')); ?>" class="btn btn-primary btn-sm">Kelola Kategori</a>
        <a href="<?php echo e(url('/alat')); ?>" class="btn btn-success btn-sm">Kelola Alat</a>
        <a href="<?php echo e(url('/peminjaman')); ?>" class="btn btn-warning btn-sm">Kelola Peminjaman</a>
        <a href="<?php echo e(url('/pengembalian')); ?>" class="btn btn-info btn-sm">Kelola Pengembalian</a>
        <a href="<?php echo e(url('/user')); ?>" class="btn btn-secondary btn-sm">Kelola User</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman-alat\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>