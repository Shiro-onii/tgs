<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AlatController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PeminjamanController;
use App\Http\Controllers\PengembalianController;
use App\Http\Controllers\VerifikasiPeminjamanController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\ActivityLogController;

// ============================
// Public & Auth
// ============================
Route::get('/', fn() => view('welcome'));
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// ============================
// ADMIN
// ============================
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', [AuthController::class, 'adminDashboard'])->name('admin.dashboard');
    Route::resource('user', UserController::class);
    Route::resource('kategori', KategoriController::class);
    Route::resource('alat', AlatController::class);
    // Route::resource('peminjaman', PeminjamanController::class);
    // Route::resource('pengembalian', PengembalianController::class);
    Route::get('/activity-log', [ActivityLogController::class, 'index'])->name('activity_log.index');
    Route::delete('/activity-log/{id}', [ActivityLogController::class, 'destroy'])->name('activity_log.destroy');
    Route::delete('/activity-log', [ActivityLogController::class, 'clearAll'])->name('activity_log.clear');
});

// ============================
// PETUGAS
// ============================
Route::middleware(['auth', 'role:petugas'])->prefix('petugas')->group(function () {
    Route::get('/dashboard', [AuthController::class, 'petugasDashboard'])->name('petugas.dashboard');
    Route::get('/peminjaman', [VerifikasiPeminjamanController::class, 'index'])->name('petugas.verifikasi.index');
    Route::post('/peminjaman/{id}/update', [VerifikasiPeminjamanController::class, 'updateStatus'])->name('petugas.verifikasi.update');
    Route::get('/laporan', [LaporanController::class, 'index'])->name('petugas.laporan.index');
    Route::get('/laporan/cetak', [LaporanController::class, 'cetakPDF'])->name('petugas.laporan.cetak');
});

// ============================
// PEMINJAM
// ============================
Route::middleware(['auth', 'role:peminjam'])->prefix('peminjam')->group(function () {
    Route::get('/dashboard', [AuthController::class, 'peminjamDashboard'])->name('peminjam.dashboard');
    Route::get('/alat', [AlatController::class, 'index'])->name('peminjam.alat.index');
    // Route::resource('/peminjaman', PeminjamanController::class)->only(['index', 'create', 'store']);
    // Route::resource('/pengembalian', PengembalianController::class)->only(['index', 'create', 'store']);

    
});
Route::middleware(['auth', 'role:admin,petugas,peminjam'])->group(function () {
    
    // Shared Peminjaman Routes
    Route::resource('peminjaman', PeminjamanController::class);
    
    // Shared Pengembalian Routes
    Route::resource('pengembalian', PengembalianController::class);
    
});

