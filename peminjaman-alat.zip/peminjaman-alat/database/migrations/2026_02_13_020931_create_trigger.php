<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        // Trigger saat peminjaman disetujui
        DB::unprepared('
            DROP TRIGGER IF EXISTS update_stok_after_approve;
            
            CREATE TRIGGER update_stok_after_approve
            AFTER UPDATE ON peminjaman
            FOR EACH ROW
            BEGIN
                -- Jika status berubah dari "menunggu" ke "disetujui"
                IF OLD.status = "menunggu" AND NEW.status = "disetujui" THEN
                    -- Kurangi stok
                    UPDATE alat
                    SET jumlah_tersedia = jumlah_tersedia - NEW.jumlah_pinjam
                    WHERE id = NEW.alat_id;
                END IF;
            END
        ');
        
        // Trigger saat pengembalian
        DB::unprepared('
            DROP TRIGGER IF EXISTS update_stok_after_return;
            
            CREATE TRIGGER update_stok_after_return
            AFTER INSERT ON pengembalian
            FOR EACH ROW
            BEGIN
                DECLARE alat_id_var INT;
                
                -- Ambil alat_id dari peminjaman
                SELECT alat_id INTO alat_id_var
                FROM peminjaman
                WHERE id = NEW.peminjaman_id;
                
                -- Tambah stok kembali
                UPDATE alat
                SET jumlah_tersedia = jumlah_tersedia + NEW.jumlah_dikembalikan
                WHERE id = alat_id_var;
                
                -- Update kondisi alat jika rusak
                IF NEW.kondisi_alat != "baik" THEN
                    UPDATE alat
                    SET kondisi = NEW.kondisi_alat
                    WHERE id = alat_id_var AND kondisi = "baik";
                END IF;
            END
        ');
    }

    public function down()
    {
        DB::unprepared('DROP TRIGGER IF EXISTS update_stok_after_approve');
        DB::unprepared('DROP TRIGGER IF EXISTS update_stok_after_return');
    }
};
