<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        DB::unprepared('
            DROP PROCEDURE IF EXISTS calculate_denda;
            
            CREATE PROCEDURE calculate_denda(
                IN peminjaman_id INT,
                IN tgl_kembali_aktual DATE,
                IN kondisi_alat VARCHAR(50),
                IN jumlah_dikembalikan INT,
                OUT total_denda DECIMAL(10,2)
            )
            BEGIN
                DECLARE tgl_rencana DATE;
                DECLARE hari_terlambat INT;
                DECLARE denda_terlambat DECIMAL(10,2);
                DECLARE denda_kerusakan DECIMAL(10,2);
                
                -- Ambil tanggal kembali rencana
                SELECT tanggal_kembali_rencana INTO tgl_rencana
                FROM peminjaman
                WHERE id = peminjaman_id;
                
                -- Hitung hari terlambat
                SET hari_terlambat = GREATEST(0, DATEDIFF(tgl_kembali_aktual, tgl_rencana));
                
                -- Hitung denda keterlambatan (Rp 10.000/hari)
                SET denda_terlambat = hari_terlambat * 10000;
                
                -- Hitung denda kerusakan
                SET denda_kerusakan = 0;
                IF kondisi_alat = "rusak_ringan" THEN
                    SET denda_kerusakan = 50000 * jumlah_dikembalikan;
                ELSEIF kondisi_alat = "rusak_berat" THEN
                    SET denda_kerusakan = 200000 * jumlah_dikembalikan;
                END IF;
                
                -- Total denda
                SET total_denda = denda_terlambat + denda_kerusakan;
            END
        ');
    }

    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS calculate_denda');
    }
};
