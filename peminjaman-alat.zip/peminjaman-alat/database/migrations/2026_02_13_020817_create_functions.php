<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        DB::unprepared('
            DROP FUNCTION IF EXISTS generate_kode_peminjaman;
            
            CREATE FUNCTION generate_kode_peminjaman()
            RETURNS VARCHAR(50)
            DETERMINISTIC
            BEGIN
                DECLARE new_kode VARCHAR(50);
                DECLARE counter INT;
                
                -- Ambil jumlah peminjaman hari ini
                SELECT COUNT(*) + 1 INTO counter
                FROM peminjaman
                WHERE DATE(created_at) = CURDATE();
                
                -- Generate kode: PJM + YYYYMMDD + counter (3 digit)
                SET new_kode = CONCAT(
                    "PJM",
                    DATE_FORMAT(NOW(), "%Y%m%d"),
                    LPAD(counter, 3, "0")
                );
                
                RETURN new_kode;
            END
        ');
    }

    public function down()
    {
        DB::unprepared('DROP FUNCTION IF EXISTS generate_kode_peminjaman');
    }
};
