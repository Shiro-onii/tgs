<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Alat;

class AlatSeeder extends Seeder
{
    public function run(): void
    {
        $alats = [
            // Elektronik
            [
                'kode_alat' => 'ELK001',
                'nama_alat' => 'Laptop ASUS ROG',
                'kategori_id' => 1,
                'merk' => 'ASUS',
                'kondisi' => 'baik',
                'jumlah_total' => 5,
                'jumlah_tersedia' => 5,
                'spesifikasi' => 'Intel Core i7, RAM 16GB, SSD 512GB, RTX 3060',
            ],
            [
                'kode_alat' => 'ELK002',
                'nama_alat' => 'Printer Epson L3210',
                'kategori_id' => 1,
                'merk' => 'Epson',
                'kondisi' => 'baik',
                'jumlah_total' => 3,
                'jumlah_tersedia' => 3,
                'spesifikasi' => 'All-in-One: Print, Scan, Copy',
            ],
            [
                'kode_alat' => 'ELK003',
                'nama_alat' => 'Monitor LG 24 inch',
                'kategori_id' => 1,
                'merk' => 'LG',
                'kondisi' => 'baik',
                'jumlah_total' => 10,
                'jumlah_tersedia' => 10,
                'spesifikasi' => 'Full HD, IPS Panel, HDMI, VGA',
            ]
        ];

        foreach ($alats as $alat) {
            Alat::create($alat);
        }
    }
}