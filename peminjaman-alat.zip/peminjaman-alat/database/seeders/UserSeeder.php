<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Admin
        User::create([
            'name' => 'Administrator',
            'email' => 'admin@gmail.com',
            'password' => Hash::make('password'), // JANGAN gunakan password ini di production!
            'role' => 'admin',
            'phone' => '081234567890',
            'address' => 'Jl. Admin No. 1',
        ]);

        // Petugas
        User::create([
            'name' => 'Petugas Satu',
            'email' => 'petugas@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'petugas',
            'phone' => '081234567891',
            'address' => 'Jl. Petugas No. 1',
        ]);

        User::create([
            'name' => 'Petugas Dua',
            'email' => 'petugas2@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'petugas',
            'phone' => '081234567892',
            'address' => 'Jl. Petugas No. 2',
        ]);

        // Peminjam
        User::create([
            'name' => 'John Doe',
            'email' => 'peminjam@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'peminjam',
            'phone' => '081234567893',
            'address' => 'Jl. Peminjam No. 1',
        ]);

        User::create([
            'name' => 'Jane Smith',
            'email' => 'peminjam2@gmail.com',
            'password' => Hash::make('password'),
            'role' => 'peminjam',
            'phone' => '081234567894',
            'address' => 'Jl. Peminjam No. 2',
        ]);
    }
}