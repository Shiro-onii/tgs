<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'address',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed', // Laravel 12: otomatis hash password
    ];


    protected static function booted()
{
    static::created(function ($user) {
        \App\Models\ActivityLog::log('CREATE', "Menambah user: {$user->name} ({$user->role})");
    });

    static::updated(function ($user) {
        \App\Models\ActivityLog::log('UPDATE', "Mengubah user: {$user->name} ({$user->role})");
    });

    static::deleted(function ($user) {
        \App\Models\ActivityLog::log('DELETE', "Menghapus user: {$user->name}");
    });
}

    public function peminjaman()
    {
        return $this->hasMany(Peminjaman::class, 'user_id', 'id');
    }


    public function activityLogs()
    {
        return $this->hasMany(ActivityLog::class, 'user_id', 'id');
    }


    public function peminjaman_disetujui()
    {
        return $this->hasMany(Peminjaman::class, 'disetujui_oleh', 'id');
    }

    public function scopeRole($query, $role)
    {
        return $query->where('role', $role);
    }


    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    public function isPetugas()
    {
        return $this->role === 'petugas';
    }

    public function isPeminjam()
    {
        return $this->role === 'peminjam';
    }
}