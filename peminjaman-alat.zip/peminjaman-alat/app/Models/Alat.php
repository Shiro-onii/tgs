<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Alat extends Model
{
    use HasFactory;

    protected $table = 'alat';

    protected $fillable = [
        'kode_alat',
        'nama_alat',
        'kategori_id',
        'merk',
        'kondisi',
        'jumlah_total',
        'jumlah_tersedia',
        'foto',
        'spesifikasi',
    ];

    protected $casts = [
        'jumlah_total' => 'integer',
        'jumlah_tersedia' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected static function booted()
{
    static::created(function ($alat) {
        \App\Models\ActivityLog::log('CREATE', "Menambah alat: {$alat->nama_alat}");
    });

    static::updated(function ($alat) {
        \App\Models\ActivityLog::log('UPDATE', "Mengubah alat: {$alat->nama_alat}");
    });

    static::deleted(function ($alat) {
        \App\Models\ActivityLog::log('DELETE', "Menghapus alat: {$alat->nama_alat}");
    });
}

    /**
     * Relasi: Alat milik satu Kategori
     */
    public function kategori()
    {
        return $this->belongsTo(Kategori::class, 'kategori_id', 'id');
    }

    /**
     * Relasi: Alat punya banyak Peminjaman
     */
    public function peminjaman()
    {
        return $this->hasMany(Peminjaman::class, 'alat_id', 'id');
    }

    /**
     * Scope: Filter alat yang tersedia
     */
    public function scopeTersedia($query)
    {
        return $query->where('jumlah_tersedia', '>', 0);
    }

    /**
     * Scope: Filter berdasarkan kondisi
     */
    public function scopeKondisi($query, $kondisi)
    {
        return $query->where('kondisi', $kondisi);
    }
}
