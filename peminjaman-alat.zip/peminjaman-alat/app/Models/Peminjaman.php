<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Peminjaman extends Model
{
    use HasFactory;

    protected $table = 'peminjaman';

    protected $fillable = [
        'kode_peminjaman',
        'user_id',
        'alat_id',
        'jumlah_pinjam',
        'tanggal_pinjam',
        'tanggal_kembali_rencana',
        'tanggal_kembali_aktual',
        'keperluan',
        'status',
        'catatan_petugas',
        'disetujui_oleh',
    ];

    protected $casts = [
        'tanggal_pinjam' => 'date',
        'tanggal_kembali_rencana' => 'date',
        'tanggal_kembali_aktual' => 'date',
        'jumlah_pinjam' => 'integer',
    ];
    protected static function booted()
{
    static::created(function ($peminjaman) {
        \App\Models\ActivityLog::log('CREATE', "Peminjaman diajukan: {$peminjaman->kode_peminjaman}");
    });

    static::updated(function ($peminjaman) {
        \App\Models\ActivityLog::log('UPDATE', "Peminjaman diupdate: {$peminjaman->kode_peminjaman} (status: {$peminjaman->status})");
    });

    static::deleted(function ($peminjaman) {
        \App\Models\ActivityLog::log('DELETE', "Menghapus peminjaman: {$peminjaman->kode_peminjaman}");
    });
}



    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

  
    public function alat()
    {
        return $this->belongsTo(Alat::class, 'alat_id', 'id');
    }


    public function petugas()
    {
        return $this->belongsTo(User::class, 'disetujui_oleh', 'id');
    }


    public function pengembalian()
    {
        return $this->hasOne(Pengembalian::class, 'peminjaman_id', 'id');
    }

    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    public function scopeMenunggu($query)
    {
        return $query->where('status', 'menunggu');
    }

    public function scopeDipinjam($query)
    {
        return $query->where('status', 'dipinjam');
    }


    public function isTerlambat()
    {
        if ($this->status === 'dipinjam') {
            return now()->isAfter($this->tanggal_kembali_rencana);
        }
        return false;
    }

    public function getDurasiAttribute()
    {
        return $this->tanggal_pinjam->diffInDays($this->tanggal_kembali_rencana);
    }
}
