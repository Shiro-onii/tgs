<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Kategori extends Model
{
    use HasFactory;

    protected $table = 'kategori';
    protected $primaryKey = 'id';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;

    protected $fillable = [
        'nama_kategori',
        'deskripsi',
    ];
    protected $hidden = [];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];
    protected static function booted()
{
    static::created(function ($kategori) {
        \App\Models\ActivityLog::log('CREATE', "Menambah kategori: {$kategori->nama_kategori}");
    });

    static::updated(function ($kategori) {
        \App\Models\ActivityLog::log('UPDATE', "Mengubah kategori: {$kategori->nama_kategori}");
    });

    static::deleted(function ($kategori) {
        \App\Models\ActivityLog::log('DELETE', "Menghapus kategori: {$kategori->nama_kategori}");
    });
}


    public function alat()
    {
        return $this->hasMany(Alat::class, 'kategori_id', 'id');
    }
}