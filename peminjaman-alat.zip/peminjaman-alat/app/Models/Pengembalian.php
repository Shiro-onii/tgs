<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Pengembalian extends Model
{
    use HasFactory;

    protected $table = 'pengembalian';

    protected $fillable = [
        'peminjaman_id',
        'tanggal_pengembalian',
        'kondisi_alat',
        'jumlah_dikembalikan',
        'denda',
        'keterangan',
        'diterima_oleh',
    ];

    protected $casts = [
        'tanggal_pengembalian' => 'date',
        'jumlah_dikembalikan' => 'integer',
        'denda' => 'decimal:2',
    ];
    protected static function booted()
{
    static::created(function ($pengembalian) {
        \App\Models\ActivityLog::log('CREATE', "Pengembalian alat untuk kode peminjaman: {$pengembalian->peminjaman->kode_peminjaman}");
    });

    static::updated(function ($pengembalian) {
        \App\Models\ActivityLog::log('UPDATE', "Mengubah data pengembalian: ID {$pengembalian->id}");
    });

    static::deleted(function ($pengembalian) {
        \App\Models\ActivityLog::log('DELETE', "Menghapus data pengembalian: ID {$pengembalian->id}");
    });
}



    public function peminjaman()
    {
        return $this->belongsTo(Peminjaman::class, 'peminjaman_id', 'id');
    }


    public function petugas()
    {
        return $this->belongsTo(User::class, 'diterima_oleh', 'id');
    }

    public function hasDenda()
    {
        return $this->denda > 0;
    }
}