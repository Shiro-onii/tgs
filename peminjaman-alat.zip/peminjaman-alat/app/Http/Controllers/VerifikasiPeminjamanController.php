<?php

namespace App\Http\Controllers;

use App\Models\Peminjaman;
use Illuminate\Http\Request;

class VerifikasiPeminjamanController extends Controller
{
    public function index()
    {
        $peminjaman = Peminjaman::with(['user', 'alat'])
            ->orderByDesc('tanggal_pinjam')
            ->get();

        return view('petugas.verifikasi_peminjaman', compact('peminjaman'));
    }

    public function updateStatus(Request $request, $id)
    {
        $peminjaman = Peminjaman::findOrFail($id);

        $validated = $request->validate([
            'status' => 'required|in:dipinjam,ditolak',
            'catatan_petugas' => 'nullable|string|max:255',
        ]);

        // Update status & petugas verifikator
        $peminjaman->update([
            'status' => $validated['status'],
            'catatan_petugas' => $validated['catatan_petugas'] ?? null,
            'disetujui_oleh' => auth()->id(),
        ]);

        // Jika disetujui → kurangi stok alat
        if ($validated['status'] === 'dipinjam') {
            $peminjaman->alat->decrement('jumlah_tersedia', $peminjaman->jumlah_pinjam);
        }

        return redirect()->route('petugas.verifikasi.index')->with('success', 'Status peminjaman berhasil diperbarui.');
    }
}
