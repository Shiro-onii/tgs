<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    public function index(Request $request)
    {
        $logs = ActivityLog::with('user')
            ->orderByDesc('created_at')
            ->paginate(20);

        return view('admin.activity_log.index', compact('logs'));
    }

    public function destroy($id)
    {
        $log = ActivityLog::findOrFail($id);
        $log->delete();
        return redirect()->route('activity_log.index')->with('success', 'Log berhasil dihapus.');
    }

    public function clearAll()
    {
        ActivityLog::truncate();
        return redirect()->route('activity_log.index')->with('success', 'Semua log aktivitas telah dihapus.');
    }
}
