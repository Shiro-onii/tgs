<?php

namespace App\Http\Controllers;

use App\Models\Peminjaman;
use Illuminate\Http\Request;
use PDF;

class LaporanController extends Controller
{
    public function index(Request $request)
    {
        $tanggal_awal = $request->input('tanggal_awal');
        $tanggal_akhir = $request->input('tanggal_akhir');

        $query = Peminjaman::with(['user', 'alat'])
            ->where('status', 'dikembalikan');

        if ($tanggal_awal && $tanggal_akhir) {
            $query->whereBetween('tanggal_pinjam', [$tanggal_awal, $tanggal_akhir]);
        }

        $peminjaman = $query->orderByDesc('tanggal_pinjam')->get();

        return view('petugas.laporan.index', compact('peminjaman', 'tanggal_awal', 'tanggal_akhir'));
    }

    public function cetakPDF(Request $request)
    {
        $tanggal_awal = $request->input('tanggal_awal');
        $tanggal_akhir = $request->input('tanggal_akhir');

        $query = Peminjaman::with(['user', 'alat'])
            ->where('status', 'dikembalikan');

        if ($tanggal_awal && $tanggal_akhir) {
            $query->whereBetween('tanggal_pinjam', [$tanggal_awal, $tanggal_akhir]);
        }

        $peminjaman = $query->get();

        $pdf = PDF::loadView('petugas.laporan.pdf', [
            'peminjaman' => $peminjaman,
            'tanggal_awal' => $tanggal_awal,
            'tanggal_akhir' => $tanggal_akhir,
        ])->setPaper('a4', 'landscape');

        return $pdf->stream('laporan-peminjaman.pdf');
    }
}
