<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // ===================== Login / Register =====================

    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        if (Auth::attempt($credentials, $request->filled('remember'))) {
            $request->session()->regenerate();

            ActivityLog::log('LOGIN', 'User berhasil login');

            $user = Auth::user();
            
            if ($user->role === 'admin') {
                return redirect()->intended('/admin/dashboard');
            } elseif ($user->role === 'petugas') {
                return redirect()->intended('/petugas/dashboard');
            } else { // peminjam
                return redirect()->intended('/peminjam/dashboard');
            }
        }

        return back()->withErrors([
            'email' => 'Email atau password salah.',
        ])->onlyInput('email');
    }

    public function showRegister()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => 'peminjam',
            'phone' => $validated['phone'] ?? null,
            'address' => $validated['address'] ?? null,
        ]);

        Auth::login($user);
        ActivityLog::log('REGISTER', 'User baru melakukan registrasi');

        return redirect('/peminjam/dashboard')->with('success', 'Registrasi berhasil!');
    }

    public function logout(Request $request)
    {
        ActivityLog::log('LOGOUT', 'User logout');
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login')->with('success', 'Anda telah logout.');
    }

    // ===================== Dashboard Methods =====================

    public function adminDashboard()
    {
        return view('admin.dashboard'); // resources/views/admin/dashboard.blade.php
    }

    public function petugasDashboard()
    {
        return view('petugas.dashboard'); // resources/views/petugas/dashboard.blade.php
    }

    public function peminjamDashboard()
    {
        return view('peminjam.dashboard'); // resources/views/peminjam/dashboard.blade.php
    }
}
