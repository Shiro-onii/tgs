<?php

namespace App\Http\Controllers;
use App\Models\ActivityLog;
use App\Models\Peminjaman;
use Illuminate\Support\Facades\DB;

abstract class Controller
{
    //
public function hitungDenda($peminjamanId, $tglKembali, $kondisi, $jumlah)
{
    $result = DB::select('CALL calculate_denda(?, ?, ?, ?, @total)', [
        $peminjamanId,
        $tglKembali,
        $kondisi,
        $jumlah
    ]);
    
    $denda = DB::select('SELECT @total as total')[0]->total;
    
    return $denda;
}

    public function generateKodePeminjaman()
    {
        $kode = DB::select('SELECT generate_kode_peminjaman() AS kode')[0]->kode;
        return $kode;
    }


public function createPeminjaman($data)
{
    DB::beginTransaction();
    
    try {
        // 1. Create peminjaman
        $peminjaman = Peminjaman::create([
            'kode_peminjaman' => DB::select('SELECT generate_kode_peminjaman() as kode')[0]->kode,
            'user_id' => auth()->id(),
            'alat_id' => $data['alat_id'],
            'jumlah_pinjam' => $data['jumlah_pinjam'],
            'tanggal_pinjam' => $data['tanggal_pinjam'],
            'tanggal_kembali_rencana' => $data['tanggal_kembali_rencana'],
            'keperluan' => $data['keperluan'],
            'status' => 'menunggu',
        ]);
        
        // 2. Log activity
        ActivityLog::create([
            'user_id' => auth()->id(),
            'activity' => 'CREATE_PEMINJAMAN',
            'description' => "Membuat peminjaman {$peminjaman->kode_peminjaman}",
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
        
        // Commit jika semua berhasil
        DB::commit();
        
        return $peminjaman;
        
    } catch (\Exception $e) {
        // Rollback jika terjadi error
        DB::rollback();
        
        throw $e;
    }
}
}
