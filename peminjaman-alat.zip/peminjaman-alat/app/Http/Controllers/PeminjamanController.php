<?php

namespace App\Http\Controllers;

use App\Models\Peminjaman;
use App\Models\Alat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\ActivityLog;

class PeminjamanController extends Controller
{
    public function index()
    {
        // Peminjam hanya melihat peminjamannya sendiri
        if (Auth::user()->isPeminjam()) {
            $peminjaman = Peminjaman::where('user_id', Auth::id())->with(['alat'])->latest()->get();
        } else {
            // Admin melihat semua
            $peminjaman = Peminjaman::with(['user', 'alat'])->latest()->get();
        }

        return view('peminjaman.index', compact('peminjaman'));
    }

    public function create()
    {
        $alat = Alat::where('jumlah_tersedia', '>', 0)->get();
        return view('peminjaman.create', compact('alat'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'alat_id' => 'required|exists:alat,id',
            'jumlah_pinjam' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date',
            'tanggal_kembali_rencana' => 'required|date|after_or_equal:tanggal_pinjam',
        ]);

        $alat = Alat::findOrFail($validated['alat_id']);

        if ($validated['jumlah_pinjam'] > $alat->jumlah_tersedia) {
            return back()->with('error', 'Jumlah pinjam melebihi stok tersedia.');
        }

        $kode = 'PMJ-' . \strtoupper(uniqid());

        $peminjaman = Peminjaman::create([
            'kode_peminjaman' => $kode,
            'user_id' => Auth::id(),
            'alat_id' => $validated['alat_id'],
            'jumlah_pinjam' => $validated['jumlah_pinjam'],
            'tanggal_pinjam' => $validated['tanggal_pinjam'],
            'tanggal_kembali_rencana' => $validated['tanggal_kembali_rencana'],
            'status' => 'menunggu',
        ]);

        ActivityLog::log('CREATE', "User mengajukan peminjaman {$peminjaman->kode_peminjaman}");

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman berhasil diajukan dan menunggu verifikasi petugas.');
    }

    public function edit(Peminjaman $peminjaman)
    {
        $alat = Alat::all();
        return view('peminjaman.edit', compact('peminjaman', 'alat'));
    }

    public function update(Request $request, Peminjaman $peminjaman)
    {
        $validated = $request->validate([
            'status' => 'required|in:menunggu,dipinjam,ditolak,dikembalikan',
        ]);

        $peminjaman->update($validated);
        ActivityLog::log('UPDATE', "Admin mengubah status peminjaman {$peminjaman->kode_peminjaman} menjadi {$peminjaman->status}");

        return redirect()->route('peminjaman.index')->with('success', 'Status peminjaman berhasil diperbarui.');
    }

    public function destroy(Peminjaman $peminjaman)
    {
        $peminjaman->delete();
        ActivityLog::log('DELETE', "Menghapus data peminjaman {$peminjaman->kode_peminjaman}");
        return redirect()->route('peminjaman.index')->with('success', 'Data peminjaman berhasil dihapus.');
    }
}
 