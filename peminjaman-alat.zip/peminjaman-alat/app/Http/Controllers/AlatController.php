<?php

namespace App\Http\Controllers;

use App\Models\Alat;
use App\Models\Kategori;
use Illuminate\Http\Request;

class AlatController extends Controller
{
    public function index()
{
    $query = \App\Models\Alat::with('kategori')->orderBy('nama_alat');

    $alat = $query->paginate(10);

    return view('alat.index', compact('alat'));
}

    public function create(Request $request) // Add Request $request
{
    $selectedAlatId = $request->query('alat_id');
    $alat = Alat::where('jumlah_tersedia', '>', 0)->get();
    
    return view('peminjaman.create', compact('alat', 'selectedAlatId'));
}

    public function store(Request $request)
    {
        $validated = $request->validate([
            'kode_alat' => 'required|unique:alat,kode_alat|max:50',
            'nama_alat' => 'required|string|max:255',
            'kategori_id' => 'required|exists:kategori,id',
            'merk' => 'nullable|string|max:100',
            'kondisi' => 'required|string|max:50',
            'jumlah_total' => 'required|integer|min:1',
            'jumlah_tersedia' => 'required|integer|min:0',
            'spesifikasi' => 'nullable|string',
        ]);


        Alat::create($validated);
        return redirect()->route('alat.index')->with('success', 'Data alat berhasil ditambahkan.');
    }

    public function edit(Alat $alat)
    {
        $kategori = Kategori::orderBy('nama_kategori')->get();
        return view('alat.edit', compact('alat', 'kategori'));
    }

    public function update(Request $request, Alat $alat)
    {
        $validated = $request->validate([
            'kode_alat' => 'required|max:50|unique:alat,kode_alat,' . $alat->id,
            'nama_alat' => 'required|string|max:255',
            'kategori_id' => 'required|exists:kategori,id',
            'merk' => 'nullable|string|max:100',
            'kondisi' => 'required|string|max:50',
            'jumlah_total' => 'required|integer|min:1',
            'jumlah_tersedia' => 'required|integer|min:0',
            'spesifikasi' => 'nullable|string',
        ]);

        $alat->update($validated);
        return redirect()->route('alat.index')->with('success', 'Data alat berhasil diperbarui.');
    }

    public function destroy(Alat $alat)
    {
        $alat->delete();
        return redirect()->route('alat.index')->with('success', 'Data alat berhasil dihapus.');
    }
}
