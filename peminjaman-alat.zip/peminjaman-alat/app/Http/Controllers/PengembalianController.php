<?php

namespace App\Http\Controllers;

use App\Models\Pengembalian;
use App\Models\Peminjaman;
use Illuminate\Http\Request;

class PengembalianController extends Controller
{
    public function index()
    {
        $pengembalian = Pengembalian::with(['peminjaman.alat', 'peminjaman.user', 'petugas'])
            ->latest('tanggal_pengembalian')
            ->get();

        return view('pengembalian.index', compact('pengembalian'));
    }

    public function create()
    {
        $peminjaman = Peminjaman::where('status', 'dipinjam')->with('alat', 'user')->get();
        return view('pengembalian.create', compact('peminjaman'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'peminjaman_id' => 'required|exists:peminjaman,id',
            'tanggal_pengembalian' => 'required|date',
            'kondisi_alat' => 'required|string|max:100',
            'jumlah_dikembalikan' => 'required|integer|min:1',
            'denda' => 'nullable|numeric|min:0',
            'keterangan' => 'nullable|string|max:255',
        ]);

        $validated['diterima_oleh'] = auth()->id();

        $pengembalian = Pengembalian::create($validated);

        // Update status peminjaman & stok alat
        $peminjaman = $pengembalian->peminjaman;
        $peminjaman->update(['status' => 'dikembalikan']);
        $peminjaman->alat->increment('jumlah_tersedia', $pengembalian->jumlah_dikembalikan);

        return redirect()->route('pengembalian.index')->with('success', 'Data pengembalian berhasil disimpan.');
    }

    public function edit(Pengembalian $pengembalian)
    {
        $peminjaman = Peminjaman::where('status', 'dipinjam')->get();
        return view('pengembalian.edit', compact('pengembalian', 'peminjaman'));
    }

    public function update(Request $request, Pengembalian $pengembalian)
    {
        $validated = $request->validate([
            'tanggal_pengembalian' => 'required|date',
            'kondisi_alat' => 'required|string|max:100',
            'jumlah_dikembalikan' => 'required|integer|min:1',
            'denda' => 'nullable|numeric|min:0',
            'keterangan' => 'nullable|string|max:255',
        ]);

        $pengembalian->update($validated);

        return redirect()->route('pengembalian.index')->with('success', 'Data pengembalian berhasil diperbarui.');
    }

    public function destroy(Pengembalian $pengembalian)
    {
        $pengembalian->delete();
        return redirect()->route('pengembalian.index')->with('success', 'Data pengembalian berhasil dihapus.');
    }
}
